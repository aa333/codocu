# Architecture

A modular Telegram bot. Features ship as self-contained modules under
`src/modules/<name>/`; the bot wires them through a small DI registry at
startup and lets each module register its own Telegram handlers.

Anchors: the module contract is `src/core/module.py`; the wiring sequence
is `src/app.py`.

## Module pattern

Every module folder follows the same split:

- `module.py` — the `Module` subclass. Declares `name` / `str_name`,
  holds references resolved from DI, exposes `init` / `help` / `debug`.
- `service.py` — business logic. No `telebot` imports; easy to test in
  isolation.
- `bot_connector.py` — registers Telegram handlers and translates
  between Telegram types and the service.
- `strings.py` — user-facing strings (currently Russian).

Optional: `models.py` for Peewee tables (declared in `Module.models`) and
`types.py` for shared enums/dataclasses.

The captcha module is the fullest example.

## Two-phase startup

`app.py` does this in order:

1. Load config, init the database, build the bot.
2. Instantiate every module class and register each in DI by its
   concrete class.
3. Create every module's declared tables.
4. Call `init` on every module.

The split between (2) and (4) is the whole point of the registry: by
the time `init` runs, every other module is already resolvable via
`di.get(...)`. The captcha module relies on this to reach the chats
module.

## DI is a registry, not a framework

`src/core/di.py` is a global `dict[type, instance]` with a register/get
pair. No scopes, no factories, no lifecycle. The choice is deliberate —
if this layer ever outgrows a registry, the bot is no longer simple
enough to warrant a custom one; bring in a real container.

By convention, modules register themselves under their concrete class,
and shared infra (`AsyncTeleBot`, `AppConfig`, `ModuleList`) follows the
same shape.

## Two chat surfaces

The bot treats the two contexts very differently:

- **Group chats** — `app.py` registers handlers for new-member and
  message-content events. New joins go through the captcha gate;
  ordinary messages get a captcha intercept first, then chats-module
  presence tracking. No commands run in groups.
- **DMs** — owner commands (`/help`, `/ping`, `/debug`, `/sleep`) are
  registered with `CommandAllowedIn.DM` and don't fire in groups even
  if typed there.

When you add a feature, place it in the right context: visible to all
chat members → group; admin or owner-only → DM.

## The `cleanup_message` keyboard convention

Help and system both reply with inline keyboards that include a
"Delete" button. They emit `callback_data="cleanup_message"`; the
handler that actually deletes the messages lives in
`SystemBotConnector` and is registered by the system module.

The contract: any module that wants a Delete button on a reply emits
`cleanup_message` as the callback data. Don't register a competing
handler — the system module owns this callback.

## Owner gate

Sensitive commands check the caller against `config.owner_ids` via
`is_owner(message, owner_ids)` inside the handler. Nothing in the
framework enforces this; it is a per-handler check. Keep that pattern
when adding owner-only features.
