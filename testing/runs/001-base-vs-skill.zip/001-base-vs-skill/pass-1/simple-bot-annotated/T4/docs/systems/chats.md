# Chats — presence tracking

Tracks who has been active in which chat, so the captcha gate can
recognize returning users and skip challenging them on rejoin.

Anchor: `src/modules/chats/service.py`. Storage: `ChatMembership` in
`src/modules/chats/models.py`.

## "Known" means: spoke at least three times

A user newly seen in a chat doesn't become known until they have
posted `MESSAGES_TO_BE_KNOWN` (currently 3) messages. Until then the
count lives in a private `_watch` map. On the third message a
`ChatMembership` row is written and the user "graduates" — they
appear in the cache, and `is_known` returns true.

The threshold guards the captcha gate against drive-by joiners who
never speak being treated as returning members.

## `is_known` is the contract captcha calls

A boolean: "has this user been seen here often enough that we
shouldn't re-challenge them on rejoin?" The captcha module reaches
into chats for this single answer. Nothing else outside chats should
reach further in.

## In-memory cache + DB, side by side

`load_cache` reads every membership row on startup; mutations write
through to both the in-memory dict and Peewee. Reads always hit
memory. The cache is not a performance optimization — it is what lets
the captcha intercept answer `is_known` synchronously inside a message
handler.

If you add a mutation, write through both. A memory-only change is a
bug waiting for the next restart to surface.

## `in_chat` is presence, not row existence

Leaving a chat sets `in_chat=False`; the row stays. That preserves the
"we've seen this person before" signal across leaves and rejoins,
which is the whole point of the gate. Don't introduce row deletion
lightly — it would defeat the gate.
