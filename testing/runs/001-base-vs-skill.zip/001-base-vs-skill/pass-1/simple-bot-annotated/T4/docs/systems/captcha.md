# Captcha gate

Stops drive-by joins from posting before they prove they're human,
while staying out of the way of returning users and other corner cases.

Anchor: `src/modules/captcha/`. The gate runs in
`CaptchaBotConnector.handle_join`; the in-chat answer intercept lives
in `src/app.py`.

## When the challenge fires

A new member triggers a challenge only when all of these hold:

- they joined themselves (not added by another user),
- they aren't a bot,
- the chats module doesn't already know them (see [chats](chats.md)),
- the join event is fresh — under `CAPTCHA_OUTDATED_TIMEOUT` seconds.

Anything else short-circuits to a `JoinOutcome` and exits quietly. The
stale-join branch handles the "bot was down when you joined" case: the
user is already in, the bot can't usefully trap them now, so it just
posts an explanation and moves on.

## Why captcha depends on chats

A returning member has spoken enough times to be "known" (see
[chats](chats.md)). Re-challenging them after a leave/rejoin would be
hostile. `ChatsService.is_known` is the contract; chats owns the
answer.

## The ban-then-unban dance on timeout

A failed challenge bans the user and unbans them a second later; the
`asyncio.sleep(1)` between the two calls is load-bearing, not
cosmetic.

Without it, Telegram processes the unban before the ban has actually
committed: `only_if_banned=True` sees no ban, no-ops, and the user is
left banned. The inline comment in `_run_challenge` flags the race;
this doc carries the reason a future reader shouldn't try to tighten
the gap.

## The `~` skip hatch

A challenge whose stored answer is `~` accepts any reply (see
`CaptchaService.check_answer`). It is a manual override path — useful
during testing or to unblock a chat after a bad question — not a
question to ship. Reserve it.

## Intercept ordering in `app.py`

The message handler checks `captcha.has_ongoing` *before* touching the
chats service. A user mid-challenge shouldn't have their answer
counted as a presence message; it would race with the gate. Preserve
that order if you add another intercept here.
