# Decisions

Why the code is shaped the way it is. Each entry stands on its own — the
expected reader is someone about to change the code in question and wondering
"can I just rip this out?".

## DI is a global dict

`src/core/di.py` is a module-level dict, a `register`, and a `get`. No
container, no scopes, no factories.

We considered a real DI library and rejected it: the bot has a single process,
modules are singletons for the life of that process, and the wiring is done
once at startup in plain Python in `app.py`. A library would buy us nothing
and would force every contributor to learn its idioms.

The price is that DI is implicit — you can't tell from a module's signature
what it pulls from the registry, only by reading its `init()`. We accept that
because the module set is small and lookups are concentrated in one place per
module.

If the bot ever grows multi-tenant scopes, this is the first thing to revisit.

## The captcha intercept lives in the central router

`app.py`'s `handle_message` checks `captcha.has_ongoing(...)` *before* doing
anything else with the message, and short-circuits with `verify_answer`.

An earlier sketch had the captcha module register its own message handler that
matched any text from a user with an active challenge. We moved it out because
pytelegrambotapi dispatches to the *first* matching handler, and a handler
that runs `has_ongoing` as its filter would still race against the
"presence-tracking" handler — whichever registered first would win, and tests
would silently bind to registration order.

Keeping the precedence rule in the central router makes the ordering explicit
and removes the dependency on registration order for this case.

## Two modules react to `left_chat_member`

Both the chats module (to mark the user as out of the chat) and the captcha
module (to abort any in-flight challenge for that user) subscribe to
`left_chat_member`. pytelegrambotapi delivers the event to *both* — handlers
are not mutually exclusive when their content-type filter matches — so order
doesn't matter for correctness here, only for tracing.

If you add a third subscriber that mutates shared state, double-check
pytelegrambotapi's current semantics before assuming both fire.

## Captcha bans by ban+sleep+unban, not by kick

When a challenge times out we want to *remove* the user — not ban them
forever. The Telegram bot API has no "kick"; the idiom is `ban_chat_member`
followed by `unban_chat_member(only_if_banned=True)`.

The `asyncio.sleep(1)` between the two is load-bearing. Without it, on
Telegram's side the unban can race the ban and `only_if_banned` silently
no-ops because, from the server's view, the ban isn't committed yet. The
user is then left banned. The one-second gap is empirical; lowering it
risks the same race.

The try/except around both calls is intentional. If the user has already
left, has been removed by an admin, or the bot lacks permissions, we want
to leave a trace in the cleanup path rather than crash the challenge loop.

## `MESSAGES_TO_BE_KNOWN = 3` (chats)

A new user is recorded in `ChatMembership` only after they've sent three
messages, not on first sight. This is to filter out drive-by spam and bots
that get caught by captcha but slip a single message through racing windows.
Three messages is a heuristic — the lower the bar, the more spam noise enters
the membership table; the higher the bar, the longer captcha's "is the
joining user known?" check is wrong about legitimate returners.

The intermediate count lives in `_watch`, an in-memory dict that is *not*
persisted. If the bot restarts mid-watch, the counter resets. That's fine
for what this is — a heuristic, not a ledger.

## `/sleep` blocks the event loop on purpose

`SystemService.sleep` calls `time.sleep`, not `asyncio.sleep`. This is
deliberate: the command exists so a running instance can yield to a freshly
deployed instance during a hand-off — by blocking the event loop entirely,
the running instance stops responding to long-polling, and the new instance
picks up Telegram updates.

If you change this to `asyncio.sleep`, the bot will continue polling and the
two instances will fight for updates.

## help's "show module" callback is owner-aware twice

The callback that renders a module's help text checks ownership *and* asks
the help service `is_accessible(...)`. The double check is on purpose:
ownership decides whether system modules appear in the keyboard at all, and
`is_accessible` re-checks at click time so a callback fired from a stale
keyboard (e.g. a button rendered for an owner and clicked later by a
non-owner) can't reveal a system module.

The same pattern lives in the keyboard builder — `current_module` is set so
the currently shown module renders as a `noop` button rather than a real
link, preventing a no-op edit and a flash of "loading".

## All cleanup buttons share one callback

The "delete this message" button on `/help` and `/debug` (and anywhere else
in the future) all emit the same callback data: `cleanup_message`. That
callback is registered once, by `SystemBotConnector`. See
[conventions](conventions.md#the-cleanup_message-callback-is-shared).

## The bot does not use peewee migrations

Tables are created at startup with `db.create_tables(...)`, which is
idempotent for *creation* but not for schema changes. If a model gains a
column, the existing table is left as it was and queries against the new
column will fail.

This is an accepted rough edge for now — the schema is one table and we'd
rather hand-edit than pull in a migration framework. Anyone adding a second
model should reconsider.
