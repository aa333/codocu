# Conventions

Rules and shared agreements the code doesn't enforce — read this before adding
a new module or a new shared callback.

## Adding a module

1. Create `src/modules/<name>/` with at minimum a `module.py`.
2. Subclass `Module`. Set `name` to the directory name; set `str_name` to the
   display label that will appear in the `/help` keyboard.
3. If the module has user-facing commands or callbacks, add a `bot_connector.py`
   and a `strings.py`. Keep service logic out of the connector so the service
   stays unit-testable.
4. If the module persists state, declare its peewee model in `models.py` and
   list it in `Module.models`. The model must extend `BaseModel` (from
   `src/storage/database.py`); don't make a new `SqliteDatabase`.
5. If `init()` needs another module, declare the dependency in `depends_on`.
   The DI registry will not enforce this — it's a breadcrumb — but the
   declaration is the first thing a reviewer looks at when they wonder why
   ordering matters.
6. Add the class to `MODULE_CLASSES` in `src/app.py`. **Order in this list is
   the only place handler precedence is decided** — see
   [decisions](decisions.md#two-modules-react-to-left_chat_member). If your
   module subscribes to a content type that another module already subscribes
   to, deciding the order is part of the change.

## System modules

A module with `is_system = True` is hidden from non-owners in the `/help`
menu. Use it for operator-only surfaces: status, debugging, instance
control. The bot has exactly one system module today (`system`), but the
pattern is meant to be applied to anything that an end user shouldn't even
see exists.

The `is_system` flag is *not* an access control mechanism on its own — it
only filters the help listing. Each handler in a system connector must
still gate itself, typically with `is_owner(message, self._owner_ids)`. The
flag and the per-handler check are belt-and-braces and both should be kept.

## The `cleanup_message` callback is shared

Multiple modules emit a "delete this message" button alongside their replies
(today: `/help` and `/debug`). All of them use the same callback data,
`cleanup_message`, and the *one* callback handler that implements it lives
in `SystemBotConnector._handle_cleanup_message`.

The rule:

- Anyone may emit a button with `callback_data="cleanup_message"`.
- No one else registers a handler for that callback data.

The handler checks that the clicker is the same user who issued the
underlying command, deletes both the bot's reply and the command message,
and returns. If you need different cleanup semantics, use a different
callback name; don't fork this one.

The `helpshow:<module>` and `noop` callbacks are owned by the help module
and follow the same one-owner rule.

## Ownership checks

Owner-only commands check `is_owner(message, owner_ids)` at the top of the
handler and return silently if the check fails — no error to the user, no
log line. This is on purpose: it makes the command invisible to non-owners
in the same way a hidden file is invisible to `ls`, and it stops a curious
user from confirming the command exists by triggering an error.

`owner_ids` comes from `config.owner_ids`. Pass it into the connector at
construction time; don't reach into `AppConfig` from handlers.

## Strings live next to the module

Each module that talks to the user has its own `strings.py`. Don't import
strings across modules. The exception is `src/core/strings.py`, which holds
strings that are about the *bot's* shared UI (button labels, generic refusal
lines) rather than any one module's concept — those are imported as
`from src.core import strings as shared`.

If you find yourself wanting to share a module-specific string, that's a
sign one module is reaching into another's UI; usually the right fix is to
let the owning module render it.

## Telebot types are not in services

`service.py` files import from the standard library, peewee, and other
services — never from `telebot`. The connector translates Telegram-shaped
inputs into service calls. This keeps services unit-testable without a
running bot and keeps the telebot dependency surface small. The chats
service is the one exception: `touch(message: Message)` takes a telebot
`Message` directly. The argument is the unique price we pay for not
duplicating the chat-id/user-id/from-user extraction across every caller;
if a second caller ever needs it, split the method.

## The `# pyright: ignore[reportArgumentType]` comments

These appear on every `bot.register_message_handler(...)` call. pytelegrambotapi
uses `pass_bot=True` to change the callback signature at runtime — the bot
is passed as a second argument — but its type stubs don't model that. The
ignore is the right local fix; don't try to silence it globally.
