# Architecture

simple-bot is a Telegram group-chat bot built around a small **module** abstraction.
Each module owns a slice of business behavior (gating new members, tracking who
belongs to which chat, answering `/help`, exposing operator commands) and wires
itself to the bot during a single startup phase.

## Shape

```
app.py
  load_config -> init_db -> create_bot
  register globals in di (config, bot, ModuleList)
  for each module: await module.init()
  register the two top-level message handlers
  start polling
```

There are exactly two top-level handlers registered in `app.py`:

- **Any message in a group chat** — first asks the captcha module if the sender
  is mid-challenge (and if so, hands the message off as the answer); otherwise
  reports the message to the chats module so it can update presence.
- **New chat member** — handed straight to the captcha module.

Everything else (commands, callback queries, `left_chat_member` events) is
registered by individual modules during their own `init()`.

## The two-phase startup, and why

Modules are instantiated *before* any `init()` runs. This split exists so a
module's `init()` is free to resolve any other module from DI without worrying
about declaration order:

1. Construct every module class. At this point modules only own data that
   doesn't depend on the bot or on other modules — typically just an internal
   service object.
2. Register each module by its concrete class in the DI registry.
3. Call `init()` on each module. Now `di.get(...)` returns the fully constructed
   peer modules and shared singletons (the `AsyncTeleBot`, the `AppConfig`).
   This is the phase where a module creates its `BotConnector` and attaches
   its handlers to the bot.

The order in `MODULE_CLASSES` still matters for one thing: handler precedence.
pytelegrambotapi dispatches to the first matching handler. Today this only
manifests in the `left_chat_member` event, which both the chats and captcha
modules subscribe to — see [decisions](decisions.md#two-modules-react-to-left_chat_member).

## Module contract

A module is a subclass of `Module` (see `src/core/module.py`). The contract is:

- **identity** — `name` (machine, used as DI key for siblings and for the help
  callback data) and `str_name` (display).
- **`models`** — peewee model classes the module owns. `app.py` collects all
  of them and runs `db.create_tables(...)` once.
- **`is_system`** — when true, the module is hidden from non-owners in the
  `/help` menu. See [conventions](conventions.md#system-modules).
- **`depends_on`** — declarative. Today nothing reads this; it's a breadcrumb
  for humans reviewing wiring order. Captcha depends on chats because it asks
  whether a joining user is already known.
- **`init()`** — wire handlers, resolve peers, prime caches. See above.
- **`help()`** — short markdown shown to the user. Return `None` to omit the
  module from the `/help` menu (the chats module does this — it has no
  user-facing surface).
- **`debug()`** — short status string folded into `/debug`. Free-form.

## Inside a module

The recurring layout, when a module has any non-trivial behavior, is three
files:

- `service.py` — pure logic. Talks to the database and in-memory caches. No
  knowledge of Telegram. Unit-testable in isolation.
- `bot_connector.py` — the Telegram adapter. Owns the command/callback
  handlers, formats messages with `strings.py`, and calls into the service.
- `module.py` — the orchestrator. Implements `Module`, holds the service, and
  in `init()` constructs the connector and registers it on the bot.

The split exists so the service stays free of telebot types and stays testable.
Modules with no command surface (chats) skip the connector. Modules with no
non-trivial state (system) have a service that's mostly a thin wrapper around
psutil/the OS, but the same shape applies.

## DI

`src/core/di.py` is a global dict keyed by type. Two helpers — `register` and
`get` — and one typed wrapper, `ModuleList`, used because resolving "the list
of all modules" by `list[Module]` doesn't survive Python's type erasure.

This is deliberately the smallest thing that works. Modules are singletons for
the lifetime of the process; we don't need scopes, factories, or lifecycles.
See [decisions](decisions.md#di-is-a-global-dict).

## Persistence

SQLite via peewee. The database lives at `config.db.path`, opened in WAL mode.
Tables are created at startup from each module's declared `models`; there are
no migrations — schema changes mean dropping the db or hand-editing it. The
only model today is `ChatMembership`.

## Strings

UI strings live next to the module that uses them, in `strings.py`. Shared
strings (button labels, generic refusals) live in `src/core/strings.py`. All
user-facing text is currently Russian; this is by design — the bot is meant
for Russian-speaking groups — and there is no i18n layer.
