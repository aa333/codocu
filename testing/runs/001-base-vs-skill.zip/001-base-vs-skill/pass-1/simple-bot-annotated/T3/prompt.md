Project conventions to follow:

# Codocu — Principles

Codocu is a COde-and-DOCUmentation system for keeping code and technical documentation aligned.

These principles are the source of truth for what Codocu believes. Operational skills and
agent-facing instructions derive from this file. When a derived rule and a
principle conflict, the principle wins. When two principles conflict, the
order below decides.

## 1. Clarity is the point

A doc is judged by one thing: does its reader come away understanding. Bloated documentation 
is useless even when correct. Accuracy serves understanding; when the two fight, cut for understanding.

## 2. Code is exhaustive about what is; docs cover the negative space

Code is itself documentation, in its most detailed form: an algorithmic set
of instructions that exhaustively describes what the system does. Docs
cover what code can't: business value, rationale, intent, direction, and the changes
planned against current code.


## 3. Code and docs must not repeat themselves 

A doc must never restate what the code already says line-for-line. 
Higher-level summaries that orient the reader are fine; mirror documentation 
that drifts the moment the code moves is not.

Codocu is not compatible with exhaustive behavioral specs (SDD etc). Documents that try to
enumerate every app behavior are precisely the retelling this principle forbids. 
Unsupportable documentation which is prone to drift is useless and will be a burden.

# Codocu — Doc Standard

The rules for writing a good doc — auxiliary or internal (see the Dictionary
below). Every rule grows from a single principle: [code is exhaustive about
what is; docs cover the negative space](principles.md). Read this before
writing or judging any doc.

## Dictionary

- **Auxiliary** — docs outside code files (`.md` system docs, plans).
- **Internal** — docs inside code files (docstrings, comments).
- **Long-term** — docs that outlive feature work and survive small refactors.
  System docs, module docstrings.
- **Short-term** — docs that are only valid during a feature development
  session. Once the work lands, their content is absorbed into long-term
  docs and the short-term file is deleted.
- **Delta** — a proposed change to the code. Usually short-term, but can
  persist as a TODO or tech-debt record.
- **ADR** — Architecture Decision Record. A note of why a decision was made,
  including the alternatives considered.

## 1. A doc lives close to what it describes

Put a doc as near to its subject as the subject's scope allows. Four homes,
by scope:

- **Symbol** — one symbol or line → its docstring or an inline comment.
- **Module** — one module → the module or file header.
- **System** — a subsystem, flow, or convention with no single anchor → a
  system doc under `docs/`.
- **Outside** — the whole repo, for outside readers → a generated artifact
  (API reference, command index), never hand-written. Hand-written reference
  drifts the moment the code moves.

### Breadcrumbs

A doc that points out at code rots silently — the person changing the code
never sees the doc, so they never know to update it. Flip the arrow: leave
a one-line breadcrumb in the load-bearing code file pointing back at the
doc. The next editor sees it in their working context and remembers the doc
exists.

Use one consistent, greppable marker so a single search lists every breadcrumb
in the repo. The exact form is a project choice — record it in `codocu.md`.

Place the breadcrumb where someone working on this concept is most likely
to land — the shared mechanism, the canonical implementation, the entry
point. A handful of breadcrumbs across genuinely related files reinforces
the link and is fine. A breadcrumb in *every* file that touches a convention
is a smell: that convention wants to become a mechanism or a lint rule, and
the doc should then reference that mechanism, carrying only the *why*.

## 2. Say only what code can't

An auxiliary doc earns its space by carrying what code structurally cannot.
The kinds of content that qualify. Here are some (not exhausting) examples:

- why the subsystem exists — the force that made it necessary;
- decisions taken and rejected, with reasons (ADRs);
- deliberate non-goals and accepted rough edges, so a reader can tell an
  intentional smell from a bug;
- cross-module flow no single file owns;
- conventions and agreements no type system enforces;
- in-flight refactors and direction of travel, so a half-migrated repo
  doesn't read as broken;
- the configuration surface — env vars, flags, constants, the ways the
  system is meant to be tuned and extended.

The field test, run before every sentence:

> Could this sentence be a test assertion?

If yes, it describes behavior — the code's job. Push it down to a docstring
or delete it. An aux doc is not a behavioral spec; enumerating inputs,
outputs, and cases is work the code already does, in more detail, without
drifting.

### Naming public surfaces is fine

A doc may name a public surface in a sentence — a route, a command, a flag
— when it makes a point about why or how. It may not turn into a list of
all the routes or all the commands. That's reference material, and
reference material belongs in the Outside home, generated.

## 3. Name code only when it won't drift out from under the doc

The rule is co-change:

> Name a specific code symbol only if it changes *together* with the doc,
> or a breadcrumb guarantees the doc is in front of whoever changes that
> symbol.

That single test settles the cases:

- An ADR sitting in `docs/` *may* name specific code, even though it's far
  from that code — because the decision is about that code, and the
  breadcrumb keeps them in sync.
- A business summary *may* refuse to name code even when it sits right next
  to it — being close doesn't oblige it to transcribe. The stable business
  word reads better and survives refactors (rule 5).

## 4. Summaries describe meaning, not symbols

A short summary — a docstring especially — describes the *meaning* it
governs, not the exact symbols underneath it. The test:

> If a variable or type here were renamed without changing behavior, would
> this summary still read true?

If no, it's transcribing, not summarizing. Rewrite it to the meaning.

- Not: "System objects list is `Set<string>`." Transcribes the type;
  drifts the moment someone refactors it.
- Better: "System objects are stored in a set to drop duplicate ingests."
  States the meaning; survives the rename.

Short summaries are wanted, not discouraged. Code is hard to read without
them. The rule is not "write fewer" — it's "write them at the level of
meaning."

## 5. Prefer business words over code words

When the same thing can be named in business terms or in code terms, use
the business term. It reads better for the next person, and it survives
refactors — the business concept outlives whatever implementation
currently serves it.

# Smell Catalog

> Source: Neph corpus (distilled offline, one-way). Provenance lines cite the
> raw `#METADOCU`-labelled instances; the instances themselves live only in
> `eval-fixtures.md`.

Named, matchable signatures of bad documentation. Each entry gives the trigger,
why it's wrong, and the fix — **never the bad instance** (seeing the
anti-pattern invites reproducing it). To grade a reviewer against a real
instance, use the matching fixture in `eval-fixtures.md`.

### consumer-not-system
- Trigger: a block or ADR in a system doc describes a feature that *uses* this system rather than the system itself.
- Why: it documents a consumer, so it doesn't change how this system works; it drifts here and buries the system's real shape under unrelated detail (often reiterating code concepts as it goes).
- Fix: move it to the consumer's own doc, or open a new doc for that slice (e.g. a UI / admin-routes doc). Keep in the system doc only the part that changes how this system works.
- Source: neph access.md §"Owner admin surface", §ADRs (admin-surface ADR)

### stray-todo-in-longterm-doc
- Trigger: a long-term doc carries an inline `#TODO` / fix-later note about future work.
- Why: a long-term doc records what is and why; a fleeting task buried in its prose is invisible to whoever tracks work and rots unowned.
- Fix: move it to the tech-debt / TODO record; if the doc must mention it, leave a one-line pointer with a stable backlink.
- Source: neph access.md §"UI availability"

### unmaintainable-aggregation-list
- Trigger: a doc aggregates per-component behavior into one list, but nothing links each source component back to the list.
- Why: the list reads well as an overview, yet an editor changing one component has no way to know it exists, so it silently goes stale.
- Fix: add a backlink (breadcrumb) from each source to the list and re-check those backlinks during routine review — or drop the list if the breadcrumbs can't be maintained.
- Source: neph chat-unions.md §"Merge semantics for known modules"

### doc-far-from-anchor
- Trigger: descriptions of many symbols are gathered into one block (a class docstring, a banner) instead of sitting on each symbol.
- Why: it places each note further from its anchor than needed and forfeits the IDE's per-symbol docstring preview, so the reader doesn't meet the right note at the right symbol.
- Fix: attach a short docstring / comment to each symbol it describes; keep a shared block only for what genuinely spans all of them.
- Source: neph caps.py §Cap

### leaks-changeable-implementation
- Trigger: a docstring states an implementation detail (caching, DB access, call count) that this layer doesn't own and that can change.
- Why: it drifts when the implementation changes, it may already be wrong for some paths, and it usually sits where the people who could act on it never look.
- Fix: drop it, or move it to the layer that owns the detail (e.g. the abstract method its implementers must read), where it is both true and seen.
- Source: neph access_service.py §AccessService.resolve_user_chat_caps
- No current fixture: grading this needs the provider/caching code to show the detail belongs to a lower layer and will drift.

### summary-restates-signature
- Trigger: a summary repeats what the declaration already states — a return type, an "…or None", a parameter list.
- Why: it duplicates the code line-for-line, adding length without meaning, and drifts the moment the signature changes.
- Fix: cut the restated part; describe the meaning, or phrase the condition in plain words ("…if it has any").
- Source: neph bot_module.py §BotModule.help

---

Below is a code fixture under `testing/fixtures/full/simple-bot-annotated/`. Write auxiliary docs for this code as if you were documenting it for new engineers joining the project. Put them under `testing/runs/001-base-vs-skill/pass-1/simple-bot-annotated/T3/produced/`. Use whatever structure and tone you judge best.
