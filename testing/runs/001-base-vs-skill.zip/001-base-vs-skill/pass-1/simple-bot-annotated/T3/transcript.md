# T3 Transcript — simple-bot-annotated

**Agent ID:** a6a0a3e81b671ac24
**Subagent type:** general-purpose
**Tokens:** 56046 total · 35 tool uses · 198097 ms

## Agent summary

I wrote three documents under `produced/`:

- **architecture.md** — orients the reader: what the bot is, the two-phase startup, the central message router with its two top-level handlers, the module contract (`Module` base class fields and what they mean), the recurring three-file shape inside a module (service / bot_connector / module), the DI registry, persistence, and string-organization.
- **decisions.md** — ADR-style notes for the load-bearing choices a new engineer would want to know before changing them: why DI is a tiny global dict; why the captcha intercept lives in the central router instead of as its own handler (handler-ordering hazard); why two modules can both subscribe to `left_chat_member`; why captcha bans then unbans with a one-second sleep between (race against Telegram's `only_if_banned`); why `MESSAGES_TO_BE_KNOWN = 3` is a soft in-memory threshold; why `/sleep` deliberately blocks the event loop (instance hand-off); why help re-checks ownership at click time; the shared `cleanup_message` callback; and the deliberate absence of peewee migrations.
- **conventions.md** — what the code can't enforce: a checklist for adding a module, the `is_system` flag and its limits, the rule that exactly one connector owns each callback name (with `cleanup_message` as the canonical shared button), the silent-failure convention for owner-only commands, the rule keeping `telebot` types out of services (with the explicit `chats.touch(Message)` exception flagged), and the reason the `# pyright: ignore[reportArgumentType]` markers exist.

Approach: I avoided enumerating commands or restating signatures (these are reference material that would drift), focused on rationale and conventions, and used business words ("operator", "instance hand-off", "drive-by spam") where possible. Concrete symbols (`MODULE_CLASSES`, `_handle_cleanup_message`, `MESSAGES_TO_BE_KNOWN`) are named only where the doc is *about* that symbol's role — co-change is plausible.
