# Judge Score — T3 / simple-bot-annotated

## Scores (1–5 each, one-sentence justification)

1. **Principle adherence** — **4**. The bulk of sentences describe rationale, constraints, and rules the code can't express (race conditions, ordering precedence, anti-fork conventions); a handful of structural sentences edge into transcription.
2. **Refactor resistance** — **3**. Most decisions/conventions would survive renames and extractions, but architecture.md and conventions.md name many specific files, classes, and method names (`SystemBotConnector._handle_cleanup_message`, `BaseModel` from `src/storage/database.py`, `ChatMembership`, `MODULE_CLASSES`, `_watch`) that would silently rot under an extract/rename.
3. **Bloat** — **3**. Decisions and conventions are tight; architecture.md has redundant scaffolding (the pseudo-shell `Shape` block, the "two-phase startup" walk that re-narrates what `app.py` already shows, plus an "Inside a module" trio description that mirrors directory layout).
4. **Voice** — **4**. Conversational, "the expected reader is someone about to change the code" framing, second-person rules, "load-bearing" callouts — generally busy-reader friendly; the architecture file slips into reference-manual tone in places.

## Code-restating sentences

- `architecture.md` / "Shape" — the entire fenced block:
  > `app.py` / `load_config -> init_db -> create_bot` / `register globals in di (config, bot, ModuleList)` / `for each module: await module.init()` / `register the two top-level message handlers` / `start polling`
  This is a line-by-line transcription of `app.py`'s main coroutine; it dies the moment that function is reordered.

- `architecture.md` / "Module contract":
  > "`models` — peewee model classes the module owns. `app.py` collects all of them and runs `db.create_tables(...)` once."
  Restates `Module.models` (a list of classes) and the `db.create_tables` call site — both are visible at the call site.

- `architecture.md` / "Module contract":
  > "**identity** — `name` (machine, used as DI key for siblings and for the help callback data) and `str_name` (display)."
  Naming the two attributes and labeling one "machine" / one "display" is field-level transcription of the `Module` base class.

- `architecture.md` / "Inside a module":
  > "`service.py` — pure logic. Talks to the database and in-memory caches. ... `bot_connector.py` — the Telegram adapter. Owns the command/callback handlers ... `module.py` — the orchestrator. Implements `Module`, holds the service ..."
  This is the directory tree retold; rename-test fails (rename `service.py` → `logic.py` and every sentence is wrong).

- `architecture.md` / "Persistence":
  > "SQLite via peewee. The database lives at `config.db.path`, opened in WAL mode."
  The path and the WAL flag are config values readable in one line of source; only "no migrations" carries doc-only weight here.

- `architecture.md` / top-level handler list:
  > "There are exactly two top-level handlers registered in `app.py`"
  The count of handlers is a code fact; if a third is added the sentence silently lies. The *rationale* below it (captcha intercept first) is doc-worthy; the count itself is not.

- `conventions.md` / "Adding a module":
  > "Create `src/modules/<name>/` with at minimum a `module.py`. Subclass `Module`. Set `name` to the directory name; set `str_name` to the display label..."
  The mechanical steps duplicate what is enforced/visible at the `Module` subclass site; the doc-worthy half is "order in `MODULE_CLASSES` decides precedence," which is buried in step 6.

- `decisions.md` / "All cleanup buttons share one callback":
  > "all emit the same callback data: `cleanup_message`. That callback is registered once, by `SystemBotConnector`."
  Names the exact string literal and the exact class; if the literal or the owning class moves this rots. The *rule* (one owner) is the durable part; the names should be the breadcrumb, not the prose.

## Overall verdict

The strongest move is the **decisions** file: every entry is a "why" the code can't tell you (the `asyncio.sleep(1)` race, the captcha intercept living in the router, the double owner-check, the `time.sleep` hand-off), framed for the reader who's about to touch that code and wondering whether they can rip it out. That file is what Codocu wants aux docs to be. The worst failure mode is **architecture.md**'s middle section — it slides from orientation into transcription, with a pseudo-startup block, an attribute-by-attribute walk of `Module`, and a service/connector/module trio description that all encode the directory layout in prose. These will be the first things to rot, and a reader who has the repo open already gets that information from the tree. Conventions sits in between — solid rules, but several "Adding a module" steps reproduce what subclassing already forces, and several rules name concrete symbols (`_handle_cleanup_message`, `BaseModel`, `_watch`) without breadcrumbs in the code pointing back.
