# Judge Score — T0 / simple-bot-annotated

## Scores (1–5 each, one-sentence justification)

1. **Principle adherence** — **3**. The docs land real negative-space content (why the ban/unban sleep exists, why `time.sleep` is deliberate, the captcha-intercept rationale, the two-phase DI reason), but they keep dragging in symbol-level transcription — config tables, the exhaustive layout tree, signature lists for `utils.py`, the per-module "Pieces" enumeration — that the code states more reliably.

2. **Refactor resistance** — **2**. Heavy reliance on named symbols (`CaptchaBotConnector.handle_join`, `JoinOutcome.SKIPPED`, `CAPTCHA_OUTDATED_TIMEOUT = 45`, `MESSAGES_TO_BE_KNOWN = 3`, `register_bot_command(bot, handler, commands, allowed_in)`, `MODULE_CLASSES`, `_challenges`, `ChatMembership`) means a rename, an enum reshuffle, or a signature tweak silently invalidates large chunks without any breadcrumb pointer.

3. **Bloat** — **2**. The minimum-viable version of this doc set is README + captcha-flow plus maybe 30 lines on the module abstraction; instead we get a full `modules.md` with a from-scratch echo module template, a duplicated lifecycle ASCII trace, and a config table that already exists in `config.example.json` — easily 2–3× the necessary length.

4. **Voice** — **3**. The README and captcha-flow read like a tired engineer talking ("the bits that look weird until you know the reason", "Do not 'fix' it"), but `modules.md` and parts of `architecture.md` slide into reference-manual cadence with enumerated bullets, tables, and a tutorial-style "Adding a new module" walkthrough that no busy reader needs upfront.

## Code-restating sentences

- README.md / Config table — the entire `| Key | Type | Notes |` block. The Type column ("string", "int", "int[]", "string | null") is a literal restating of the dataclass fields in `config.py`; would fail the rename test the moment a field is renamed or retyped.
- README.md / Config table — `` "`captcha.challenge_time` | int | Seconds a new joiner has to answer." `` — the field name and meaning are right there in code; a sentence-form "default 15s timer, configurable" would carry the same intent without transcribing.
- architecture.md / "The Telegram connector" — the four-bullet list of `register_bot_command(bot, handler, commands, allowed_in)`, `register_bot_callback(...)`, `is_owner(...)`, `is_group_chat(...)`. Each could be a test assertion against `utils.py`; this is a signature dump.
- architecture.md / "Layers" — the ASCII tree of `src/app.py — entrypoint…`, `src/core/ — shared primitives…`, etc. The filesystem already says this; `ls src/` is the breadcrumb. Fails Rule 4 (summary describes meaning, not symbols).
- architecture.md / "Lifecycle in one trace" — the full ASCII trace from `asyncio.run(main())` through `await bot.infinity_polling(...)`. This mirrors `app.main()` line-for-line and would drift on any reorder.
- captcha-flow.md / "Skip conditions" — `JoinOutcome.SKIPPED`, `CAPTCHA_OUTDATED_TIMEOUT = 45`, the literal four-case bulleted list. The numeric constant and enum name are pure transcription; "stale joins (~45s) are dropped" is the meaning.
- captcha-flow.md / "The challenge" — `` "Pick a `(question, answer)` from `strings.QUESTIONS` at random." `` and `` "`service.create(...)` records the challenge with `answer.lower()` and `time_left = challenge_time`." `` — both are restatements of `_run_challenge`'s body.
- captcha-flow.md / "How an answer reaches the service" — the embedded code block `if message.from_user and captcha.has_ongoing(...)` is the code, pasted. The surrounding prose already explains the intercept; the snippet adds nothing the file two directories over doesn't.
- modules.md / "chats" / State — `` "One peewee table `chat_memberships` keyed on `(chat_id, user_id)`, plus an in-memory `_cache` mirror" `` — table name, key, and field name (`_cache`) are all in `models.py`/`service.py`.
- modules.md / "captcha" / Pieces — `` "`service.CaptchaService` — in-memory list of active `CaptchaChallenge` records. CRUD-ish: `get`, `has_ongoing`, `create`, `check_answer`, `abort`, `remove`." `` — a method roster, exactly the kind of list Rule 2 calls out as belonging generated.
- modules.md / "system" / Commands — `` "`/sleep <seconds>` / `/pause <seconds>` — blocks the event loop for 10–1200 seconds" `` — the bounds and aliases are literally what argparse/validation in the code enforces.
- modules.md / "Sketch of a minimal module" — the entire ~30-line Python example. This is teaching by transcription; it will rot the first time `register_bot_command`'s signature or `Module`'s abstract surface shifts.

## Overall verdict

The strongest move is in `captcha-flow.md` and the "Things that look like bugs but aren't" / "Conventions worth knowing" sections — those genuinely live in the negative space: timing race rationale, deliberate event-loop blocking, the captcha intercept-before-`touch` ordering, why `_cleanup` runs after the welcome. That's the doc set at its best, and it would survive most refactors because it's about intent, not symbols. The worst failure mode is symbol-fixation: the README's config table, architecture's signature lists and ASCII layout/lifecycle traces, and the entirety of `modules.md`'s per-module breakdown plus the "add a new module" tutorial together turn aux docs into a parallel reference manual that the codebase already is. The author understood the rationale layer but couldn't stop themselves from also writing the reference layer next to it — and per Codocu's doc-standard, that reference layer is where rot lives.
