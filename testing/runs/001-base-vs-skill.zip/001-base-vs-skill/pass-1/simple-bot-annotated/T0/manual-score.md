# Manual Score — T0 / simple-bot-annotated

Tier: T0 (no Codocu materials, generic prompt).
Produced: `produced/README.md`, `architecture.md`, `modules.md`, `captcha-flow.md`.

Fill each entry below. Do not let the judge or metrics influence the score
— record what the doc reads like to you.

## 1. Principle adherence — does each sentence say something code can't?

Score (1–5): 2
Notes: Decent README with config options and public api surface, some parts of docs pass as a summary and carry business-tone, but otherwise they are just verbose code duplication. Most of the negative space reasoning is missing in this project: no plans, no specs. So aux docs should be mostly empty apart from summaries. 


## 2. Refactor resistance — would this survive a rename, extract, or inline?

Score (1–5): 1
Notes: Every document but README will stale after trivial internal refactorings

## 3. Bloat — judged against a minimum-viable mental version of the same doc

Score (1–5, 5 = lean, 1 = bloated): 2
Notes: Extreme bloat, mostly due to restating code. README is okay-ish, so 2

## 4. Code-restating sentences

List specific sentences with file + approximate line / section. One per bullet.

-

## 5. Voice — busy-tired-reader, or reference material?

Score (1–5, 5 = busy-reader, 1 = reference):
Notes:

## METADOCU agreement

Ground truth: `testing/fixtures/full/simple-bot-annotated-reference/`.

Of the N annotation-flagged issues in that reference, how many does this run:

- reproduce (made the same mistake):
- avoid (the doc handles it correctly):
- introduce new (the doc adds an issue the reference doesn't):

Notes:
