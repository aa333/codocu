# Modules

Each module lives in `src/modules/<name>/`. Standard layout:

```
modules/<name>/
├── module.py         — Module subclass; wires the rest during init()
├── service.py        — pure logic and state
├── bot_connector.py  — Telegram handler registration (often optional)
├── strings.py        — user-facing copy
├── types.py          — dataclasses/enums (if needed)
└── models.py         — peewee models (if the module persists data)
```

`chats` deliberately has no `bot_connector.py` because its only handler
(`left_chat_member`) is registered inline in `module.init()`. That's fine
— the split is a guideline, not a rule.

## chats

**Purpose.** Tracks who's "in" each chat and which users the bot recognises.
`captcha` consults this to skip the gate for returning members.

**State.** One peewee table `chat_memberships` keyed on
`(chat_id, user_id)`, plus an in-memory `_cache` mirror loaded at startup.
Also an in-memory `_watch` counter for users we've seen but haven't
promoted to "known" yet.

**Becoming "known".** `touch(message)` is called on every group message
from a real user. A user becomes known after `MESSAGES_TO_BE_KNOWN = 3`
messages — only then do we write a `ChatMembership` row. Existing
members have their `last_message_at` updated and `in_chat=True` if they'd
been marked out.

**`left_chat_member`.** Handled in `ChatsModule.init()`. Sets `in_chat=False`
in cache and DB, but keeps the row so a return-and-rejoin doesn't have to
re-earn "known".

**Commands.** None. This module is purely a service for others.

## captcha

**Purpose.** Gate new joiners with a question. Pass → welcome. Fail → soft kick
(ban then immediate unban) so the user can rejoin and try again.

**Pieces.**
- `service.CaptchaService` — in-memory list of active `CaptchaChallenge`
  records. CRUD-ish: `get`, `has_ongoing`, `create`, `check_answer`,
  `abort`, `remove`.
- `bot_connector.CaptchaBotConnector` — owns the join flow, the answer
  flow, the cleanup, and the `left_chat_member` abort handler.
- `types` — `CaptchaChallenge` dataclass, `ChallengeStatus` (ONGOING /
  PASSED / ABORTED), `JoinOutcome` (PASSED / FAILED / SKIPPED / ABORTED),
  and `CAPTCHA_OUTDATED_TIMEOUT = 45`.
- `strings` — questions list, prompts, success/timeout templates.

**Public surface on `CaptchaModule`.** `has_ongoing`, `verify_answer`,
`handle_join`. `app.py` calls these directly — it's the one place outside
the module that orchestrates captcha.

See [`captcha-flow.md`](captcha-flow.md) for the detailed flow.

## help

**Purpose.** `/help` in DM shows an inline keyboard of available modules.
Tapping a module replaces the message with that module's help text.

**Access rules.** Modules with `is_system = True` are hidden from non-owners.
Hitting a system-module callback as non-owner returns `ACCESS_DENIED` instead
of the help.

**Quirks.**
- The "current" module's button is rendered with `callback_data="noop"`
  so re-tapping the same button doesn't reload the message.
- Help text is run through `escape_markdown` (MarkdownV2). Module
  `strings.HELP` text in the codebase is already partially escaped (e.g.
  the `\\.` in `help/strings.py`). When writing a new module, either
  pre-escape or rely on the wrapper.
- The "Удалить" button on the help reply emits `cleanup_message`, which
  `system`'s connector handles. So `help` depends on `system` being
  loaded if you want delete-to-work — that's not currently in
  `depends_on`, just an implicit coupling.

**Commands.** `/help` (DM only).

## system

**Purpose.** Owner-only operational commands and the global cleanup callback.

**Commands (DM, owner only).**
- `/ping` — replies with hostname and uptime.
- `/debug` — collects each module's `debug()` output plus CPU/RAM stats,
  appends a Delete button.
- `/sleep <seconds>` / `/pause <seconds>` — blocks the event loop for
  10–1200 seconds so this instance stops polling. Intended for handing
  over to a backup instance during a deploy.

**Callbacks.** Handles `cleanup_message` (the Delete button used here
and by `help`). Authorisation: only the user who sent the original
command can delete the reply.

**`is_system = True`.** This module is hidden from non-owners in `/help`.

**Why the `time.sleep` is not a bug.** See architecture notes.

## Adding a new module

1. Make `src/modules/<name>/`, drop in `__init__.py`, `module.py`,
   `service.py`. Add `bot_connector.py`, `strings.py`, `types.py`,
   `models.py` as needed.
2. Subclass `Module`. Set `name` (lowercase, used as DI key by name and
   in callback data), `str_name` (display name in the help keyboard),
   `is_system` if owner-only, `depends_on` if you read another module
   during `init()`, and `models = (...)` if you persist anything.
3. In `__init__`, build only what doesn't need other modules.
4. In `init()`:
   - `di.get(AppConfig)` and `di.get(AsyncTeleBot)` are always available.
   - Resolve other modules via `di.get(OtherModule)`.
   - Build your connector, call `connector.register(bot)`.
   - Load any caches.
5. Implement `help()` (return `None` to hide from `/help`) and `debug()`
   (return a short status block prefixed with `[YourName]`).
6. Register your class in `MODULE_CLASSES` in `src/app.py`. Order matters
   only for `__init__` side-effects; cross-module reads happen in
   `init()` where everything is registered.

## Sketch of a minimal module

```python
# src/modules/echo/module.py
from telebot.async_telebot import AsyncTeleBot
from telebot.types import Message

from src.connectors.telegram.utils import (
    CommandAllowedIn, register_bot_command,
)
from src.core import di
from src.core.module import Module


class EchoModule(Module):
    name = "echo"
    str_name = "Echo"

    def help(self) -> str:
        return "*Echo*\n• `/echo text` — repeat text"

    async def debug(self) -> str:
        return "[Echo]\nno state"

    async def init(self) -> None:
        bot = di.get(AsyncTeleBot)
        register_bot_command(bot, self._handle, ["echo"], CommandAllowedIn.Both)

    async def _handle(self, message: Message, bot: AsyncTeleBot) -> None:
        text = (message.text or "").partition(" ")[2] or "(empty)"
        await bot.reply_to(message, text)
```

Then in `app.py`:

```python
from src.modules.echo.module import EchoModule
MODULE_CLASSES = [ChatsModule, CaptchaModule, HelpModule, SystemModule, EchoModule]
```

That's enough — `/help`'s keyboard, `/debug`'s aggregator, and the
DI registry all pick it up automatically.
