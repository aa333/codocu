# Architecture

## Layers

```
src/app.py                 — entrypoint: load config, build bot, wire modules, poll
src/core/                  — shared primitives (config, DI, Module base, shared strings)
src/connectors/telegram/   — pytelegrambotapi adapter (bot factory + handler helpers)
src/storage/database.py    — single peewee SqliteDatabase, BaseModel, init_db()
src/modules/<name>/        — one folder per feature (captcha, chats, help, system)
```

The split that matters: **`core` defines contracts, `modules` implement
features, `connectors` translate between Telegram-the-protocol and our
internal services.** Don't import Telegram types from `core` or from a
module's `service.py`.

## The Module abstraction

`src/core/module.py` defines `Module(ABC)`. Each feature subclasses it:

- Class attrs declare metadata (`name`, `str_name`, `is_system`,
  `depends_on`, `models`).
- `__init__` does cheap setup only — building services that don't need
  other modules yet.
- `async init()` runs **after every module is in DI**, so this is where you
  resolve cross-module deps (`di.get(...)`), load caches, build connectors,
  and register Telegram handlers.
- `help()` returns user-facing help (or `None` to hide from `/help`).
- `async debug()` returns a one-block status string for `/debug`.

This two-phase construction (build first, then `init()`) is the whole
reason DI exists here: modules can reference each other without import
cycles or ordering bugs.

## The DI container

`src/core/di.py` is a 40-line dict keyed by type:

```python
di.register(AppConfig, config)
di.register(AsyncTeleBot, bot)
config = di.get(AppConfig)
```

It's a global registry — no scoping, no auto-wiring. That's deliberate: the
app is a single process with one of everything. `ModuleList` is a thin
typed wrapper registered under its own type so code can ask for "all
modules" without bumping into the bare-`list` type.

## The Telegram connector

`src/connectors/telegram/bot.py` is a one-liner that creates the
`AsyncTeleBot` and sets the optional proxy. `utils.py` is where the real
contract lives:

- `register_bot_command(bot, handler, commands, allowed_in)` — registers a
  command handler scoped to DM, group, or both.
- `register_bot_callback(bot, handler, func)` — inline-keyboard callbacks.
- `is_owner(message, owner_ids)` — owner check, used by `system` and `help`.
- `is_group_chat(message)` — the predicate `app.py` uses to ignore DMs in
  the generic message handler.

`pass_bot=True` is on every registration, so handler signatures are
`(message, bot)` / `(call, bot)`. The pyright ignores in callers are
because the pytelegrambotapi stubs don't model that signature shift.

## How a Telegram event reaches business logic

```
Telegram API
   v
AsyncTeleBot (telebot)             registered in DI
   v
bot.infinity_polling()             driven from app.main()
   v
registered handlers                from app.py and each module's bot_connector
   v
ModuleX.service                    pure-Python logic, no telebot imports
   v
peewee models / in-memory state
```

There are two layers of handler registration:

1. **`app.py`** registers the generic message handler and the new-member
   handler. The generic handler is what enforces the captcha intercept:
   "if this user has an open challenge, route the message into captcha and
   don't let `chats` see it." Without this, ChatsService would count
   answer attempts as legitimate activity.
2. **Each module's `bot_connector.register(bot)`** registers its own
   commands and callbacks during `module.init()`. So `captcha` registers a
   `left_chat_member` handler to abort challenges; `chats` registers
   another for membership tracking; `system` and `help` register their
   commands. Multiple handlers on the same `content_types` are fine —
   telebot runs them in registration order.

## Storage

`src/storage/database.py` defines a single module-level `SqliteDatabase`
with `journal_mode=wal` and `foreign_keys=on`. Every model subclasses
`BaseModel`. `init_db(path)` is called once from `app.main()` before any
module is constructed, so model classes resolve their `Meta.database`
correctly by the time tables are created.

Table creation: `app.main()` collects `m.models` from every module and
calls `db.create_tables(all_models)`. If you add a model, list it on
your module's `models` tuple — that's the only registration needed.

Today only `chats` persists anything (`ChatMembership`). Captcha state is
in-memory by design — a restart drops in-flight challenges, which is
acceptable because they're short-lived.

## Lifecycle in one trace

```
asyncio.run(main())
├── load_config("config.json")
├── init_db(config.db.path)            # peewee SqliteDatabase ready
├── create_bot(token, proxy)           # AsyncTeleBot instance
├── di.register(AppConfig, ...)
├── di.register(AsyncTeleBot, ...)
├── for cls in MODULE_CLASSES:         # ChatsModule, CaptchaModule, HelpModule, SystemModule
│       m = cls()                      # cheap __init__
│       di.register(type(m), m)
├── di.register(ModuleList, ...)
├── db.create_tables(all_models)
├── for m in modules:
│       await m.init()                 # resolve deps, register handlers
├── register app.py's message + new_member handlers
├── for chat_id in debug_chats: send "simplebot started"
└── await bot.infinity_polling(...)
```

Note: module construction order matches `MODULE_CLASSES`, and that order
matters because `CaptchaModule.__init__` doesn't depend on anyone, but
`CaptchaModule.init()` calls `di.get(ChatsModule)` — which works because
all modules are registered before any `init()` runs. The `depends_on`
attribute on `Module` is informational only right now; nothing enforces
it.

## Conventions worth knowing

- **`bot_connector.py` vs `service.py`** — services hold logic and state,
  connectors hold "how this gets called from Telegram." Tests would mock
  the connector and exercise the service. Don't put telebot imports in
  `service.py`.
- **Strings live in `strings.py`** at module level. The Russian text is
  the user-facing copy; helper functions like `random_no()` and templated
  format strings (e.g. `CHALLENGE_INTRO.format(time=...)`) live there too.
- **`MarkdownV2` is the parse mode** for help replies. That's why
  `escape_markdown` is used around module help text in
  `help/bot_connector.py`.
- **Errors during Telegram I/O are swallowed** at the call site with
  bare `except Exception: pass`. This is intentional — a transient API
  hiccup shouldn't crash the polling loop — but it does mean failures
  during e.g. captcha cleanup are invisible. If you want a log, add one
  inside the except.
- **`time.sleep(seconds)` in `/sleep` is deliberate.** It blocks the event
  loop on purpose so this instance stops polling and a backup instance can
  take over. Do not "fix" it to `await asyncio.sleep`.
