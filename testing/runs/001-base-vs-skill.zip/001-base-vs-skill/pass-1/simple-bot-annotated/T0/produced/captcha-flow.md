# Captcha flow

The captcha module is the only feature with non-trivial timing and
non-obvious behaviour. This page traces what happens, in order, and
explains the parts that look strange.

## Trigger: a `new_chat_members` event

Telegram fires a service message when someone joins. `app.py` registers
`handle_new_member` for the `new_chat_members` content type, which pulls
the first new user out of the list and calls
`captcha.handle_join(bot, message, new_user)`.

Note "first new user only". If a batch contains more than one joiner,
later ones are silently ignored. The original codebase this was modelled
on apparently never observed multi-user joins in practice; if you do,
you'll want to iterate.

## Skip conditions (handled before starting a challenge)

`CaptchaBotConnector.handle_join` returns `JoinOutcome.SKIPPED` (no
challenge run) for any of:

1. **The "new user" is a bot.** Sends `PASSED_BOT` and exits.
2. **Someone added someone else** (`message.from_user.id != new_user.id`).
   The assumption is that an existing trusted member vouched for them.
3. **The user is already "known"** to the `chats` module (3+ prior messages
   on file). Returning members aren't re-gated.
4. **The join event is stale** (older than `CAPTCHA_OUTDATED_TIMEOUT = 45`
   seconds). Happens after long polling outages. If the user is in fact
   still a member, post a short "missed it" notice (`OUTDATED`); either
   way, skip.

Otherwise: run a challenge.

## The challenge

`_run_challenge`:

1. Pick a `(question, answer)` from `strings.QUESTIONS` at random.
2. Reply to the join message with the intro plus the question wrapped in
   backticks.
3. `service.create(...)` records the challenge with `answer.lower()` and
   `time_left = challenge_time` (config'd, default 15).
4. Spin: `while ONGOING and time_left > 0: sleep(1); time_left -= 1`.

`time_left` is decremented by this coroutine, but `status` is mutated
externally — `check_answer` flips it to `PASSED` and the
`left_chat_member` handler flips it to `ABORTED`. There's no lock; the
event loop is single-threaded.

## How an answer reaches the service

Here's the part that needs the most explanation. The captcha doesn't
register a separate text handler for answers. Instead, `app.py`'s
**generic message handler intercepts**:

```python
if message.from_user and captcha.has_ongoing(chat_id, user_id):
    await captcha.verify_answer(bot, message)
    return
```

This runs *before* `chats_svc.touch()`, so attempts don't count toward
becoming "known". `verify_answer` calls `service.check_answer`, which
returns `True` iff `text.lower() == challenge.answer` (or the literal
answer `"~"` — a wildcard kept around for testing). On success the
spinning challenge loop exits because `status` is now `PASSED`.

The cleanup of the captcha message itself happens in `_cleanup` after
the loop exits, not in `verify_answer`. `verify_answer` deletes the
*user's answer message* (the one that contained "4" or whatever).

## Outcomes after the loop exits

```
status == PASSED   → _cleanup, return PASSED          (no further action; the welcome message was already sent in verify_answer)
status == ABORTED  → _cleanup, return ABORTED         (user left; just clean up)
status == ONGOING  → _cleanup, ban+sleep(1)+unban,    (timeout; soft-kick)
                     send TIMEOUT message,
                     return FAILED
```

`_cleanup` deletes the captcha question message and removes the challenge
from `service._challenges`. Both telebot calls are wrapped in
`try/except Exception: pass` because the message may already be gone.

## Why the ban-then-unban dance has an `asyncio.sleep(1)` between them

Direct quote from the inline comment, paraphrased: without a brief gap,
the unban can race the ban on Telegram's side. The unban is sent with
`only_if_banned=True`; if it arrives before the ban has been committed,
it silently no-ops and the user stays banned. A 1-second pause is enough
in practice. Do not remove this sleep unless you have a better fix.

## `revoke_messages=False`

The ban does not delete the user's messages. The only message they'd
have sent during the challenge is their failed answer attempt, which
`verify_answer` doesn't even reach (the loop terminates first), so
there's nothing to revoke anyway.

## The `left_chat_member` abort path

`CaptchaBotConnector._handle_left_member` is registered during
`CaptchaModule.init()` for `content_types=["left_chat_member"]`. If the
leaving user has an active challenge, it flips the status to `ABORTED`
and the spinning loop exits cleanly. No kick, no welcome.

There's a second `left_chat_member` handler in `chats/module.py` that
updates membership. Both fire — telebot runs registered handlers in
order — and that's intentional.

## Concurrency notes

- One in-flight challenge per `(chat_id, user_id)`. `service.create`
  aborts any prior one for the same key before creating a new one.
- The `_challenges` list is iterated and mutated within the same event
  loop, no locks needed.
- The status enum acts as the synchronisation primitive: producers
  (timer loop, answer check, leave handler) write it; the timer loop
  reads it to decide when to stop.

## Things that look like bugs but aren't

- **`asyncio.sleep(1)` between ban and unban.** Required, see above.
- **`time.sleep` in `system/service.sleep`.** Blocking the event loop
  is the point — it disables polling for the duration.
- **Bare `except Exception: pass` around `bot.delete_message` and
  `bot.send_message`.** Telegram I/O is best-effort during cleanup.
- **The captcha welcome message is sent before the captcha question
  message is deleted.** Order is `verify_answer` (sends welcome) →
  challenge loop exits → `_cleanup` (deletes question). Visually fine.
- **`answer == "~"` always passes.** Test/debug backdoor; harmless in
  production since "~" isn't on the question list.

## Things that *are* sharp edges

- **Multi-user joins:** only the first new user is challenged.
- **No persistence of `challenges`:** restart-during-challenge loses
  the challenge and the user is effectively skipped on next message.
- **No rate limit on `/sleep`:** an owner could DoS themselves.
- **`time_left` decrement assumes ~1s per loop iteration.** It's "close
  enough" but a slow event loop will let timeouts run longer than
  configured.
