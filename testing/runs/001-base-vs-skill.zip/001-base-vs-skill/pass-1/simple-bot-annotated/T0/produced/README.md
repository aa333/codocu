# simple-bot

A Telegram group bot that gates new joiners with a captcha and tracks chat
membership. Async, single-process, SQLite-backed. Python 3.14.

## What it does, end to end

1. New user joins a group. The bot replies with a math/word question and a
   short timer (default 15s).
2. If the user answers correctly in time, the bot says hi and deletes its
   own captcha message.
3. If the timer runs out, the bot bans-then-unbans the user (a "soft kick"
   that forces them to rejoin). Aborted challenges (e.g. user leaves) are
   silently dropped.
4. Users who pass — and existing members who talk often enough — are
   recorded as "known" so the captcha skips them next time they appear.
5. Owners (`owner_ids` in config) get `/help`, `/ping`, `/debug`,
   `/sleep` in DM.

## Running it locally

```bash
uv sync
cp config.example.json config.json
# fill in tg_token, optionally bot_username, owner_ids, debug_chats
uv run python -m src.app
```

Required deps come from `pyproject.toml`; `uv` is the assumed runner but
plain `pip` works too. SQLite file path is `config.db.path`
(default `simple_bot.db`).

## Config (config.json)

| Key | Type | Notes |
| --- | --- | --- |
| `tg_token` | string | Telegram bot token. Required. |
| `bot_username` | string \| null | Cosmetic; not used at runtime by current code. |
| `db.path` | string | SQLite file path. |
| `captcha.challenge_time` | int | Seconds a new joiner has to answer. |
| `debug_chats` | int[] | Chat IDs that get a "simplebot started" message at boot. |
| `owner_ids` | int[] | User IDs allowed to invoke `/ping`, `/debug`, `/sleep`, `/help` in DM, and to see system modules in help. |
| `proxy` | string \| null | Forwarded to `telebot.asyncio_helper.proxy`. |
| `log_level` | string | Not currently consumed; logging isn't wired. |

`log_file` defaults to `bot.log` and is read by `/debug` if it exists; nothing
writes it out of the box.

## Where to look next

- [`architecture.md`](architecture.md) — how the pieces fit (modules, DI,
  the bot dispatcher, why captcha intercepts in `app.py`).
- [`modules.md`](modules.md) — what each module does, plus the recipe for
  adding a new one.
- [`captcha-flow.md`](captcha-flow.md) — the join-to-pass-or-kick sequence
  in detail, including the bits that look weird until you know the reason.
