# Judge Score — T1 / simple-bot-annotated

## Scores (1–5 each, one-sentence justification)

1. **Principle adherence** — **3.5**. Most sentences carry genuine negative-space content (rationale, ordering constraints, gotchas, intent), but pockets — especially the `module.py` attribute list in `architecture.md` and the file-by-file menu in `module-pattern.md` — restate the ABC and the directory layout in a way the code itself already declares.
2. **Refactor resistance** — **3**. Heavy reliance on specific symbol names (`CaptchaService._challenges`, `MESSAGES_TO_BE_KNOWN`, `_watch`, `handle_message`, `register_bot_command`) means a rename or extraction would silently falsify multiple sentences; some claims (e.g. "`_challenges` is a list") are pure transcription that doesn't survive a refactor to a dict.
3. **Bloat** — **3**. The set is well-organized and load-bearing in most places, but `README.md`'s repo-layout-in-one-screen plus `architecture.md`'s startup-order numbered list plus `module-pattern.md`'s file-table cover overlapping ground, and several gotchas (proxy module-global, `pyright: ignore` rationale) are short enough to live as code comments rather than aux doc.
4. **Voice** — **4**. The prose is genuinely busy-reader friendly — short, concrete, with "where to look when…" navigational aids and inlined rationale — though the attribute and file lists drop into reference register that breaks the tone.

## Code-restating sentences

- "`name` — short, lowercased, used as the key in `ModuleList`." — `architecture.md`, *The Module contract*. Transcribes the ABC declaration; would also need editing on rename.
- "`str_name` — human label shown in the `/help` keyboard." — `architecture.md`, *The Module contract*. Mirrors the attribute name and its docstring intent.
- "`models` — peewee model classes for `db.create_tables`. Default `()`." — `architecture.md`, *The Module contract*. Could be a test assertion against the ABC signature.
- "`help()` → `str | None`. `None` hides the module from `/help`." — `architecture.md`, *The Module contract*. The return-type half is pure transcription of the signature.
- The whole `| File | When to add it | Example |` table in `module-pattern.md`, *The shape*. The rows like "`__init__.py` — Empty — just makes it a package." restate filesystem facts code already shows.
- "`CaptchaService._challenges` is a `list[CaptchaChallenge]`." — `gotchas.md`, *Captcha state is in-memory only*. Reads as a type annotation; the rationale-bearing claim ("there is no persistence") is fine, but the type sentence is transcribing.
- "Subclass `BaseModel` from `src/storage/database.py`. That gives you the shared `db` and a `Meta.database` binding." — `module-pattern.md`, *Models*. Sentence 2 restates what subclassing the base class does, visible in the base class.
- "Both helpers pass `pass_bot=True`, so every handler signature is `(message_or_call, bot)`." — `architecture.md`, *Message dispatch*. The signature half is code-restating; the "why" (uniformity) is fine on its own.
- The `register_bot_command(bot, self._handle_foo, ["foo"], CommandAllowedIn.DM)` skeleton block in `module-pattern.md`, *What `bot_connector.py` looks like*. Echoes the actual connector code with no added meaning beyond "look at the connectors."
- "`MESSAGES_TO_BE_KNOWN` (= 3)" appears in both `README.md` (*Where to look when…*) and `architecture.md` (*Persistence*). The literal value is in the code; pinning it in prose invites drift.

## Overall verdict

The set's strongest move is its consistent commitment to the *why* and the *ordering* — startup steps explained in terms of the constraints they satisfy, the captcha gate's `return` flagged as load-bearing with the specific failure mode named, the `time.sleep` vs `asyncio.sleep` distinction reframed as the feature rather than a bug. That is exactly what aux docs are for. Its worst failure mode is creeping reference-material: the Module ABC attribute list, the module-file table, and several code skeleton blocks slip into transcription, anchoring the docs to current symbol names so that a rename or signature change would falsify sentences without warning — exactly the drift the doc standard's rename test is meant to catch. Tightening those sections (reduce to "the ABC defines load-bearing names; see `module.py`") would push the set from "mostly clarifying" to genuinely lean.
