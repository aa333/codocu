# Gotchas

Things that look wrong but are deliberate, and things that look fine but
will bite. Most of these are visible in the code if you read it carefully;
they're collected here so a new engineer can stop tripping over them.

## Captcha ban-then-unban has a 1-second sleep between calls

In `captcha/bot_connector.py::_run_challenge`:

```python
await bot.ban_chat_member(...)
await asyncio.sleep(1)
await bot.unban_chat_member(..., only_if_banned=True)
```

The sleep is load-bearing. Without it the unban can race the ban on
Telegram's side and silently no-op (`only_if_banned` sees an
uncommitted ban and skips), leaving the user permanently banned. There's
an inline comment saying so. Don't "clean it up" by removing the
`asyncio.sleep`.

The kick uses ban + unban rather than `kick_chat_member` because Telegram
doesn't have a plain "kick" — banning then unbanning is the documented
way to remove a member who can re-join later.

## `/sleep` blocks the event loop on purpose

`SystemService.sleep` calls `time.sleep`, not `asyncio.sleep`. This is
not a bug. The whole point of `/sleep` is to stop the polling loop so a
second instance of the bot (on another host) can take over via Telegram's
"only one long-poller wins" semantics. `asyncio.sleep` would yield to
the event loop and polling would continue.

Side effect: while sleeping, *nothing* this bot does works. No commands,
no captcha challenges, no left-member events. That's fine for the
hand-off use case but if you reuse `sleep` for anything else, remember
it really does freeze the process.

## Captcha state is in-memory only

`CaptchaService._challenges` is a `list[CaptchaChallenge]`. There is no
persistence. If you restart while a user is mid-challenge, they're no
longer being challenged and they're not yet known to `chats`. They'll
get challenged again the next time they trigger a join event.

The `_watch` dict in `ChatsService` (progress toward "known") is also
in-memory. Restart resets it.

## The captcha gate's `return` is load-bearing

In `app.py::handle_message`:

```python
if message.from_user and captcha.has_ongoing(chat_id, user_id):
    await captcha.verify_answer(bot, message)
    return                                   # ← this
if message.from_user is not None:
    chats_svc.touch(message)
```

Without the `return`, an in-progress captcha attempt counts toward
`MESSAGES_TO_BE_KNOWN`. A user could pass captcha after sending two
wrong answers and a right one, then never be challenged again because
`chats.is_known` returns `True`. Keep the early return.

## `pyright: ignore[reportArgumentType]` on every handler registration

```python
bot.register_message_handler(
    handle_message,  # pyright: ignore[reportArgumentType]
    ...
    pass_bot=True,
)
```

The comment in `app.py` explains: `pass_bot=True` changes the callback
signature at runtime (it adds the `bot` argument), but pytelegrambotapi's
type stubs don't model that. The ignore is correct. Don't try to "fix"
the handler's signature to satisfy pyright — you'd break it at runtime.

Same goes for `# pyright: ignore[reportAttributeAccessIssue]` on
assignments like `existing.in_chat = True` in `ChatsService`. Peewee's
descriptor-based fields confuse pyright; the assignment actually works.

## Help text uses MarkdownV2 — escape user-provided text

`HelpBotConnector` calls `bot.edit_message_text(..., parse_mode=
"MarkdownV2", ...)`. The static help strings in each module's
`strings.py` are already escaped for MarkdownV2 (note the `\\.` in
`DEFAULT_HELP_TEXT = "Выберите модуль для подробной справки\\."`). When
showing dynamic text (a module's `help()` output), the connector calls
`escape_markdown(raw_help)` first.

If you add a new module whose `help()` returns text with `.`, `*`, `_`,
`(`, etc., either escape them in the string or rely on the connector's
escape pass. Don't mix — double-escaping renders backslashes literally.

## Inline buttons check the author of the *original command*

In `help/bot_connector.py::_handle_show_module` and
`system/bot_connector.py::_handle_cleanup_message`, the connector walks
`call.message.reply_to_message.from_user.id` and compares it to
`call.from_user.id`. Click that button as anyone other than the user
who ran `/help` (or `/debug`) and you get a sass-bot reply via
`shared.random_no()` and nothing happens. This is intentional — buttons
belong to whoever asked.

The `# type: ignore` comments around `command_message: Message =
call.message.reply_to_message` are because the type stubs make that
field `Message | None`; the runtime check above is what guarantees it.

## `handle_new_member` only looks at the first added member

```python
new_user = message.new_chat_members[0]
await captcha.handle_join(bot, message, new_user)
```

Telegram batches multi-add events. The current behaviour challenges only
the first user in the batch. If someone invites three people in one
action, only one gets challenged; the other two are silently let
through. This is a known limitation, not a typo.

## Proxy is set via a module-global on telebot

`create_bot` writes to `telebot.asyncio_helper.proxy`. That's
process-global. There is no "per-bot proxy" — if you ever spin up a
second `AsyncTeleBot` in the same process, it'll share the proxy. Not a
problem today; will be a footgun if you ever multi-bot.

## DI lookups in `__init__` will fail; do them in `init()`

A module is constructed *before* the other modules are registered. Any
`di.get(SomeOtherModule)` inside `__init__` will raise `KeyError`. The
ABC's `init()` is async and called after all modules are in the
registry, which is why you see all cross-module lookups happen there.
Equally, `AppConfig` and `AsyncTeleBot` are registered in `app.py`
*before* any module is constructed, so those two are safe in `__init__`
— but the convention is still to fetch them in `init()` to keep
construction trivial.

## `db.create_tables` happens once, after all modules are built

There's no migration framework. Adding a column to an existing model
will not alter the SQLite table; peewee's `create_tables` is `IF NOT
EXISTS`. You need to either delete the DB file or write the `ALTER
TABLE` yourself. The codebase has no migration story today.

## `log_file` is read by `/debug` but nothing writes to it

`SystemService.get_recent_logs` opens `config.log_file` and returns the
last 200 lines. Nothing in this repo configures Python's `logging`
module to actually write there. If you want `/debug` to surface logs,
add a `logging.basicConfig(filename=...)` call somewhere early in
startup. (The current state is that the call returns `None` because the
file doesn't exist.)

## `debug_chats` boot notice swallows errors

```python
for chat_id in config.debug_chats:
    try:
        await bot.send_message(chat_id, "simplebot started")
    except Exception:
        pass
```

If the bot doesn't have permission, the chat doesn't exist, the token
is wrong, etc., you'll get *nothing* — not even a log line. If startup
notifications seem broken, check that the bot is actually in the chat
and that the chat ID is correct (negative for groups, with a `-100`
prefix for supergroups).
