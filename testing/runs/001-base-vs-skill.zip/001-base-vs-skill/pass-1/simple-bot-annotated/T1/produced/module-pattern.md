# Adding a module

If you're adding bot functionality, you almost always want a new module
rather than code in `app.py`. Modules are how the codebase stays scannable;
`app.py` only carries the top-level gate-and-route logic.

## The shape

A module is a directory under `src/modules/<name>/`. Pick whichever of
these files you actually need; the existing modules show the menu:

| File              | When to add it                                   | Example                      |
| ----------------- | ------------------------------------------------ | ---------------------------- |
| `module.py`       | Always — subclass `Module`, this is the glue.    | every module                 |
| `service.py`      | Almost always — business logic without telebot.  | every module                 |
| `bot_connector.py`| When the module owns telegram handlers/keyboards.| captcha, help, system        |
| `strings.py`      | When user-facing text is non-trivial.            | captcha, help, system        |
| `types.py`        | When you need dataclasses/enums shared in-module.| captcha                      |
| `models.py`       | When the module persists anything.               | chats                        |
| `__init__.py`     | Empty — just makes it a package.                 | every module                 |

The split exists for one reason: keep telebot out of the logic. `service.py`
should be testable with a fake or no telegram present. `bot_connector.py`
holds the parts that genuinely need `AsyncTeleBot`, `Message`, `CallbackQuery`.

`chats` is the cleanest example of the split. `captcha` is the
realistic example — its connector is large because the join flow is the
logic.

## What `module.py` has to do

Subclass `Module` and set the class attributes:

- `name` — short lowercase, unique. Used as the DI key inside `ModuleList`
  and as the prefix in callback payloads if you need one.
- `str_name` — human label for `/help`.
- `is_system = True` if it's an owner-only operational module
  (`system` is the only current case).
- `depends_on = ("other_name", ...)` — currently informational only. It
  helps the next person reordering `MODULE_CLASSES`.
- `models = (Foo, Bar)` — peewee classes from your `models.py`. They'll
  be passed to `db.create_tables` automatically.

Implement:

- `__init__` — build the service (synchronous only — no DI lookups; other
  modules aren't registered yet at this point).
- `init()` — `async`. This is where you can `di.get(...)` for the bot,
  config, or other modules. Build the connector, call its `register(bot)`.
- `help()` — return a Russian help string with MarkdownV2 escaping, or
  `None` to hide from `/help`.
- `debug()` — return a short status string. The leading line is
  conventionally `[ModuleName]` with one bullet per fact. Look at
  `CaptchaModule.debug` and `ChatsModule.debug` for the in-house style.

Finally: add your class to `MODULE_CLASSES` in `src/app.py`. Order is
load order — put modules others depend on first.

## What `bot_connector.py` looks like

The codebase's convention:

```python
class FooBotConnector:
    def __init__(self, service: FooService, owner_ids: list[int]) -> None:
        self._service = service
        self._owner_ids = owner_ids

    def register(self, bot: AsyncTeleBot) -> None:
        register_bot_command(bot, self._handle_foo, ["foo"], CommandAllowedIn.DM)
        register_bot_callback(
            bot,
            handler=self._handle_callback,
            func=lambda call: call.data and call.data.startswith("foo:"),
        )

    async def _handle_foo(self, message: Message, bot: AsyncTeleBot) -> None:
        ...
```

Use `register_bot_command` / `register_bot_callback` from
`src/connectors/telegram/utils.py` rather than calling the underlying
telebot APIs directly. They apply the chat-type filter and set
`pass_bot=True` so every handler has the same `(event, bot)` signature.

For owner-only commands, the first line of the handler is the gate:

```python
if not is_owner(message, self._owner_ids):
    return
```

Don't show an error — silent ignore is the chosen behaviour.

## What `service.py` looks like

Plain Python. Take dependencies in the constructor. Don't import from
`telebot`. Don't reach into `di` from the service if you can pass the
thing in — `CaptchaService` takes nothing at construction; `SystemService`
takes the log file path; only `HelpService` and the system service's
`collect_debug_info` use `di.get(ModuleList)` because they genuinely need
to introspect across modules.

If you persist anything: write through. The pattern in `ChatsService` is
to update the in-memory cache *and* run a `Model.update(...).where(...).
execute()` call. The codebase doesn't rely on peewee's "dirty field"
tracking. The `# pyright: ignore[reportAttributeAccessIssue]` comments
on `existing.last_message_at = now` are because peewee's descriptors
confuse pyright; the writes are fine.

## Registering callbacks: namespacing payloads

Callback queries are matched by predicate, not by name. The convention is
`"<verb>:<arg>"` and the predicate is `call.data.startswith("<verb>:")`.
`helpshow:captcha` is one example. There's also one pure-string payload
in use, `cleanup_message`, deliberately shared across modules so any
keyboard built anywhere can include a "Delete" button.

If you add a callback that another module's keyboard should be able to
fire, document it the way `help/bot_connector.py` does — a one-line
comment noting which module owns the handler.

## Models

Subclass `BaseModel` from `src/storage/database.py`. That gives you the
shared `db` and a `Meta.database` binding. Put a sensible `table_name` in
the inner `Meta` and a `CompositeKey` / `IntegerField` primary key if
you need one. Do *not* call `create_tables` from your module —
`app.py` does that after collecting `models` from every module.

## Minimal checklist

1. `src/modules/<name>/__init__.py` empty.
2. `service.py` with a class, no telebot import.
3. `module.py` subclassing `Module`, instantiating the service in
   `__init__`, building the connector in `init()`.
4. If you need handlers: `bot_connector.py`.
5. If you need user-facing text: `strings.py`.
6. If you persist anything: `models.py` with `BaseModel` subclasses,
   and a `models = (...)` tuple on the module class.
7. Add the class to `MODULE_CLASSES` in `src/app.py`.

That's it. There's no plugin discovery, no entry-point registry — the list
in `app.py` is the source of truth.
