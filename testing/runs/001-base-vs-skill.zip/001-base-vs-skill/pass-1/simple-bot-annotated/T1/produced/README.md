# simple-bot

A small, single-process Telegram group bot. It guards group joins with a
short captcha and ignores anyone who hasn't passed it. Beyond that it carries
a `/help` menu and a few owner-only operational commands (`/ping`, `/debug`,
`/sleep`).

This is the orientation doc. If you want the mental model, read
[`architecture.md`](architecture.md) next. If you're about to add a feature,
read [`module-pattern.md`](module-pattern.md). When things misbehave in
non-obvious ways, [`gotchas.md`](gotchas.md) is the cheat sheet.

## What it does (and doesn't)

It does:

- Watches a small number of Telegram groups it's been added to.
- When a new member joins, asks them a simple arithmetic / trivia question
  in Russian. Wrong answer or timeout → ban-then-unban (kick), so they have
  to be re-invited.
- After a user has sent a few real messages, marks them as a known member
  and stops challenging them on future re-joins.
- Responds to `/help` in DM with an inline keyboard listing the modules.
- Lets owners (`owner_ids` in config) ping it, dump per-module debug info,
  and put one instance to sleep so a second instance can take over polling.

It does not:

- Run multiple workers, scale horizontally, or expose any HTTP surface.
- Persist captcha state across restarts. If you restart mid-challenge, the
  challenge is gone; the new member is back to "unknown" until they send
  `MESSAGES_TO_BE_KNOWN` messages.
- Authenticate anything beyond a hard-coded `owner_ids` list.

## Running it

Requirements:

- Python 3.14 (pinned in `pyproject.toml`).
- A Telegram bot token from BotFather.
- `uv` for dependency management. `uv sync` installs everything including
  the dev group.

Then:

1. `cp config.example.json config.json` and fill in at least `tg_token`. Add
   your Telegram numeric user ID to `owner_ids` if you want the
   `/debug`/`/ping`/`/sleep` commands.
2. `uv run python -m src.app`.

The bot uses long polling (`infinity_polling`). No webhook setup, no public
endpoint. SQLite lives at whatever path `db.path` points to, with WAL mode
on.

## Repo layout in one screen

```
src/
  app.py                       entry point: load config, init DB, build modules, start polling
  core/
    config.py                  AppConfig dataclass + JSON loader
    di.py                      tiny dict-backed DI registry + ModuleList wrapper
    module.py                  Module ABC — what every module must provide
    strings.py                 globally-shared UI strings
  connectors/telegram/
    bot.py                     AsyncTeleBot factory (optional proxy)
    utils.py                   register_bot_command / register_bot_callback helpers
  storage/database.py          peewee SqliteDatabase + BaseModel
  modules/
    captcha/                   join-time challenge, in-memory state
    chats/                     per-(chat,user) presence tracking, only persistent module
    help/                      /help menu with module buttons
    system/                    /ping /debug /sleep for owners
```

Every module under `src/modules/` follows the same shape: `module.py`,
`service.py`, optional `bot_connector.py`, optional `strings.py`,
`types.py`, `models.py`. [`module-pattern.md`](module-pattern.md) explains
the split.

## Configuration in one screen

`config.json` keys (see `config.example.json` for the literal form):

- `tg_token` — required.
- `bot_username` — currently unused at runtime but read from config.
- `db.path` — SQLite file location. Created on first run.
- `debug_chats` — chat IDs that get a "simplebot started" notice on boot.
  Failures are silently swallowed.
- `owner_ids` — gates `/ping`, `/debug`, `/sleep`, and the "system" tab in
  `/help`.
- `proxy` — optional, passed to `telebot.asyncio_helper.proxy`.
- `log_level`, `log_file` — `log_file` is read by `/debug` for the recent
  log tail; nothing in this codebase actually writes to it. If you want
  logs in the file, configure logging yourself.
- `captcha.challenge_time` — seconds a new joiner has to answer. Default 15.

## Where to look when…

- A command isn't firing → `src/connectors/telegram/utils.py` for the
  command/callback registration, then the relevant module's
  `bot_connector.py`.
- A new joiner is being challenged when they shouldn't be (or vice versa)
  → `src/modules/captcha/bot_connector.py::handle_join`.
- A joiner passed captcha but is still being treated as unknown →
  `src/modules/chats/service.py::touch`. They need
  `MESSAGES_TO_BE_KNOWN` (= 3) messages.
- Owner commands silently doing nothing → `is_owner` check at the top of
  every `_handle_*` in `src/modules/system/bot_connector.py`. Your user ID
  isn't in `owner_ids`.
