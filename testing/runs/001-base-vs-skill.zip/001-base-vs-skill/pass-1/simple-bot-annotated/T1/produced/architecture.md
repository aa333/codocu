# Architecture

The bot is one async process. There are four moving parts you have to hold
in your head to read the code without re-deriving the design every time:

1. **A DI registry** — a global dict keyed by type, so any module can
   resolve any other (and the bot, and the config) by importing
   `src.core.di` and calling `di.get(...)`.
2. **Modules** — self-contained units of functionality. Each one registers
   itself, its DB models, and its message handlers.
3. **One Telegram polling loop** — `bot.infinity_polling()` in `app.py`.
   Every callback the modules register hangs off this single bot.
4. **A captcha gate sitting in front of group messages** — the only piece
   of cross-cutting logic that lives directly in `app.py` rather than
   inside a module's handler.

## Startup, in the order things actually happen

`src/app.py::main` is short. The order matters and it's worth reading
once with this map in hand:

1. `load_config()` parses `config.json` into a frozen `AppConfig`.
2. `init_db(path)` initialises the global peewee `SqliteDatabase` with
   WAL and `foreign_keys=1`, then opens it. Tables don't exist yet.
3. `create_bot(token, proxy)` builds an `AsyncTeleBot`. Proxy is set
   via a module-global on `telebot.asyncio_helper` (see gotchas).
4. The `AppConfig` and `AsyncTeleBot` are registered into the DI
   container so any module can pull them with `di.get(AppConfig)` etc.
5. Every entry in `MODULE_CLASSES` is instantiated and registered by its
   concrete type. A `ModuleList` wrapper is also registered so consumers
   can iterate all modules generically (used by `/help` and `/debug`).
6. **Then** `db.create_tables(...)` is called with the union of every
   module's `models` tuple. Modules don't create their own tables —
   `app.py` does it after collecting them.
7. Each module's `init()` is awaited in declaration order. This is where
   a module is allowed to `di.get(...)` other modules, build its
   connector, and register its handlers.
8. The two top-level handlers (`handle_message`, `handle_new_member`)
   are registered. They live in `app.py` because they need to coordinate
   between captcha and chats.
9. `infinity_polling` runs until killed.

The order matters because:

- A module's `__init__` cannot call `di.get` for another module — that
  module may not be registered yet. Lookups must happen in `init()` (or
  later, inside handlers).
- `db.create_tables` has to see every module's models, but only after
  modules are instantiated and only before `init()` would query them.

## The Module contract

`src/core/module.py` defines the ABC. Required surface:

- `name` — short, lowercased, used as the key in `ModuleList`.
- `str_name` — human label shown in the `/help` keyboard.
- `is_system` — `True` hides it from non-owners in `/help`.
- `depends_on` — declarative only. Not enforced; a hint to whoever
  reorders `MODULE_CLASSES`.
- `models` — peewee model classes for `db.create_tables`. Default `()`.
- `init()` — `async`. Resolve cross-module deps, build connectors,
  register handlers.
- `help()` → `str | None`. `None` hides the module from `/help`.
- `debug()` → `str`. Shown in `/debug` output. Can be sync or async; the
  system module awaits the result if it's a coroutine.

Modules in this repo follow a consistent internal split:

```
module.py          glue: subclass Module, hold service + connector, expose Module surface
service.py         pure-ish business logic. No telebot imports if avoidable.
bot_connector.py   adapts service to telebot — handlers, keyboards, message sends.
strings.py         user-facing text (Russian).
types.py           dataclasses and enums shared inside the module.
models.py          peewee models if the module persists anything.
```

Only `chats` has a real `models.py`. Only `captcha` has a `types.py`.
The pattern is described in [`module-pattern.md`](module-pattern.md).

## Message dispatch

There are two layers of handlers, registered with the same telebot
mechanism but doing different jobs.

**Top-level handlers in `app.py`** are content-type-based and unconditional.
They fire for *every* group message and every `new_chat_members` event:

- `handle_message` — runs on text/photo/video/document/sticker/voice/audio.
  Group-only. Inside it:
    1. If the sender currently has an active captcha challenge,
       `captcha.verify_answer` is called and nothing else happens.
       This is the captcha gate.
    2. Otherwise `chats_svc.touch(message)` records presence.
- `handle_new_member` — runs on the `new_chat_members` content type and
  delegates straight to `captcha.handle_join` for the *first* new member
  only.

**Module-level handlers** are registered inside each module's `init()` via
the helpers in `src/connectors/telegram/utils.py`:

- `register_bot_command(bot, handler, ["foo"], CommandAllowedIn.DM)` —
  registers `/foo` and applies a chat-type filter so the command only
  fires in the allowed chat type. `DM` for `/help`, `/ping`, `/debug`,
  `/sleep`. The default is `Group` if you forget to pass one.
- `register_bot_callback(bot, handler, func)` — registers a
  callback-query handler with a custom predicate. The codebase uses
  string-prefix predicates (e.g. `call.data.startswith("helpshow:")`).

Both helpers pass `pass_bot=True`, so every handler signature is
`(message_or_call, bot)`.

Telebot doesn't deduplicate handlers, so it's fine for two modules to
register a callback handler for the same payload by matching different
predicates. `captcha` and `chats` both react to `left_chat_member` events
this way — captcha aborts an ongoing challenge for the leaver, chats marks
them as out.

## The captcha gate (and why it's at the top)

When a user is mid-challenge, *any* message they send is treated as their
answer. That's enforced by the early-return in `app.py::handle_message`:

```python
if message.from_user and captcha.has_ongoing(chat_id, user_id):
    await captcha.verify_answer(bot, message)
    return
```

The `return` is load-bearing. Without it, `chats_svc.touch` would count
an in-progress captcha attempt as a "real" message and start promoting
the not-yet-verified user to known. Captcha state is in-memory only
(`CaptchaService._challenges` is a list); a restart loses it.

A new joiner is challenged unless one of these short-circuits in
`CaptchaBotConnector.handle_join` matches:

- The joiner is a bot → welcomed without challenge.
- The joiner was added by someone else → `SKIPPED` (we only challenge
  self-joins).
- The joiner is already "known" in `chats` (re-join case) → skipped.
- The join event is more than `CAPTCHA_OUTDATED_TIMEOUT` (45s) old at
  the time we see it → skipped, with a polite note if they're still in.

Otherwise a question is picked from `strings.QUESTIONS`, sent as a reply,
and a `CaptchaChallenge` is created. A loop ticks down `time_left` every
second until the challenge passes, is aborted (user left), or expires.
Expiry → ban + tiny sleep + unban (kick). The sleep is deliberate; see
`gotchas.md`.

## Persistence

Only `chats` writes to the database. The model is `ChatMembership`, keyed
on `(chat_id, user_id)`, with `in_chat`, `registered_at`, and
`last_message_at`. The service keeps an in-memory cache loaded once at
init from the DB, and writes through to the DB on `touch`/`mark_left`.

Promotion to "known" is gated by `MESSAGES_TO_BE_KNOWN` (= 3) real
messages, tracked in a separate in-memory `_watch` dict that does *not*
survive restarts. If you restart while a new user has sent 2 messages,
they're back at 0 — captcha will challenge them again on next join.

## Cross-module conventions you'll see

- `cleanup_message` is a shared callback payload. `HelpBotConnector`
  builds keyboards with a "Delete" button carrying `callback_data=
  "cleanup_message"`. `SystemBotConnector` is the *only* place that
  registers the handler for it. This is deliberate — see the comment in
  `help/bot_connector.py`.
- Shared UI strings (`BTN_DELETE`, `MSG_DELETED`, `random_no()`) live in
  `src/core/strings.py`. Module-specific strings live in each module's
  `strings.py`.
- Owner gating is duplicated at each handler entry (`if not
  is_owner(...): return`) rather than wrapped in a decorator. The split
  between system-only and shared modules in `/help` is also done by
  filtering on `Module.is_system`.
