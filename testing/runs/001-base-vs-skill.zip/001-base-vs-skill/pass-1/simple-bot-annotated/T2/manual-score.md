# Manual Score — T2 / simple-bot-annotated

Tier: T2 (+ principles.md + doc-standard.md).
Produced: under `produced/docs/`: `README.md`, `architecture.md`, `modules.md`, `captcha-flow.md`, `conventions.md`, `config.md`, `tech-debt.md`.

Fill each entry below. Do not let the judge or metrics influence the score
— record what the doc reads like to you.

## 1. Principle adherence — does each sentence say something code can't?

Score (1–5):
Notes:

## 2. Refactor resistance — would this survive a rename, extract, or inline?

Score (1–5):
Notes:

## 3. Bloat — judged against a minimum-viable mental version of the same doc

Score (1–5, 5 = lean, 1 = bloated):
Notes:

## 4. Code-restating sentences

List specific sentences with file + approximate line / section. One per bullet.

-

## 5. Voice — busy-tired-reader, or reference material?

Score (1–5, 5 = busy-reader, 1 = reference):
Notes:

## METADOCU agreement

Ground truth: `testing/fixtures/full/simple-bot-annotated-reference/`.

Of the N annotation-flagged issues in that reference, how many does this run:

- reproduce (made the same mistake):
- avoid (the doc handles it correctly):
- introduce new (the doc adds an issue the reference doesn't):

Notes:
