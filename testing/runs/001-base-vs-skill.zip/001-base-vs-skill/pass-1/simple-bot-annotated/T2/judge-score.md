# Judge Score — T2 / simple-bot-annotated

## Scores (1–5 each, one-sentence justification)

1. **Principle adherence** — **4.5**: Nearly every sentence explains rationale, intent, or cross-cutting invariants that the code cannot self-document; a few spots (the `MESSAGES_TO_BE_KNOWN` mechanic in modules.md, the step-by-step "adding a key" recipe in config.md, parts of the `cleanup_message` contract description) drift toward narrating what the code does.

2. **Refactor resistance** — **4**: Most prose survives renames because it talks about reasons and contracts, but several anchors (`ChatsService.touch`, `CaptchaModule.has_ongoing`, `_run_challenge`, `MESSAGES_TO_BE_KNOWN`, `_handle_left_member`, `revoke_messages=False`, `_cache`) would silently rot if those identifiers move.

3. **Bloat** — **3.5**: Cohesive and on-topic, but the seven-file set is denser than a minimum-viable mental version — the README index, "What this bot is not" list, the two-phase recap in conventions.md, and the prose enumeration of every config key inflate it noticeably.

4. **Voice** — **4**: Reads conversationally with named choices and consequences ("Keep this sleep", "The hard module", "you've removed an invariant"), though config.md and parts of modules.md tip into reference cadence.

## Code-restating sentences

- "`src/core/module.Module` is the contract. A module declares its identity (`name`, `str_name`), an optional list of peewee models, optional cross-module dependencies, and implements `init`, `help`, `debug`." — `architecture.md` / The module shape. This is the class signature spelled out in prose; a rename of any of those attributes invalidates the sentence and the code already declares them.

- "Inside a module directory the same three files keep recurring: `module.py` ... `service.py` ... `bot_connector.py` ..." — `architecture.md` / The module shape. The filesystem layout is observable by `ls`; the doc-worthy part (separation of IO from decisions) is the next paragraph.

- The numbered six-step startup list in `architecture.md` / Startup: two phases. Steps 1, 2, 4, 5 transcribe the sequence in `app.py:main`; the load-bearing insight ("the two phases exist for one reason…") is in the paragraph below and could stand without the enumeration.

- "`ChatsService.touch` keeps an in-memory counter and only inserts a row once the counter reaches `MESSAGES_TO_BE_KNOWN`." — `modules.md` / chats. Names a method and a constant and restates the threshold logic; the rationale sentence that follows is what's actually doc-worthy.

- "`CaptchaModule` exposes three methods directly (`has_ongoing`, `verify_answer`, `handle_join`) because…" — `modules.md` / captcha. The method list is a test assertion (`hasattr`); the "because" clause is the only part code can't say.

- "`/ping` (host + uptime), `/debug` (aggregated `debug()` output from every module + memory stats), `/sleep N` (block the event loop for N seconds…)" — `modules.md` / system. Command-output enumeration that the help text and code already produce.

- "A new-member event goes to `handle_join`, which decides whether to bother with a challenge. We **skip** if: ... The new member is a bot ... The joiner is not the user who triggered the join event ... The user is already 'known' ..." — `captcha-flow.md` / When we challenge. The skip predicates are exactly the `if`-branches in `handle_join`; they'd read as test assertions.

- "When the budget runs out, we ban the user with `revoke_messages=False` and then immediately unban." — `captcha-flow.md` / The ban / unban race. Restates the two API calls and a kwarg; the doc-worthy content is the sleep-between-them rationale in the next paragraph.

- "1. Add the field to the appropriate dataclass in `core/config.py`. ... 2. Read it from the JSON in `load_config`, applying the default with `.get(...)` ... 3. Update `config.example.json`." — `config.md` / Adding a new key. A mechanical recipe a competent reader derives by skimming `load_config`.

- The bullet list of every config key in `config.md` / What each key is for. `tg_token`, `db.path`, `debug_chats`, `owner_ids` are largely self-describing from the dataclass; the entries that earn their keep are `proxy`, `log_level` (paired with tech-debt), `log_file`, and `captcha.challenge_time` — the others are reference material that belongs generated.

- "When invoked, it: 1. Confirms the caller is the user who originally typed the command ... 2. Deletes both the bot's reply and the command message." — `conventions.md` / The `cleanup_message` contract. The numbered steps transcribe the callback body; the contract (any module can emit the button) is the only non-code-restating part.

- "`debug()` reaches into a private attribute (`self.service._cache`) to count tracked memberships." — `tech-debt.md` / `ChatsModule.debug` reads `service._cache` directly. Names a private attribute that's likely to be the first thing renamed when the smell is fixed; the doc rots itself.

## Overall verdict

The strongest move is that this set knows *why* simple-bot is shaped the way it is and is willing to say it out loud: the two-phase wiring rationale, the ban/unban race with its empirical sleep, the "three-message rule" motivation, the cleanup_message cross-module contract, and the tech-debt entries that distinguish intentional rough edges from real bugs are all things `pytest` and the source can't tell a new reader. Voice is busy-reader friendly, and the README does a real job of orienting before drilling. The worst failure mode is creeping transcription: when the author has finished saying the irreplaceable thing, they keep going and re-narrate the code — the startup numbered list, the `When we challenge` skip-predicate bullets, the `Adding a new key` recipe, and the full config key enumeration are all places where the doc accumulates sentences that would read as test assertions and that will drift the moment someone refactors. The result is a doc set that is dense with insight but carries roughly 25–30% material that doesn't earn its line on the rename test.
