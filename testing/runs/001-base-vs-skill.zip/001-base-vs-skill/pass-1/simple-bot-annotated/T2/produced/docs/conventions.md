# Conventions

Agreements that are not enforced by code but matter across the codebase.

## Owner gating

Several commands are owner-only. The pattern is uniform: at the top of the
handler, call `is_owner(message, self._owner_ids)`; on `False`, return
silently (no error reply — non-owners shouldn't even know the command
exists). `owner_ids` comes from config and is passed into each
`BotConnector` constructor.

The gate lives in the **connector**, not the service. Rationale: services
operate on already-authorised data; pushing gates down into them would
mean every service method has to take a "who is asking" parameter, which
is a Telegram concern leaking through.

The help module has a parallel notion: `Module.is_system = True` hides a
module from non-owner views of `/help`. These are coupled — if you mark a
module as system, its connector should also `is_owner`-gate its commands.

## The `cleanup_message` contract

`SystemBotConnector` registers a single callback that matches
`call.data == "cleanup_message"`. When invoked, it:

1. Confirms the caller is the user who originally typed the command (the
   "command author"), reading `call.message.reply_to_message`. If not, it
   answers with a flavourful refusal and does nothing.
2. Deletes both the bot's reply and the command message.

Any module that wants to render a "Delete" button on its output just emits
a button with `callback_data="cleanup_message"`. Help does this. System
does this. There is no other registration needed — the system module owns
the implementation, every other module is a client.

If you ever remove the system module, this contract breaks silently
(buttons appear but do nothing).

## Strings: per-module, Russian, hardcoded

Every module that produces user-facing text owns a `strings.py` next to
its `module.py`. There is no i18n layer — translation is a non-goal. Two
things in core `src/core/strings.py` are shared because they appear in
multiple modules' replies (`Удалить` button, refusal phrases).

When you add user-facing copy:

- Put it in the module's own `strings.py`, not `core/strings.py`. Only
  move something to `core/strings.py` once two modules need it.
- Keep MarkdownV2 escaping at the point of formatting, not in the string
  constant. `help/bot_connector` uses `escape_markdown` on the help
  payload it injects — string constants stay readable.

## Avoid `from telebot.x import ...` at module top in `module.py`

`Module` subclasses do `from telebot.async_telebot import AsyncTeleBot`
inside `init()` rather than at the top of the file. This is to keep
`module.py` importable without the bot client being available — useful
for tests and for tooling that just wants to enumerate modules. The
service files do the same when they can.

`bot_connector.py` files freely import telebot at module top — they are
the Telegram boundary.

## `pass_bot=True` and the type ignore

All handler registrations use `pass_bot=True`, which changes the runtime
callback signature to `(message_or_call, bot)` but is not modelled in
pytelegrambotapi's type stubs. Every registration carries
`# pyright: ignore[reportArgumentType]`. This is intentional, not a bug to
fix; the alternative is closing over `bot` and losing testability.

## Two-phase wiring (recap, since it's load-bearing)

Inside a `Module` subclass, `__init__` is for in-process state that peers
might want to reference. `init()` is for everything else: DI lookups,
connector construction, handler registration, cache loads. Don't call
`di.get` from `__init__`.
