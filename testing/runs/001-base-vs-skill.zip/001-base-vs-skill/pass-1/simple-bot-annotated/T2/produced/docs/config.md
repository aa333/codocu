# Configuration

Runtime config is loaded once at startup from `config.json` in the working
directory. `config.example.json` ships with the repo and shows every key.

`AppConfig` and its nested dataclasses are frozen — the configuration is
immutable for the lifetime of the process. To change config, edit the
file and restart.

## What each key is for

- **`tg_token`** — Telegram bot token from BotFather. Required.
- **`bot_username`** — currently unused at runtime but read into config so
  it survives future use without a migration. May be `null`.
- **`db.path`** — path to the SQLite file. Defaults to `simple_bot.db`.
  The schema is created on startup from every module's `models` tuple.
- **`debug_chats`** — chat IDs that get a "simplebot started" line when
  the bot boots. Failures sending it are swallowed; an offline debug chat
  shouldn't prevent startup.
- **`owner_ids`** — Telegram user IDs allowed to run owner-only commands
  (`/ping`, `/debug`, `/sleep`) and see the `system` module in `/help`.
- **`proxy`** — optional `http(s)://...` proxy URL passed to
  pytelegrambotapi's global `asyncio_helper.proxy`. Set when running
  behind a forced proxy; leave `null` otherwise.
- **`log_level`** — accepted into config but **not currently applied** to
  Python logging. See `tech-debt.md`.
- **`log_file`** — path read by `/debug`'s log-tail support inside
  `SystemService.get_recent_logs`. Defaults to `bot.log`. The bot does not
  itself write to this file — your process supervisor or logging config
  does. If the file isn't there, `/debug` just skips the log section.
- **`captcha.challenge_time`** — seconds a new joiner has to answer the
  captcha. Defaults to 15. Lower values are harsher; higher values give
  more room to humans but also to bots that solve slowly.

## Adding a new key

1. Add the field to the appropriate dataclass in `core/config.py`. Give it
   a default if it should be optional.
2. Read it from the JSON in `load_config`, applying the default with
   `.get(...)` so old config files still load.
3. Update `config.example.json`.
4. Add a row above describing what it does and why.
