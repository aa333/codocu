# Modules

Each module owns one concern. They are listed in the order they appear in
`MODULE_CLASSES` (which is the order they `init()` in).

## chats — presence tracking

Tracks, per group chat, which users we've seen and whether they are
currently in the chat. Persists to SQLite via the `ChatMembership` model.

The interesting design choice is **the three-message rule**: a user is not
"known" after the first message. `ChatsService.touch` keeps an in-memory
counter and only inserts a row once the counter reaches
`MESSAGES_TO_BE_KNOWN`. The reason is captcha: once a user is "known",
captcha skips them on re-join. We don't want a single hit-and-run message
to bypass future captcha challenges, so we wait until they've spoken a few
times.

Used by captcha (`is_known` decides whether to challenge a returning user)
and by no one else right now.

No bot_connector — `chats` doesn't own any commands or callbacks. It
registers exactly one handler (left-chat-member) directly from
`ChatsModule.init`.

## captcha — gate for new joiners

The hard module. New joiner gets a question, must answer within
`config.captcha.challenge_time` seconds. Pass → welcome. Time out → ban
and immediately unban (Telegram's way of saying "kicked, may rejoin").
Leaves the chat → challenge aborted. See `captcha-flow.md` for the full
lifecycle and the race condition `_run_challenge` works around.

`CaptchaModule` exposes three methods directly (`has_ongoing`,
`verify_answer`, `handle_join`) because `app.py` calls them inline from
the global message handler — captcha needs to intercept messages *before*
the normal dispatch chain. The connector's own handlers only cover the
`left_chat_member` event.

Depends on `chats` to ask "have we seen this user before?".

## help — discoverable command index

`/help` (DM only) opens an inline keyboard of every module that returns
non-None from `help()`. Tapping a module replaces the message body with
that module's help text.

Two non-obvious bits:

- **Owner-gated visibility.** Modules with `is_system = True` (currently
  only `system`) are hidden from non-owners. The keyboard, the
  `is_accessible` check, and the inline-callback flow all consult
  `owner_ids` from config. See `conventions.md` for why the gate lives in
  the connector rather than the service.
- **Cleanup-message button.** Every help keyboard includes a
  `cleanup_message` callback button. That callback is *registered by
  SystemBotConnector*, not by help — see `conventions.md` "cleanup_message
  contract".

`HelpService.get_available_modules` reaches into `ModuleList` to enumerate
peers. It's the canonical example of a module reading the whole module
graph.

## system — operator commands

Owner-only commands for the bot operator: `/ping` (host + uptime),
`/debug` (aggregated `debug()` output from every module + memory stats),
`/sleep N` (block the event loop for N seconds — used to hand polling off
to a sibling instance during a deploy). Marked `is_system = True` so its
`/help` entry is hidden from non-owners.

`SystemService.sleep` deliberately uses **blocking `time.sleep`**, not
`asyncio.sleep`. The whole point is to make polling stop so another
instance can pick up; an async sleep would yield the loop and continue
processing updates. See `tech-debt.md` for the consequence (no other
handlers can run during sleep).

Also owns the `cleanup_message` callback registration — the shared
"delete this and the command that produced it" button used by `/help` and
`/debug`.
