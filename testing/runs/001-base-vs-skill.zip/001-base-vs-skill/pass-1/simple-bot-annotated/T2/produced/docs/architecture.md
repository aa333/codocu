# Architecture

simple-bot is a Telegram group bot built around one shape: a **module**.
Every feature — captcha, chat tracking, help, system commands — is a module
that the entrypoint loads, wires through a shared DI container, and lets
register its own Telegram handlers. Adding a feature means adding a module;
the entrypoint does not change.

## The module shape

`src/core/module.Module` is the contract. A module declares its identity
(`name`, `str_name`), an optional list of peewee models, optional cross-module
dependencies, and implements `init`, `help`, `debug`.

Inside a module directory the same three files keep recurring:

- **`module.py`** — the `Module` subclass. Holds wiring, not logic.
- **`service.py`** — pure business logic. No Telegram imports. Easy to test.
- **`bot_connector.py`** — the Telegram boundary. Translates Telegram events
  into service calls and service results back into Telegram replies.

Not every module needs all three — `chats` has no bot_connector because it
only exposes a service to its peers, and `help` has no models because it
keeps no state. The split is a guideline, not a framework rule: keep IO in
`bot_connector`, keep decisions in `service`, and the rest follows.

The reward for this split is that captcha's matching logic, chat's presence
tracking, and system's uptime/sleep accounting are all testable without a
Telegram client.

## Startup: two phases

`src/app.py:main` runs startup in a deliberate order:

1. Load config, init the SQLite database, create the Telegram client.
2. Register `AppConfig` and the bot client in DI.
3. **Construct every module.** This only runs `__init__`, which sets up
   in-process state. No DI lookups, no handler registration.
4. Register every module instance in DI, keyed by its concrete class. Also
   register a `ModuleList` so a module can iterate or look up its peers
   by `name`.
5. Create database tables for every model declared across modules.
6. **Call `init()` on every module, in `MODULE_CLASSES` order.** This is
   where modules resolve peers via `di.get(...)`, build their connectors,
   and call `bot.register_message_handler(...)`.

The two phases exist for one reason: a module's `init()` may pull *any*
other module out of DI. By the time `init` runs, every peer is constructible
but not yet initialized — so peers must be safe to *reference* before any of
them are initialized. In practice that means a module exposes its `service`
as a plain attribute on `__init__`, and only relies on the connector wiring
inside `init()`. Captcha does this: it stores `self.service` in `__init__`
so `ChatsModule.init()` could call into it, even though by convention only
the reverse direction is used here.

A consequence: `depends_on` is documentation only — the actual init order
is the order modules appear in `MODULE_CLASSES`. See `tech-debt.md`.

## Message flow

```
Telegram → AsyncTeleBot → (registered handler) → bot_connector → service
```

The entrypoint registers two top-level handlers itself, before any
module-registered ones run:

- **All content types** → `handle_message`. Group chats only. If the
  sender currently has an active captcha challenge, route the message to
  `captcha.verify_answer` and stop — they cannot do anything else until
  they pass or time out. Otherwise, hand the message to `chats_svc.touch`
  to update presence.
- **`new_chat_members`** → `handle_new_member`. Always forwarded to
  `captcha.handle_join`.

Module-registered handlers (commands, callbacks, `left_chat_member`) run
through the normal pytelegrambotapi dispatch, which iterates handlers in
registration order. Order between modules' handlers therefore tracks
`MODULE_CLASSES` order.

## DI: deliberately tiny

`src/core/di.py` is a dict from type to instance. No scopes, no lazy
construction, no autowiring. Register at startup, `get(T)` anywhere.

This works because the bot has one instance per process and modules are
singletons. The DI is doing two things only:

- breaking the import cycle between `app.py` and modules without resorting
  to globals scattered across files;
- letting a module fetch a peer by class without knowing where it was
  constructed.

`ModuleList` is a typed wrapper so that modules can iterate "all modules"
(used by `/debug` and `/help`) without each call site needing a `cast`.
