# Captcha flow

The captcha module is the only place in the bot with non-trivial concurrency
and remote-API choreography. The reasons behind a few of its choices aren't
obvious from the code.

## When we challenge

A new-member event goes to `handle_join`, which decides whether to bother
with a challenge. We **skip** if:

- The new member is a bot. (Bots can't read captions and shouldn't be
  punished for it. We post a welcome line and move on.)
- The joiner is not the user who triggered the join event. This filters out
  "user A added user B" — A is the actor, B is the new member. We only
  challenge self-joins so we don't punish people for being invited.
- The user is already "known" in this chat per `ChatsService.is_known`.
  Known means they previously spoke at least `MESSAGES_TO_BE_KNOWN` times.
  A returning member shouldn't have to prove they're human again.
- The join event arrived **late**. If we receive a new-member update more
  than `CAPTCHA_OUTDATED_TIMEOUT` seconds after the event happened, we
  assume the bot was offline (deploy, sleep, restart) and the user has
  effectively already been a member. We post a one-line "outdated" note
  if they're still in the chat and stop.

The "outdated" handling exists because `/sleep` deliberately blocks the
event loop during deploys (see `modules.md` → system). When we wake up,
the join queue can have minutes-old events. Challenging then would be
both unfair and useless.

## Running a challenge

A random `(question, answer)` pair from `strings.QUESTIONS` is posted as a
reply to the join message. The challenge is recorded in `CaptchaService`
with the configured time budget. A coroutine ticks the budget down once a
second, watching for state transitions.

Three things can end the loop:

- The user answers correctly. `verify_answer` (called from `app.py`'s
  global message handler, *not* from a registered captcha handler) sets
  status to `PASSED`.
- The user leaves the chat. `_handle_left_member` (registered by captcha)
  sets status to `ABORTED`.
- The budget runs out.

The captcha service holds a list of challenges, keyed by `(chat_id,
user_id)`. The polling loop checks the *challenge object's* status, not
the service — so any caller that mutates the status (verify, abort) is
immediately visible.

## Why the message handler is hooked from `app.py`

A passing answer is just a regular text message. If we registered captcha
as one handler among many, pytelegrambotapi would call every matching
handler, meaning `ChatsService.touch` would also fire — incrementing the
user's "known" counter on a message that should not count.

To intercept cleanly, `app.py` checks `captcha.has_ongoing(...)` at the
top of its message handler and routes the message to `verify_answer`
directly, *returning* before any other logic runs. This is why
`CaptchaModule` exposes `has_ongoing` and `verify_answer` as public
methods.

## The ban / unban race

When the budget runs out, we ban the user with `revoke_messages=False`
and then immediately unban. On Telegram, ban+unban is the kick gesture:
the user is removed and may rejoin freely.

Between the two calls there's a deliberate `asyncio.sleep(1)`. The reason
is documented inline at the call site — without the gap, the unban request
can race the ban on Telegram's side. The unban uses `only_if_banned=True`,
which silently no-ops if the ban hasn't been committed yet, leaving the
user permanently banned. The one-second pause is empirically enough.

Keep this sleep. Removing it looks like a tightening but reintroduces the
bug.

## Cleanup

When a challenge ends (any outcome), the captcha message itself is deleted.
The challenge record is removed from the service's list. If deletion fails
(message already gone, no permission) we swallow the exception — the
challenge result is what matters.
