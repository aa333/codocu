# simple-bot docs

A simplified Telegram group bot. New joiners pass a captcha; the bot
tracks who has spoken in which chat; owner-only commands cover help, debug
output, and deploy handoff.

This directory is for things the code can't say on its own — why pieces
exist, how they fit together, decisions that shaped them, known rough
edges. Behaviour lives in the code.

## Where to start

- **[architecture.md](architecture.md)** — the module shape, the DI
  container, the two-phase startup, the message flow. Read this first.
- **[modules.md](modules.md)** — what each module is for and why.
- **[captcha-flow.md](captcha-flow.md)** — the only piece with non-trivial
  concurrency. Read before changing anything in `modules/captcha/`.
- **[conventions.md](conventions.md)** — owner gating, the
  `cleanup_message` cross-module contract, string organisation.
- **[config.md](config.md)** — every config key, and how to add one.
- **[tech-debt.md](tech-debt.md)** — known smells. Read before "fixing"
  things that look wrong.

## What this bot is not

- Not multi-lingual. Strings are Russian, hardcoded per module.
- Not multi-tenant. One process, one Telegram token, one SQLite file.
- Not a behavioural spec. These docs deliberately do not enumerate every
  command's output — `pytest` and the code do that better.
