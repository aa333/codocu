# Tech debt and known smells

Things that are real but not a priority to fix. Recorded so a new reader
can tell intentional rough edges from actual bugs.

## `Module.depends_on` is documentation only

`CaptchaModule.depends_on = ("chats",)` looks like a dependency
declaration but nothing reads it. The actual init order is the order
classes appear in `MODULE_CLASSES` in `src/app.py`. If you reorder that
list and put captcha before chats, captcha will still work today (because
chats only needs `init()` to load its cache, and captcha doesn't call
chats during *its own* `init`), but you've removed an invariant the code
quietly relies on.

Two ways out: either delete `depends_on` (don't promise what you don't
keep), or have `app.py` sort `MODULE_CLASSES` by it. Either is fine; the
current state is worse than both.

## Owner-gating is duplicated per handler

Every owner-only handler starts with the same `if not is_owner(...):
return` line. There is no decorator or filter wrapping this. Adding a new
owner-only command means remembering to copy the line; forgetting it is a
security bug.

A small `@owner_only` decorator or an `is_owner_func` kwarg into
`register_bot_command` would fix it. Untaken because there are only four
such handlers today.

## `log_level` config is read but ignored

`AppConfig.log_level` is parsed and stored but nothing configures Python
logging from it. The string sits in the dataclass for a future
`logging.basicConfig` call. Either wire it up or remove the field.

## `/sleep` blocks the entire event loop

This is by design — see `modules.md` system. The consequence is that
during a sleep, *no* handlers run (not just polling pauses). The whole
asyncio task is frozen. That's exactly the desired behaviour for handing
off polling between instances, but it makes `/sleep` unusable for any
other purpose. If you ever want a "back in N minutes" status that still
processes commands, this is the wrong primitive.

## DI is a process-global mutable dict

`_registry` in `src/core/di.py` is a module-level dict with no reset
hook. Tests that need a clean registry have to clear it themselves. Two
processes sharing this module in-process (e.g. parallel pytest workers)
would step on each other; today nothing does that.

## `ChatsModule.debug` reads `service._cache` directly

`debug()` reaches into a private attribute (`self.service._cache`) to
count tracked memberships. A `len(self.service)` or
`self.service.count()` would be cleaner. Trivial; not done.

## Captcha challenges live only in memory

If the bot restarts mid-challenge, in-flight challenges are lost. The
re-joining user will look like a "late join" event on next start
(`CAPTCHA_OUTDATED_TIMEOUT` covers most cases) but a user mid-challenge
during restart simply isn't re-challenged. Acceptable for now; persisting
challenges to SQLite would be the fix if it ever matters.
