# T2 Transcript — simple-bot-annotated

**Agent ID:** a01aeb4112cb8eba1
**Subagent type:** general-purpose
**Tokens:** 59976 total · 38 tool uses · 282479 ms

**Note:** Agent placed docs under `produced/docs/` (one extra `docs/` level) rather than directly under `produced/`. This was its own structural choice given the prompt was Codocu-flavored — the doc-standard names `docs/` as the home for system docs. Left as-is.

## Agent summary

Wrote seven docs under `produced/docs/`:

- **README.md** — orientation. What the bot is, what it isn't, which doc to read first.
- **architecture.md** — the module shape (module/service/bot_connector split), two-phase startup with rationale, message flow, and why the DI container is deliberately tiny.
- **modules.md** — per-module purpose-and-rationale: chats (the three-message rule and why), captcha (overview pointing to captcha-flow), help (owner gating, cleanup_message coupling), system (why `time.sleep` not `asyncio.sleep`).
- **captcha-flow.md** — the only piece with real concurrency. Skip conditions and their reasons (outdated joins exist because `/sleep` blocks the loop), the challenge state machine, **why the message handler is hooked in `app.py` rather than registered** (so chats.touch doesn't increment on captcha answers), and the ban/unban race with the load-bearing 1-second sleep.
- **conventions.md** — owner gating lives in connectors not services (with reasoning), the `cleanup_message` cross-module contract (system owns it, others emit it), per-module Russian strings as a non-goal, deferred telebot imports inside `module.py`, the `pass_bot=True` type-ignore is intentional.
- **config.md** — every config key with purpose and footgun, plus the recipe for adding a new one.
- **tech-debt.md** — `depends_on` is dead documentation, owner-gating is copy-pasted per handler, `log_level` is read-but-ignored, `/sleep` blocks everything (intentional), DI is process-global, captcha challenges are memory-only.

### Design choices behind the doc set

- **Refused to transcribe.** No "the `Module` class has these attributes" lists, no command-output catalogs, no input/output tables. Code already says that.
- **Wrote the why repeatedly.** Every non-obvious choice in the code (the 3-message rule, the 1-second ban/unban sleep, blocking `time.sleep`, capturing the message handler in `app.py`, two-phase init) gets its rationale, not its mechanics.
- **Multiple small files, not one monolith.** A new engineer reads README → architecture → the module they're touching. They don't have to scroll through irrelevant sections.
- **Named code symbols only where they co-change with the doc.** `MODULE_CLASSES`, `CAPTCHA_OUTDATED_TIMEOUT`, `MESSAGES_TO_BE_KNOWN` get named because the docs are *about* those decisions; the help keyboard's button structure is not named because it would drift on the next refactor.
- **Business words over code words** for everything reader-facing ("known user", "owner-gated command", "the gate", "the captcha message") even where a code term exists.
- **Tech-debt as first-class doc**, distinguishing intentional smells (`/sleep` blocking the loop) from real ones (`depends_on` dead, `log_level` unused) so readers don't "fix" load-bearing weirdness.
