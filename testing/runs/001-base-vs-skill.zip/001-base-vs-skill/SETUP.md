# Base-vs-Skill Eval — SETUP

The suite answers one question: **does Codocu's bloat and code-repetition
failure live in the base material or in the skill's behavior on top of it?**

Companion design: [`docs/plans/2026-05-25-base-vs-skill-eval-suite-design.md`](../../../docs/plans/2026-05-25-base-vs-skill-eval-suite-design.md).
Motivating prior art: [`PRIOR-FINDINGS.md`](PRIOR-FINDINGS.md) — the
bobatler init notes that triggered this suite.

## Fixtures

Two fixtures, both under `testing/fixtures/full/`. The agent under test is
pointed at the fixture root and told *"here's the project, work there"* —
no "do not look at X" clauses.

**`simple-bot-annotated/`** — Python. Full simplified project re-extracted
from `../bots/bobatler`: `src/`-rooted package with `app.py` entrypoint, DI
core, four modules (captcha/chats/help/system), storage, plus
`pyproject.toml` and `config.example.json`. Module-level summary
docstrings stripped; class/function/argument docstrings retained. Ships
with a paired `simple-bot-annotated-reference/` companion (METADOCU-
annotated; scorer-only) — so this fixture gets the METADOCU-agreement
score in addition to the always-on triangle.

**`obsidian-spotiplay/`** — TypeScript. Copied verbatim from
`../obsidian-spotiplay`, a small Obsidian plugin exposing Spotify playback
control via a custom markdown code block. 7 `.ts` files under `src/`,
plus `manifest.json`, `package.json`, `tsconfig.json`, `esbuild.js`, and
lint/format/CI config. The source `README.md` is intentionally omitted —
it is a complete narrative of what the plugin does, and including it
would feed the agent its own conclusion. No `-reference/` companion, so
METADOCU agreement does not apply; the five-criterion rubric still does.

Each fixture is frozen after creation. If a fixture proves bad, a new one
is created at a new name; the old is never edited.

## Tier ladder

Five cumulative tiers per cell. Each tier adds materials on top of the
previous tier's set.

| Tier | Materials | What it isolates |
|---|---|---|
| **T0** | Nothing Codocu. Generic prompt: *"Write aux docs for this code under `docs/`."* | The pretrained baseline. |
| **T1** | + `skills/codocu/references/principles.md` | Do the three principles alone steer behavior? |
| **T2** | + `skills/codocu/references/doc-standard.md` | Do operational rules lift over the principles? |
| **T3** | + `skills/codocu/references/smell-catalog.md` | Do named anti-patterns help recognize bloat? |
| **T4** | Full `/codocu` skill via plugin install. `/codocu:init` then `/codocu` against the fixture. | Marginal value of the skill scaffolding. |

T1–T3 deliver materials by injecting the files into the agent's initial
context — plain text, no skill scaffolding. The agent is told these are the
conventions, then asked to produce docs.

T4 is the real plugin invocation: `claude --plugin-dir <codocu-repo>`,
followed by the slash commands. Only this tier exercises the actual user
flow. The runner collects T4's produced docs from inside the fixture
working copy into the same `produced/` layout the other tiers use.

One run per cell to start. Variance test deferred. Opus 4.7 only at first.

## Scoring — three tracks

Every produced doc gets all three scores. Disagreement between tracks is
itself a signal.

### Manual rubric

| # | Criterion | Scale |
|---|---|---|
| 1 | Principle adherence — does each sentence say something code can't? | 1–5 |
| 2 | Refactor resistance — would this survive a rename, extract, or inline? | 1–5 |
| 3 | Bloat — judged against a minimum-viable mental version of the same doc. | 1–5 |
| 4 | Code-restating count | list of sentences with line refs |
| 5 | Voice — busy-tired-reader, or reference material? | 1–5 |

**METADOCU agreement (optional — only when the fixture ships a
`-reference/` companion):** of the N annotation-flagged issues on the
reference, how many does this run reproduce, avoid, or introduce new?
`simple-bot-annotated` ships a companion, so this section applies there.
`obsidian-spotiplay` does not, so it is omitted from that fixture's
scorecards; the five criteria above still apply.

Manual scores live in `manual-score.md` inside each cell directory.

### Automated metrics — `testing/tools/metrics.py`

Per produced doc:
- word count, sentence count, average sentence length
- identifier-mention count — symbols actually defined in the fixture's code
- code-block count, code-block total lines
- transcription density — identifier mentions per 100 words

Aggregated per cell:
- total words across all produced docs
- words-per-module ratio (the headline bloat-tilt number)

JSON output → `metrics.json` in each cell directory. Diffable across passes.

### Claude-as-judge

Fresh session loaded with principles.md + doc-standard.md + the produced
docs only. No transcript, no rubric, no other tier's output. Scores the
same five criteria, lists specific sentences that restate code, outputs
structured markdown → `judge-score.md`.

Known limit: the judge may share the bloat-tilt we're hunting. Convergence
across the three tracks = high confidence. Divergence = data.

## Pass output layout

```
testing/runs/001-base-vs-skill/
  SETUP.md              # this file
  PRIOR-FINDINGS.md     # the bobatler-results notes that motivated this suite
  SUMMARY.md            # cross-cell scoreboard + narrative + next-pass actions
  pass-1/
    simple-bot-annotated/
      T0/
        prompt.md          # exact prompt given to the agent
        transcript.md      # verbatim agent transcript
        produced/          # the produced docs, as the agent wrote them
        metrics.json
        judge-score.md
        manual-score.md   # includes METADOCU section
      T1/ ... T4/
    obsidian-spotiplay/
      T0/ ... T4/         # same shape; manual-score.md omits METADOCU section
```

## Running a pass

The operator skill is `.claude/skills/eval-base-vs-skill/` (project-local;
not in the plugin manifest). It owns the playbook — how to set up a fresh
agent per tier, what prompt to give, where outputs land.

Manual fallback (if the skill is unavailable): the design doc's Phase 1
section lists the steps in order.

## Status

- **Phase 1** — both fixtures in place: `simple-bot-annotated/` (Python,
  with METADOCU companion) re-extracted from `../bots/bobatler`;
  `obsidian-spotiplay/` (TypeScript, no companion) copied verbatim from
  `../obsidian-spotiplay`. Runner skill in place. `metrics.py` needs a
  small extension to extract identifiers from `.ts` as well as `.py` —
  pending. First clean pass after that.
- **Phase 2** — `pass <id>` orchestrator and variance reruns.
