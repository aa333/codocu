# Manual scorecard — pass-2 / simple-bot-annotated / T1

Tier: T1 (principles.md + doc-standard.md prepended as project conventions; no skill scaffolding).

Fill in by hand. Each numeric score is 1–5 unless noted.

## Scores

| # | Criterion | Score | Notes |
|---|---|---|---|
| 1 | Principle adherence — does each sentence say something code can't? |  |  |
| 2 | Refactor resistance — would this survive a rename, extract, or inline? |  |  |
| 3 | Bloat — judged against a minimum-viable mental version of the same doc set. (5 = lean; 1 = bloated) |  |  |
| 4 | Code-restating count | (list sentences with file refs) |  |
| 5 | Voice — busy-tired-reader (5) vs reference material (1). |  |  |

## METADOCU agreement

Ground truth: `testing/fixtures/full/simple-bot-annotated-reference/` (METADOCU-annotated, scorer-only).

Of the issues the reference flags, how many does this run:
- **Reproduce** (the agent hit the same problem):
- **Avoid** (the agent steered clear):
- **Introduce new** (the agent created issues the reference didn't flag):

## Free-form notes
