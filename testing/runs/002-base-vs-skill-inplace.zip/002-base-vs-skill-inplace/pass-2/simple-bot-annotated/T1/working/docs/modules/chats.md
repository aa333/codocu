# Chats module

Tracks who is present in which chat, persisted in SQLite. The captcha module
reads this to decide whether to skip the gate for known users.

Code: [`src/modules/chats/`](../../src/modules/chats/)

## "Known" vs "in chat"

Two booleans on a `(chat_id, user_id)` row:

- **registered** (existence of the row at all). A user becomes registered
  after they post `MESSAGES_TO_BE_KNOWN` messages in the chat. Captcha
  checks this via `is_known` — once registered, the user skips the gate
  forever, even if they later leave and rejoin.
- **in_chat**. Flipped to false when we see a `left_chat_member` event for
  them; flipped back to true on their next message via `touch`. Currently
  read by `is_in_chat` and `get_all`, neither of which has external
  callers. It exists for future features and to give `debug()` something
  to report.

`MESSAGES_TO_BE_KNOWN = 3` lives in
[`src/modules/chats/service.py`](../../src/modules/chats/service.py). Three
messages was picked as "more than a one-shot accident, fewer than a real
conversation". No deeper rationale; tune freely.

## Why an in-memory cache

`ChatsService._cache` is a dict mirror of the table, loaded on startup. The
hot path is `is_known` on every join, called from a place that already
holds up the joining user — we don't want a SQL roundtrip there. Writes go
through both the cache and the DB.

The pre-registration counter (`_watch`) is in-memory only. If the bot
restarts, your two-message progress toward becoming known is lost. That's
fine; we accept it.

## Why composite primary key, not auto-id

[`models.ChatMembership`](../../src/modules/chats/models.py) keys on
`(chat_id, user_id)` directly. There's no business-level "membership ID"
worth surfacing; the natural key is the lookup key.

## Not in scope

- No history. We only know the *current* membership state, not when a user
  last left or how many times they've rejoined.
- No bulk admin tools. There's no way through the bot to clear or reset
  rows; edit the SQLite file directly if you need to.
