# help and system modules

These two modules carry the admin and discovery surface for the bot. They're
small enough to share a doc.

## help

Code: [`src/modules/help/`](../../src/modules/help/)

`/help` (DM only) replies with an inline keyboard of available modules. The
keyboard is built from `ModuleList` filtered by:

- `m.help() is not None` — module has something to say. Chats currently
  returns None and so doesn't appear.
- `not m.is_system` unless the caller is an owner — system-flagged modules
  (only `SystemModule` today) hide from non-owners.

Tapping a button rewrites the same message with that module's help text and
a new keyboard where the current module's button becomes a no-op (`noop`
callback) so users can tell which one they're reading.

### Two cross-module couplings

- The keyboard's "Удалить" (delete) button emits `callback_data="cleanup_message"`.
  That callback is *handled by the system module*, not help. See the comment
  at the top of `bot_connector.py`. If you remove the system module you lose
  the delete button.
- `_handle_show_module` and `_handle_cleanup_message` both check that the
  callback comes from the user who originally typed `/help` (via the
  reply-to-message author). Other users get a snarky Russian putdown from
  [`core/strings.RESPONSES_NO`](../../src/core/strings.py).

## system

Code: [`src/modules/system/`](../../src/modules/system/)

Owner-only ops surface. `is_system=True` so it stays hidden from the help
menu for normal users.

| Command | What it does |
|--|--|
| `/ping` | Replies with hostname and uptime. |
| `/debug` | Calls `debug()` on every module, plus a CPU/RAM line, and posts it with a delete button. |
| `/sleep <seconds>` | **Blocks the event loop** for that many seconds (10–1200). See below. |

### `/sleep` blocks on purpose

`SystemService.sleep` uses `time.sleep`, not `asyncio.sleep`. This is the
whole point of the command: pausing the event loop pauses `infinity_polling`,
which means Telegram will fail over `getUpdates` to another instance of the
same bot running elsewhere. It's the cheapest "hand the bot off" knob we
have.

The `_sleeping` flag isn't read anywhere; it's set for future use (e.g. a
`/debug` line that says "sleeping"). Leave it or wire it up — either is
fine.

### The hostname pattern

`socket.gethostname()` is captured at module import (top of
`service.py` and `bot_connector.py`) and embedded in `/ping` and `/debug`.
The intent: when multiple instances run against the same token, the
hostname in replies tells you which one answered. If you containerize this,
set the container hostname to something distinguishable.

### Logs

`SystemService.get_recent_logs` reads the tail of `config.log_file`. No
command currently exposes it — this is a hook for a future `/logs`
command. Nothing writes that log file from this codebase either; the
intent is that you wire up Python `logging` to it externally.
