# Captcha module

Gates new joiners on group chats. A joiner gets a small arithmetic question
and a countdown; failing the answer or the timer results in a ban+unban
(equivalent to a kick — the user can rejoin and try again).

Depends on the **chats** module: known users skip the gate.

Code: [`src/modules/captcha/`](../../src/modules/captcha/)

## The flow

[`CaptchaBotConnector.handle_join`](../../src/modules/captcha/bot_connector.py)
is the entry point and decides whether to challenge:

1. **Bots get a free pass.** A friendly message and no challenge.
2. **Self-add only.** If `message.from_user != new_user`, the joiner was added
   by someone else — skip. Only people who walked in on their own face the
   captcha.
3. **Known users skip.** If `chats.is_known(chat_id, user_id)`, no challenge.
   "Known" means the user has posted `MESSAGES_TO_BE_KNOWN` messages in this
   chat in the past (see [chats doc](chats.md)).
4. **Outdated joins are dropped.** If the join event is older than
   `CAPTCHA_OUTDATED_TIMEOUT` (45s, in [`types.py`](../../src/modules/captcha/types.py)),
   we don't start a challenge. Instead, if the user is somehow still a
   normal `member`, we post a one-line apology and bail. This catches the
   case where the bot was offline (or sleeping — see `/sleep`) when the user
   joined, and is only catching up now.
5. **Otherwise**, `_run_challenge` posts the question and waits.

The waiting loop ticks `time_left` down one second at a time, polling
`ch.status`. The user's reply path is `app.py → has_ongoing → verify_answer`;
a correct answer flips status to `PASSED` and the loop exits. `left_chat_member`
flips status to `ABORTED` (handled here in
[`_handle_left_member`](../../src/modules/captcha/bot_connector.py)) so the
loop exits if the user leaves mid-challenge.

If the loop runs out, the user is banned then unbanned. Net effect: a kick
they can come back from.

## Why the special-case answer `"~"`

[`CaptchaService.check_answer`](../../src/modules/captcha/service.py)
returns true for any text if the stored answer is `"~"`. There are no
`"~"` answers in [`strings.QUESTIONS`](../../src/modules/captcha/strings.py)
today — this is a hook for ops use (e.g. a future debug command that creates
a passthrough challenge) or for testing. Don't remove it without grepping for
external uses.

## Why the ban → sleep(1) → unban

Inline comment in `_run_challenge` covers it:

> without a brief gap the unban can race the ban on Telegram's side,
> leaving the user banned (only_if_banned then silently no-ops because the
> ban isn't committed yet).

That `asyncio.sleep(1)` is load-bearing. If you're tempted to drop it, test
against a real chat first.

## Why a separate `OUTDATED_TIMEOUT` vs `challenge_time`

- `config.captcha.challenge_time` is how long the joiner has to *answer*
  once we start a challenge.
- `CAPTCHA_OUTDATED_TIMEOUT` (constant) is how stale a join event can be
  before we refuse to start a challenge at all.

They live at different layers and don't share a value on purpose: the
challenge timer is part of the user-facing experience and can be tuned per
deployment; the outdated cutoff is about polling realities and stays fixed.

## State

Challenges are kept in `CaptchaService._challenges`, a plain list. No
persistence — a bot restart drops all in-flight challenges, which is the
right behavior (users get re-challenged on their next message, or are
already through).

## Not in scope

- No retries; failure means ban-then-unban and you wait for the user to
  rejoin.
- No per-chat configuration of question pool or timing.
- No metrics. `debug()` lists active challenges, that's it.
