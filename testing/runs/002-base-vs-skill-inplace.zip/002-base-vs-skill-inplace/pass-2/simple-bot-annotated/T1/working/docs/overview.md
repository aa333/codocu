# simple-bot — overview

A small Telegram bot for moderating group chats. Its main job: gate new
joiners through a text captcha, and track who is actually present in each
chat so the gate can be skipped for known users. A couple of owner-only
admin commands ride along.

UI strings are in Russian by design — this bot serves Russian-speaking
chats. Code, comments, and these docs stay in English.

## What's in the box

- **Captcha gate.** When someone joins a group, they get a short arithmetic
  question and a countdown. Wrong answer or timeout → banned then immediately
  unbanned (effectively kicked, so they can rejoin later). Right answer → welcomed.
- **Chat presence tracking.** After a user has posted N messages in a chat,
  they become "known". Known users skip the captcha next time they rejoin.
- **/help.** DM-only inline menu listing modules and their commands.
- **/ping, /debug, /sleep.** Owner-only ops commands. `/sleep` deliberately
  blocks the event loop — see [the sleep note](#sleepblockstheloop).

## Shape of the code

```
src/
  app.py                      entry point: load config, wire DI, run polling
  core/
    config.py                 dataclass config + JSON loader
    di.py                     tiny type->instance registry
    module.py                 Module ABC (the plugin interface)
    strings.py                strings shared across modules
  storage/database.py         peewee SQLite handle
  connectors/telegram/        thin wrappers over pytelegrambotapi
  modules/<name>/
    module.py                 Module subclass — the only required file
    service.py                business logic, no telegram types
    bot_connector.py          telegram handlers, calls into service
    models.py                 peewee models, if the module persists state
    strings.py                user-facing text (typically Russian)
```

A module needs only `module.py`. The four-file split (service / bot_connector
/ models / strings) is a convention, not enforced. Captcha, chats, help, and
system all follow it; small modules don't have to.

## Module lifecycle

`app.py` constructs every module in [`MODULE_CLASSES`](../src/app.py), then
runs them through three phases:

1. **Construct** (`__init__`). Plain Python; no DI lookups allowed here —
   other modules aren't registered yet.
2. **Register.** `app.py` puts each module instance into the DI container
   keyed by its concrete class. After this point any module can `di.get(...)`
   any other.
3. **Init** (`async init()`). The module resolves its dependencies via
   `di.get`, builds its service/connector, registers Telegram handlers.

Module order in `MODULE_CLASSES` is the construction order, but `init()`
runs them all sequentially so any module can depend on any other by the
time `init()` runs. Declared `depends_on = (...)` is informational today —
nothing checks it. It exists so a future reorder check has somewhere to
look. See `Module.depends_on` in [`src/core/module.py`](../src/core/module.py).

## Message routing in `app.py`

Two handlers are registered at the app level:

- `handle_message` for normal content types. **Order matters here**: if the
  sender currently has an active captcha challenge, the message is routed
  to `captcha.verify_answer` and `chats_svc.touch` is *skipped*. Otherwise
  it goes through `touch`, which counts toward becoming "known".
- `handle_new_member` for joins, delegates to `captcha.handle_join`.

If you add a new app-level handler, decide whether it should fire while a
captcha is active. The default answer is no — most things should sit behind
the captcha intercept.

`left_chat_member` is handled by two separate handlers (chats marks the user
as left; captcha aborts any ongoing challenge for them). Both run; order
between them is not significant.

## Adding a new module

1. Create `src/modules/<name>/module.py` with a `Module` subclass.
2. Set `name` (used by the help menu's lookup and `ModuleList.get`),
   `str_name` (button label in the help menu), and `is_system=True` if it
   should be hidden from non-owners.
3. If you persist state, define peewee models in `models.py`, list them on
   `models = (...)`. `app.py` calls `create_tables` on the union.
4. Implement `help()` (return None to hide from `/help`) and `debug()`
   (a short string for `/debug`).
5. In `init()`: pull deps from `di`, build internals, register handlers.
6. Add the class to `MODULE_CLASSES` in `app.py`.

The `service` / `bot_connector` split is the recommended shape: the service
owns state and pure logic and takes no Telegram types; the connector owns
Telegram handler wiring and translates between Telegram types and service
calls. Tests then target the service directly.

## Configuration

`config.json` (gitignored; copy `config.example.json`). All fields and their
defaults live in [`AppConfig`](../src/core/config.py). The notable ones:

- `tg_token` — required.
- `owner_ids` — Telegram user IDs that may run owner-only commands
  (`/ping`, `/debug`, `/sleep`, and the owner-visible help entries).
- `debug_chats` — chat IDs that get a `"simplebot started"` message on
  boot. Failures are swallowed; used to confirm an instance came up.
- `proxy` — set as a global on `telebot.asyncio_helper`. Not per-bot; if
  you ever run two bots in-process this becomes a problem.
- `captcha.challenge_time` — seconds the joiner has to answer. Independent
  of `CAPTCHA_OUTDATED_TIMEOUT` (see [captcha doc](modules/captcha.md)).

## Known rough edges

- <a id="sleepblockstheloop"></a>**`/sleep` blocks the event loop on purpose.**
  `SystemService.sleep` calls `time.sleep`, not `asyncio.sleep`. The intent is
  to stop `infinity_polling` so a second instance can take over the bot
  token. While sleeping the bot does not process anything, including its
  own commands. There is no auto-wake; the seconds argument is the only
  exit.
- **`pass_bot=True` typing.** pytelegrambotapi's stubs don't model
  `pass_bot`, which changes the handler signature at runtime. We pass
  `pass_bot=True` everywhere via [`register_bot_command`/`register_bot_callback`](../src/connectors/telegram/utils.py)
  and suppress pyright on the few direct `register_message_handler` calls.
  Don't try to "fix" the pyright comments by dropping `pass_bot` — handlers
  assume `bot` is their second arg.
- **Single global DI container.** [`src/core/di.py`](../src/core/di.py) is
  module-level mutable state. Fine for one bot per process; tests that
  spin up modules need to clear `_registry` themselves.
- **Captcha races.** See [captcha doc](modules/captcha.md) — there's a
  deliberate `sleep(1)` between ban and unban, and a 45s "outdated" cutoff
  for stale join events.
