# simple-bot

A small Telegram bot for moderating Russian-speaking group chats: captcha-gates
new joiners, tracks who is actually present, and exposes a couple of
owner-only ops commands.

## Run

1. `cp config.example.json config.json` and fill in `tg_token` and `owner_ids`.
2. Install with `uv sync` (or any tool that reads `pyproject.toml`; the
   project targets Python 3.14).
3. `python -m src.app`.

## Docs

Start at **[docs/overview.md](docs/overview.md)** — it covers the architecture
(module + DI), the module lifecycle, message-routing rules in `app.py`, and
how to add a new module. From there, drill into the per-module notes:

- [docs/modules/captcha.md](docs/modules/captcha.md) — join flow, skip rules,
  the ban/unban race, the outdated-event cutoff.
- [docs/modules/chats.md](docs/modules/chats.md) — what "known" means and how
  presence is tracked.
- [docs/modules/help-and-system.md](docs/modules/help-and-system.md) — the
  inline help menu and the owner-only ops surface (`/ping`, `/debug`, `/sleep`).
