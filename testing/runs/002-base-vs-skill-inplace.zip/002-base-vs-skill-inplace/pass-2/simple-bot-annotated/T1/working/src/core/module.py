from abc import ABC, abstractmethod


class Module(ABC):
    """Base unit of business functionality — the plugin interface.

    A module owns its slice of state, its Telegram handlers, and its
    user-facing strings. ``app.py`` constructs every module, registers each
    in the DI container, then calls ``init()`` on each in order so any
    module can depend on any other by the time ``init`` runs.

    The full lifecycle (construct -> register -> init), the conventional
    file split (service / bot_connector / models / strings), and the
    add-a-new-module checklist live in ``docs/overview.md``.

    Subclass in ``src/modules/<name>/module.py``.
    """

    # Stable identifier; used by ModuleList.get and as the help-menu key.
    name: str
    # Human label shown on help-menu buttons (typically the Russian title).
    str_name: str
    # If true, the module hides from /help for non-owners. See help module.
    is_system: bool = False
    # Names of modules this one expects to be present. Informational today —
    # nothing enforces it. A future ordering check can read this.
    depends_on: tuple[str, ...] = ()
    # peewee models to create on startup. app.py unions these across modules.
    models: tuple[type, ...] = ()

    async def init(self) -> None:
        """Called after ALL modules are registered in DI.

        Override to resolve cross-module deps via ``di.get()``,
        load caches, create internal service/connectors, and register handlers.
        """

    @abstractmethod
    def help(self) -> str | None:
        """Return help text for this module, or None."""

    @abstractmethod
    async def debug(self) -> str:
        """Return debug/status info string."""
