"""Single SQLite handle shared by every module's peewee models.

The handle is created with no path (``SqliteDatabase(None)``) so that model
classes can be defined at import time. ``init_db`` is called once from
``app.py`` with the path from config; that's when WAL mode and foreign keys
are turned on and the connection is opened.

Modules don't open their own connections — they just subclass ``BaseModel``
and list the model on ``Module.models``; ``app.py`` calls
``create_tables`` on the union at startup.
"""

from peewee import Model, SqliteDatabase

db = SqliteDatabase(None)


class BaseModel(Model):
    class Meta:
        database = db


def init_db(path: str) -> None:
    db.init(path, pragmas={"journal_mode": "wal", "foreign_keys": 1})
    db.connect()
