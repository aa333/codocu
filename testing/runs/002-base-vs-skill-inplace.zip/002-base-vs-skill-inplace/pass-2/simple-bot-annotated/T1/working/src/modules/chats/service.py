from datetime import datetime, timezone
from typing import cast

from telebot.types import Message

from src.modules.chats.models import ChatMembership

# How many messages a user must post in a chat before they're considered
# "known" and can skip the captcha on a future rejoin. Tunable; see
# docs/modules/chats.md for the reasoning (such as it is).
MESSAGES_TO_BE_KNOWN = 3


class ChatsService:
    """Tracks who is present in which chat and who has "graduated" past the
    captcha gate.

    Two pieces of state per ``(chat_id, user_id)``:

    * registered (row exists in the cache / DB) -> the user has posted at
      least ``MESSAGES_TO_BE_KNOWN`` messages here; captcha skips them
      forever after.
    * ``in_chat`` -> mirrors Telegram's left/joined events for the user.

    The cache is loaded once at startup and kept in sync with the DB on
    writes; reads (especially ``is_known``, called from the captcha
    hot path) never hit SQL.

    Full semantics + why this design: docs/modules/chats.md.
    """

    def __init__(self) -> None:
        self._cache: dict[tuple[int, int], ChatMembership] = {}
        self._watch: dict[tuple[int, int], int] = {}

    def load_cache(self) -> None:
        self._cache.clear()
        for row in ChatMembership.select():
            self._cache[(cast(int, row.chat_id), cast(int, row.user_id))] = row

    def _now(self) -> datetime:
        return datetime.now(timezone.utc)

    def is_known(self, chat_id: int, user_id: int) -> bool:
        return (chat_id, user_id) in self._cache

    def is_in_chat(self, chat_id: int, user_id: int) -> bool:
        m = self._cache.get((chat_id, user_id))
        return m is not None and bool(m.in_chat)

    def get_all(self, chat_id: int) -> list[ChatMembership]:
        return [m for k, m in self._cache.items() if k[0] == chat_id and bool(m.in_chat)]

    def get_user_chats(self, user_id: int) -> list[int]:
        return [k[0] for k in self._cache if k[1] == user_id]

    def touch(self, message: Message) -> None:
        """Record a message from a user in a chat.

        If they're already registered, bump ``last_message_at`` and flip
        ``in_chat`` back on. If not, increment the in-memory pre-registration
        counter; on hitting ``MESSAGES_TO_BE_KNOWN`` the user is registered
        in the DB and added to the cache.

        Counter state is in-memory only — a restart resets in-progress
        counts but never demotes already-registered users.
        """
        if message.from_user is None:
            return
        chat_id = message.chat.id
        user_id = message.from_user.id
        key = (chat_id, user_id)
        now = self._now()

        existing = self._cache.get(key)
        if existing is None:
            self._watch[key] = self._watch.get(key, 0) + 1
            if self._watch[key] >= MESSAGES_TO_BE_KNOWN:
                del self._watch[key]
                row = ChatMembership.create(
                    chat_id=chat_id,
                    user_id=user_id,
                    in_chat=True,
                    registered_at=now,
                    last_message_at=now,
                )
                self._cache[key] = row
            return

        existing.last_message_at = now  # pyright: ignore[reportAttributeAccessIssue]
        was_out = not bool(existing.in_chat)
        if was_out:
            existing.in_chat = True  # pyright: ignore[reportAttributeAccessIssue]
        ChatMembership.update(last_message_at=now, in_chat=True).where(
            ChatMembership.chat_id == chat_id,
            ChatMembership.user_id == user_id,
        ).execute()

    def mark_left(self, chat_id: int, user_id: int) -> None:
        key = (chat_id, user_id)
        row = self._cache.get(key)
        if row is None:
            return
        row.in_chat = False  # pyright: ignore[reportAttributeAccessIssue]
        ChatMembership.update(in_chat=False).where(
            ChatMembership.chat_id == chat_id,
            ChatMembership.user_id == user_id,
        ).execute()
