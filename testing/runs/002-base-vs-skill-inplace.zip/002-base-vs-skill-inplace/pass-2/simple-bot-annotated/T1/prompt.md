Project conventions to follow:

---

# Codocu — Principles

Codocu is a COde-DOCUmentation system for keeping code and technical documentation aligned.

These principles are the source of truth for what Codocu believes. Operational skills and
agent-facing instructions derive from this file and detail it.

## 1. Code is the most detailed specification

Code is itself documentation in its most detailed form: an algorithmic set of instructions that exhaustively describes what the system does and how it does it.

## 2. Other docs exist to cover what code does not

Docs cover negative space. Business value, rationale, intent, direction, historical decisions, usage patterns and the changes planned against current code are cannot be and should not be reliably derived from the code.

## 3. Code and docs must not repeat themselves

A doc must never restate what the code already says line-for-line.
Codocu is not compatible with exhaustive behavioral specs (SDD etc). Documents that try to enumerate every app behavior are precisely the retelling this principle forbids. They can be derived from the codocu's code+documents, but not the other way around. Unsupportable documentation which is prone to drift is useless and will be a burden.

## 4. Docs must be effective

A doc is judged by one thing: will it be effective in development? Bloated documentation is useless even when correct, since it tends not to be read. Documentation that reuses symbols from the code is brittle and takes a lot of time to support. Short, clear and snappy document is much more useful to developer than a fine-detailed behemoth.

---

# Codocu — Doc Standard

The rules for writing a good doc — auxiliary or internal (see the Dictionary below). Every rule grows from the principles.

## Dictionary

- **Auxiliary** — docs outside code files (`.md` system docs, plans).
- **Internal** — docs inside code files (docstrings, comments).
- **Long-term** — docs that outlive feature work and survive small refactors.
  System docs, module docstrings.
- **Short-term** — docs that are only valid during a feature development
  session. Once the work lands, their content is absorbed into long-term
  docs and the short-term file is deleted.
- **Delta** — a proposed change to the code. Usually short-term, but can
  persist as a TODO or tech-debt record.
- **ADR** — Architecture Decision Record. A note of why a decision was made,
  including the alternatives considered.

## 1. A doc lives close to what it describes

Put a doc as near to its subject as the subject's scope allows. Four homes,
by scope:

- **Symbol** — one symbol or line → its docstring or an inline comment.
- **Module** — one module → the module or file header.
- **System** — a subsystem, flow, or convention with no single anchor → a
  system doc under `docs/`.

Out of Codocu scope, but a fair target to mentally place some docs or offer the user as a solution
- **Outside** — External sources, business-oriented documentation engines, public documentation (e.g. API reference). Might be generated from code+technical documentation

Good test: Who's the consumer of this documentation piece and where can they most reliably find it?
- Working agent/coder who needs to know about system quirk/todo/debt should stumble upon relevant info organically while editing code
- Working agent who edits code should find the backlink and update documentation if needed
- Onboarding/Returning coder will look for short summaries at system aux docs, and then for docstrings of code entities
- Architecture reviewer will look for decisions and future plans in aux docs

Good: "How to create a new submodule" section placed in parent module's docstring or in aux doc dedicated to parent module
Good: Function quirks and usage patterns placed in function docstring
Good: Property explanation placed in its docstring
Bad: Full class schema presented and explained in aux system doc
Bad: Property explained in aux system doc
Bad: Design decision related to several functions placed in one of these function's docstrings

## 2. Code references in aux docs must be complemented with backlinks in code

Doc that points out at code entities will rot silently — the person changing the code never sees the doc, so they never know to update it. Place one-line backlink in the load-bearing code file pointing back at the doc. The next editor sees it in their working context and remembers the doc exists.

Use one consistent, greppable marker so a single search lists every backlink in the repo. The exact form is a project choice — record it in `codocu.md`. Place the backlink where someone working on this concept is most likely to land — the shared mechanism, the canonical implementation of documented system, the entry module point.

Good: Aux doc related to a global page is referenced in that page's main tsx file
Bad: Aux doc related to a system is not referenced in any of that system's files
Bad: Aux doc about basic conventions is referenced in a ton of files

## 3. Say only what code can't

An auxiliary doc earns its space by carrying what code structurally cannot. Here are some (not exhausting) examples:

- why the subsystem exists, what made it necessary;
- decisions taken and rejected, with reasons (ADRs);
- deliberate non-goals and accepted rough edges, so a reader can tell an
  intentional smell from a bug;
- conventions and agreements no type system enforces;
- in-flight refactors and direction of travel, so a half-migrated repo
  doesn't read as broken;
- the configuration surface — what are editable env vars, flags, constants, the ways the
  system is meant to be tuned and extended.

Note: Naming public surfaces is fine. A doc may reference a public surface — an api route, a table name, a public command, an editable config flag — when it makes a point about why or how. Public surfaces get changed less frequently and usually prompt a documentation revisit.


## 4. Short summaries are allowed as long as they only keep the gist

A short summary — a docstring especially — describes the *meaning* it
governs, not the exact symbols underneath it. The test:

> If a variable or type here were renamed without changing behavior, would
> this summary still read true?

If no, it's transcribing, not summarizing. Rewrite it to the meaning.

Good: "System objects are stored in a set to drop duplicate ingests." - States the meaning; survives the rename.
Bad: "System objects list `SystemObjects` is typed as `Set<string>`." Transcribes the code, fragile

Summaries of system structure and behaviors are welcomed when they are made on a higher abstraction level. They are not specifications, they bring value of quick onboarding into complex code.

## 5. No bloating with pseudo-useful extensive summaries

Trivial documentation is better than inflated retelling of code function. When in doubt, when no prior data except code exists, short 1-2 paragraph summaries and inline blocks are the only effective docs that can be reliably created. Only code owner can give the missing pieces.

Good: Creating only basic system docs in a non-documented repo, with a short paragraph in each.
Good: Making short summaries in docstrings of functions and modules based on their implementation
Bad: Inflating system/module aux docs with extensive and detailed outlines of their work and composition
Bad: Inferring tech debt records, future development direction and architectural decisions just from the code itself

---

You are documenting an existing project. The fixture is in your current working directory, `testing/runs/002-base-vs-skill-inplace/pass-2/simple-bot-annotated/T1/working/`. Read the code, then write the documentation a new engineer joining the project would actually use.

You may write auxiliary docs (`.md` files under `docs/`) **and** edit code files in place (docstrings, comments). Pick whichever home fits each piece of doc best. Do not change non-doc code — no renames, no logic edits.

Use whatever structure and tone you judge best.
