# T1 transcript — pass-2, simple-bot-annotated

Cold subagent given principles.md + doc-standard.md prepended as "Project conventions to follow," then the standard T0 instruction (document the fixture in `<cell>/working/`, may write aux docs and edit code-file docstrings/comments, no logic edits).

## Subagent's report

### What was written

**New auxiliary docs (system-level):**

- `README.md` — entry point. How to run + pointer into `docs/`.
- `docs/overview.md` — top-level architecture: project purpose, code layout, the module + DI design, the lifecycle (construct → register → init), the load-bearing message-routing order in `app.py`, an "add a new module" checklist, config notes, and a "known rough edges" list.
- `docs/modules/captcha.md` — join flow and skip rules, the `"~"` wildcard, the load-bearing `sleep(1)` between ban and unban, why `CAPTCHA_OUTDATED_TIMEOUT` is a separate dial from `challenge_time`, scope.
- `docs/modules/chats.md` — what "known" vs "in chat" actually mean, where `MESSAGES_TO_BE_KNOWN = 3` comes from, why the cache + composite key, scope.
- `docs/modules/help-and-system.md` — folded together since both are small. Covers the keyboard logic, the cross-module `cleanup_message` callback coupling, the deliberate-blocking semantics of `/sleep`, and the hostname-stamping pattern.

**Inline docs (backlinks + meaning summaries):**

- `src/app.py` — module docstring tying the file to overview.md; expanded captcha-intercept comment naming the actual invariant being protected.
- `src/core/module.py` — class docstring rewritten as the plugin interface; per-attribute one-liners on each class attr (the previous ones were missing for `name`, `str_name`, `is_system`, `depends_on`, `models`).
- `src/core/di.py` — module docstring explaining process-global / test-isolation rule.
- `src/core/config.py` — module docstring with backlink to overview.md.
- `src/storage/database.py` — module docstring explaining the "single shared handle, late init" pattern.
- `src/connectors/telegram/utils.py` — module docstring explaining why the wrappers exist (the `pass_bot` typing situation and the DM/group filter).
- `src/modules/chats/service.py` — class docstring covering the two pieces of state and the hot-path reason for the cache; constant comment on `MESSAGES_TO_BE_KNOWN`; `touch` docstring describing the pre-registration counter behavior.
- `src/modules/captcha/bot_connector.py` — class docstring naming the entry points and backlinking to the captcha doc.
- `src/modules/captcha/service.py` — class docstring on the non-persistence choice; `check_answer` docstring on the `"~"` wildcard.
- `src/modules/captcha/types.py` — constant comment on `CAPTCHA_OUTDATED_TIMEOUT` explaining what it is and how it differs from `challenge_time`.
- `src/modules/system/service.py` — `sleep` docstring expanded to name the *intent* (yield polling to another instance) and the consequence (no commands while sleeping).
- `src/modules/help/bot_connector.py` — extended the existing cross-module comment with the consequence (removing system breaks the delete button) plus a backlink.

### Placement rationale

- **System docs under `docs/`**: each piece touches multiple files and/or carries why-not-what context that has no single code anchor (lifecycle, message ordering, ban/unban race, "known" semantics, `/sleep`'s deliberate blocking). These are the things a new engineer needs *first* and the things that won't survive in only one file's docstring.
- **Docstrings at the canonical entry point**: `Module` (the plugin interface), `ChatsService` / `CaptchaService` (the per-module brains), `SystemService.sleep` (the single deliberately-weird method).
- **Inline comments where the surprise lives**: app.py's captcha intercept, the constants whose names don't tell you what they're for (`MESSAGES_TO_BE_KNOWN`, `CAPTCHA_OUTDATED_TIMEOUT`), and the cross-module `cleanup_message` coupling.
- **Backlinks**: every aux doc is pointed to from at least one code file (app.py, module.py, di.py, both captcha files, both chats files, system/service.py, help/bot_connector.py), so an editor changing the load-bearing code will see the doc reference.

### What was deliberately not written

- No per-method walkthroughs of code that already reads cleanly (e.g. `is_known`, `mark_left`, the help keyboard plumbing). Adding a docstring saying "checks whether the user is known" on `is_known` would be transcription.
- No ADR-style decision log — no prior history to fold in, and inventing rationale from the code alone is the kind of unsupportable doc the principles flag.
- No exhaustive command/string list. `strings.py` files and the per-module `HELP` are already the source of truth; duplicating them in markdown would drift.
- No tests, no logic edits, no renames — per the task constraints.
