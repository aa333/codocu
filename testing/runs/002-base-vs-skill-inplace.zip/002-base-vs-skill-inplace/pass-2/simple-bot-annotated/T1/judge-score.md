# Judge score — pass-2 / simple-bot-annotated / T1

Cold judge subagent given: principles.md + doc-standard.md + all new `.md` files under `T1/working/` + inline doc diffs against the fixture. No transcript, no rubric file, no other tier's output.

## Scores

| Dimension | Score | Justification |
|---|---|---|
| **Principle adherence** | 4 | Most sentences carry intent, rationale, races, ops/test hooks, or cross-module couplings that code can't show; a few inline lines (e.g. `models` peewee comment, the `Module.name` attribute comments) are close to transcription. |
| **Refactor resistance** | 4 | Docs lean on meaning ("known", "ban+unban kick", "the captcha intercept") rather than symbols; some specific symbol references (`MESSAGES_TO_BE_KNOWN`, `CAPTCHA_OUTDATED_TIMEOUT`, `MODULE_CLASSES`) are unavoidable and appropriately used as public-surface anchors. Survives a rename of internals like `_watch`, `ChatsService`, `_run_challenge`. |
| **Bloat** | 3 | `docs/overview.md` does most of the work, but the per-module aux docs duplicate parts of it (the join flow, the sleep rationale, the `MESSAGES_TO_BE_KNOWN` blurb) and the README adds another summary on top. A minimum-viable set could be `overview.md` plus one captcha note; the four-doc fan-out is more than the bot needs. |
| **Voice** | 4 | Direct, second-person, occasional dry asides ("such as it is", "load-bearing", "snarky Russian putdown") — feels like a colleague's notes. The overview's "Adding a new module" walks toward checklist-ese, which is the only stretch toward reference-manual register. |

## Code-restating sentences

- `"""Return help text for this module, or None."""` — `working\src\core\module.py` (unchanged from fixture, but still: the signature already says exactly this). Same critique for `"""Return debug/status info string."""`.
- `# Stable identifier; used by ModuleList.get and as the help-menu key.` — `working\src\core\module.py:19`. The "stable identifier" half is fine, but tying it to `ModuleList.get` and "help-menu key" restates references that grep would find; sensitive to a rename of `ModuleList.get`.
- `# peewee models to create on startup. app.py unions these across modules.` — `working\src\core\module.py:28`. The type annotation already says these are model classes and `app.py` already shows the union; this is a restatement of the call site.
- `"""Register an instance by its type in the global DI container."""` / `"""Resolve an instance from the global DI container."""` — `working\src\core\di.py:49, 54`. Function names plus signature already convey this; the bodies are two lines.
- `"""Validate /sleep args. Returns (ok, error_or_empty)."""` — `working\src\modules\system\service.py:71` (carried from fixture but kept). The signature `-> tuple[bool, str]` plus the literal Russian error strings already say this.
- `"Bots get a free pass.** A friendly message and no challenge."` — `docs\modules\captcha.md:17`. The `if new_user.is_bot:` branch and its `bot.send_message(... PASSED_BOT ...)` call already show exactly this; the doc adds no "why bots are exempted".
- `"The waiting loop ticks `time_left` down one second at a time, polling `ch.status`."` — `docs\modules\captcha.md:33`. Direct narration of the `while ch.status == ch.status.ONGOING and ch.time_left > 0: await asyncio.sleep(1); ch.time_left -= 1` loop; survives no refactor.
- `"`SystemService.sleep` uses `time.sleep`, not `asyncio.sleep`."` appears in **three** places — `docs\overview.md:119`, `docs\modules\help-and-system.md:48`, and the docstring on `sleep()` at `working\src\modules\system\service.py:84`. The docstring is the right home; the two aux mentions repeat what the docstring (and now the function body) already shows.
- `"`/ping` | Replies with hostname and uptime."` — `docs\modules\help-and-system.md:42`. `PingBotConnector` (and `SystemService.get_uptime_text` + `hostname`) already say this; the table row adds nothing about *why*.
- `"`MESSAGES_TO_BE_KNOWN = 3` lives in `src/modules/chats/service.py`."` — `docs\modules\chats.md:22`. The constant's name and value are literal code; the doc's value adds the "three messages was picked as..." which is fine, but the leading sentence is transcription.

## Overall verdict

This run lands on the right side of every Codocu principle most of the time: the heavy lifting (lifecycle, message-routing order, ban/unban race, outdated-timeout vs challenge-time, `/sleep` blocking on purpose, `pass_bot=True` typing, the cross-module `cleanup_message` callback, the single global DI container) all surface where a working agent would meet them, and inline backlinks are placed in the load-bearing files (`app.py`, `service.py`, `bot_connector.py`, `types.py`). The voice is appropriately tired-developer. The main weakness is bloat across the doc *set*: README, overview, and three module docs cover overlapping ground, and the captcha doc in particular narrates the implementation step-by-step rather than just naming the non-obvious calls. A leaner shape — one overview plus a captcha-specific note for the races and timeouts, with the chats and help/system content folded into module-level docstrings — would have scored higher without losing any of the rationale the agent surfaced.
