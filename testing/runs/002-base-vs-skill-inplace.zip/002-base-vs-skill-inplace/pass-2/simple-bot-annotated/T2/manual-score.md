# Manual scorecard — pass-2 / simple-bot-annotated / T2

Tier: T2 (full Codocu skill). **Variant for this pass:** the cell was run by a cold subagent that simulated `/codocu:init` then `/codocu` by reading the actual SKILL.md files, rather than by a real `claude --plugin-dir` session. See `transcript.md` for the caveats — no user-in-the-loop init confirmation, no `codocu-reviewer` subagent, etc. Weigh against pass-1's true T2 when interpreting these scores.

Fill in by hand. Each numeric score is 1–5 unless noted.

## Scores

| # | Criterion | Score | Notes |
|---|---|---|---|
| 1 | Principle adherence — does each sentence say something code can't? |  |  |
| 2 | Refactor resistance — would this survive a rename, extract, or inline? |  |  |
| 3 | Bloat — judged against a minimum-viable mental version of the same doc set. (5 = lean; 1 = bloated) |  |  |
| 4 | Code-restating count | (list sentences with file refs) |  |
| 5 | Voice — busy-tired-reader (5) vs reference material (1). |  |  |

## METADOCU agreement

Ground truth: `testing/fixtures/full/simple-bot-annotated-reference/` (METADOCU-annotated, scorer-only).

Of the issues the reference flags, how many does this run:
- **Reproduce** (the agent hit the same problem):
- **Avoid** (the agent steered clear):
- **Introduce new** (the agent created issues the reference didn't flag):

## Free-form notes
