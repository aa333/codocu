# Chats

Tracks which users have been seen in which chats. The captcha module asks "is this user known here?" to decide whether to gate a join; the system module reports the cache size in `/debug`.

Auxillary doc: docs/systems/chats.md (in `src/modules/chats/`)

## When does a user become "known"

A row in `chat_memberships` is created only after a user has sent `MESSAGES_TO_BE_KNOWN` (3) messages in a chat. Before that, the count lives in an in-memory `_watch` dict and is lost on restart. The intent is to avoid a single drive-by message bypassing captcha forever; the cost is that a restart resets uncommitted watchers and a known user must be observed across the full N-message window again only if they weren't yet persisted.

## What "left" means

When Telegram emits `left_chat_member`, the row's `in_chat` is flipped to false but the row is kept. `is_known` stays true — that user has been here before, so on rejoin captcha skips them. Removing them from `is_known` would mean re-challenging long-time members after every leave/rejoin cycle, which the design rejects.

## Cache versus DB

The service keeps an in-memory dict `_cache` keyed by `(chat_id, user_id)`. Reads (`is_known`, `is_in_chat`, `get_all`, `get_user_chats`) hit only the cache; writes update both the cache row and the DB. The cache is loaded once at module init from `ChatMembership.select()`. There's no invalidation path — a process that bypasses the service and writes the table directly will be invisible until restart.
