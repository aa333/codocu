# Architecture

Single-process Telegram bot. `src/app.py` is the entry point; it loads config, opens the SQLite DB, builds the bot client, and instantiates one of each module. Modules are then registered into a tiny DI registry (`src/core/di.py`), tables are created from each module's `models`, and `init()` is called on each — that's where handlers get wired into the bot. After init, polling runs forever.

## The module pattern

Each business area is a `Module` (see `src/core/module.py`) living under `src/modules/<name>/`. The standard layout per module:

- `module.py` — the `Module` subclass. Owns lifecycle (`init`), `help()` text, and a `debug()` line for the operator.
- `service.py` — pure logic. No telebot imports. Holds in-memory state and DB calls.
- `bot_connector.py` — registers handlers on the bot, translates between telebot types and the service, formats user-facing replies.
- `strings.py` — user-facing text. Russian-only at present.
- `models.py` — peewee models, when the module needs persistence.

Why the split: a module's service can be exercised without telebot, and the connector can be swapped if the transport ever changes. In practice nothing else exercises services today; the split is held for clarity, not for test surface.

Auxillary doc: docs/systems/architecture.md

## Module wiring

`src/app.py` holds the module list literally — `MODULE_CLASSES`. Order matters at startup because `init()` runs in list order and a module may `di.get()` siblings: captcha resolves `ChatsModule` during init, so chats must be listed first. The `depends_on` field on `Module` is informational; nothing enforces it.

After every module's `init()` returns, two extra wires are set up directly in `app.py`:

- A pre-dispatch interceptor for group messages that gives the captcha module first refusal — if the sender has an active challenge, the message is treated as the answer and chats' message-tracking is skipped.
- A `new_chat_members` handler that hands joins to captcha.

These two wires live in `app.py` rather than in a module's connector because they make ordering choices between modules (captcha-before-chats), which a single module can't decide on its own.

## DI registry

`src/core/di.py` is a `dict[type, instance]` keyed by type. Registered at startup: `AppConfig`, `AsyncTeleBot`, each module instance keyed by its concrete class, and `ModuleList` (a typed wrapper used by help and system for "all modules" iteration). There is no scoping, no teardown, no lazy construction — it's a global lookup table.

## Storage

One SQLite database opened in `src/storage/database.py`. Models inherit `BaseModel` which binds them to the shared `db`. Each module declares its models on the class (`models = (...)`), and `app.py` calls `db.create_tables(...)` over the union of all declared models. WAL is enabled; there is no migration story — schema changes mean editing the model and resetting the DB.
