# Captcha

Gate for new group members: when someone joins, the bot replies with a small arithmetic/trivia question; if they answer correctly within the time window, they pass. If not, they're banned-then-unbanned (a kick — the user can rejoin) and the challenge message is cleaned up.

Auxillary doc: docs/systems/captcha.md (in `src/modules/captcha/`)

## Who is challenged

A join only triggers a challenge if all of these hold:

- The new member isn't a bot (bots get a one-line "added without check" message and pass).
- The member added themselves (someone else adding them is treated as a vouch — skipped).
- The pair `(chat_id, user_id)` is not already known to the chats module — returning members aren't re-challenged.
- The join event isn't older than `CAPTCHA_OUTDATED_TIMEOUT` seconds (45). Stale events from a backlog get a polite "time expired" reply if the user is in fact present, and are otherwise dropped silently.

## Challenge lifecycle

The service holds active challenges in memory only — they don't survive a restart. A challenge has three real statuses (`ChallengeStatus`): ONGOING, PASSED, ABORTED. There is no FAILED status: timeout is detected by the connector noticing the status is still ONGOING after the countdown ends. This is the meaning of the four `JoinOutcome` values — PASSED / FAILED / SKIPPED / ABORTED — which are the connector's view, not the service's.

ABORTED is set in two situations: a new challenge for the same `(chat, user)` overrides the previous one, and a `left_chat_member` event during an ongoing challenge cancels it (the user left voluntarily, no need to ban).

## The ban-then-unban dance

When a challenge times out, the user is banned and then unbanned a second later. The sleep between the two calls is deliberate — without it Telegram's API can race: the unban arrives at the server before the ban is committed, `only_if_banned=True` no-ops because there's no ban yet, and the user ends up permanently banned. The one-second gap makes the ordering reliable.

## Bypass answer

If a challenge's stored answer is exactly `~`, any non-empty text passes. This is an operator escape hatch — nothing in code sets it today; questions come from `strings.QUESTIONS`.

## Interaction with the chats module

Captcha reads `ChatsService.is_known` to decide whether to challenge. The chats module's "known" threshold is `MESSAGES_TO_BE_KNOWN` (3) message hits before a row is persisted; the implication is that someone who joined, said two things, and rejoined will be challenged again. That's a deliberate tradeoff against a single message being enough to permanently whitelist a user.
