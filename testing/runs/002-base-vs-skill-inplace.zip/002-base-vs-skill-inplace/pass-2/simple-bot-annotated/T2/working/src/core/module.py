# Auxillary doc: docs/systems/architecture.md
from abc import ABC, abstractmethod


class Module(ABC):
    """Base unit of business functionality.

    A module bundles a service (pure logic), a bot connector (handler glue),
    optional peewee models, and user-facing strings. Lifecycle: instantiated
    in ``app.py``, registered into DI, then ``init()`` is called once with
    all siblings already registered — that's where cross-module ``di.get()``
    calls are safe and where handlers are wired onto the bot.

    Subclass in ``src/modules/<name>/module.py``.
    """

    name: str
    str_name: str
    is_system: bool = False
    depends_on: tuple[str, ...] = ()
    models: tuple[type, ...] = ()

    async def init(self) -> None:
        """Called after ALL modules are registered in DI.

        Override to resolve cross-module deps via ``di.get()``,
        load caches, create internal service/connectors, and register handlers.
        """

    @abstractmethod
    def help(self) -> str | None:
        """Return help text for this module, or None."""

    @abstractmethod
    async def debug(self) -> str:
        """Return debug/status info string."""
