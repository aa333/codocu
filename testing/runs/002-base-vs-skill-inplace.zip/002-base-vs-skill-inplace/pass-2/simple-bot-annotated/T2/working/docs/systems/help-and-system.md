# Help and System modules

Two small operator-facing modules with one shared mechanism worth noting.

## Help

`/help` (DM only) replies with an inline-keyboard menu of modules that have `help() is not None` and that the caller is allowed to see (system-only modules are gated on owner status, set via `config.owner_ids`). Tapping a module replaces the message body with that module's help text; tapping the active module is a no-op. The menu is built fresh every render from `di.get(ModuleList)` — modules added at runtime would appear automatically, though there's no runtime registration path today.

Owner-gated visibility is decided per render. A non-owner who opens the menu and is later granted ownership won't see system modules until they re-open `/help`.

## System

Owner-only DM commands:

- `/ping` — hostname and human-readable uptime.
- `/debug` — fans out `Module.debug()` across every module and reports memory/CPU. Reply carries a "delete" button.
- `/sleep <seconds>` — blocks the event loop with `time.sleep` for 10–1200 seconds. This is deliberate: it stops polling so a second instance can take over without a clean handoff. Don't replace it with `asyncio.sleep` — that would keep polling alive and defeat the point.

## The `cleanup_message` callback

The "delete this reply" button you see on `/debug` and on the `/help` menu is wired in `SystemBotConnector`, but `HelpBotConnector` emits the same `callback_data="cleanup_message"`. This is intentional: one handler, many emitters. If the system module is ever removed or renamed, the delete button on help replies stops working — the dependency is invisible from `bot_connector.py` in help. Worth a backlink if the modules ever drift far apart.

Authorization on the callback checks that the caller is the same user who issued the original command (via `reply_to_message`). Anyone else gets the shared random "hands off" string.
