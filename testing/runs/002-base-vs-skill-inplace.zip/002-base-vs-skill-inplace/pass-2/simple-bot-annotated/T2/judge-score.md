# Judge score — pass-2 / simple-bot-annotated / T2

Cold judge subagent given: principles.md + doc-standard.md + all new `.md` files under `T2/working/` + inline doc diffs against the fixture. No transcript, no rubric file, no other tier's output.

## Scores

**Principle adherence: 5**
Every aux-doc sentence and added docstring earns its space with intent, rationale, or non-obvious behavior (e.g. the ban-then-unban race, the ABORTED-vs-FAILED design, the `~` bypass, the `time.sleep` rationale). I struggled to find any sentence that merely echoes code mechanics.

**Refactor resistance: 4**
Most prose holds up under renames. A handful of bare symbol references (`MESSAGES_TO_BE_KNOWN`, `CAPTCHA_OUTDATED_TIMEOUT`, `ChallengeStatus`, `JoinOutcome`, `MODULE_CLASSES`, `_cache`, `_watch`, the per-module file names like `module.py`/`service.py`) would need touching on a rename, but in each case the symbol is being named to make a *point* about it (the doc-standard explicitly allows public-surface references), not to inventory the code.

**Bloat: 5**
Lean against a minimum-viable mental version. `tech-debt.md` is empty, `todo.md` is one line, `CLAUDE.md` is a single include, system docs run a tight 1–4 short sections each, docstrings are 3–7 lines max. No section is padding.

**Voice: 5**
Busy-tired-reader throughout — short paragraphs, plain verbs, em-dashes, declarative facts ("the one-second gap makes the ordering reliable"). Reads like a teammate explaining the codebase, not a spec.

## Code-restating sentences

I scanned for sentences that merely transcribe code structure or symbol semantics. Slim pickings — these are the closest things, and they're borderline rather than clear violations:

- `docs/systems/architecture.md`: "`src/app.py` holds the module list literally — `MODULE_CLASSES`." The "holds the module list literally" half is content; the bare symbol naming is borderline.
- `docs/systems/architecture.md`: "Registered at startup: `AppConfig`, `AsyncTeleBot`, each module instance keyed by its concrete class, and `ModuleList`..." Reads like an inventory of `di.register` calls in `app.py`; a reader could derive this from `main()` directly. Mitigated by the next sentence ("no scoping, no teardown, no lazy construction") which earns the paragraph.
- `docs/systems/captcha.md`: "A challenge has three real statuses (`ChallengeStatus`): ONGOING, PASSED, ABORTED." Enumerates the enum values. (The followup "There is no FAILED status: timeout is detected by..." is the actual insight, which justifies the enumeration.)
- `docs/systems/chats.md`: "Reads (`is_known`, `is_in_chat`, `get_all`, `get_user_chats`) hit only the cache; writes update both the cache row and the DB." Mostly transcribes the method bodies; the "no invalidation path" sentence after it is the load-bearing claim.
- `src/modules/captcha/service.py` docstring: "ABORTED is set on voluntary leave or when a new challenge supersedes an existing one for the same (chat, user)." The "new challenge supersedes" half is visible directly in `create()` four lines below — though pairing it with the voluntary-leave fact (which isn't in this file) makes the whole sentence net-additive.

No outright violations — everything I flagged either pairs a structural fact with an insight, or names a public-surface symbol the doc-standard explicitly permits.

## Overall verdict

This is a strong Codocu pass. The aux docs are organized by system (architecture, captcha, chats, help-and-system), every section asks "what can't the code say?" and answers it — race conditions, deliberate non-goals, the meaning of an enum that omits a state, the operator escape hatch, why a `time.sleep` looks like a bug but isn't. The inline doc edits are surgical: each touched file gets one backlink and at most one docstring expansion, and the expansions add intent rather than restate signatures. `codocu.md` and `CLAUDE.md` are clean template-derived configuration. `tech-debt.md` is empty and `todo.md` is essentially empty — appropriate given the standard's rule against inferring tech debt from code alone. The few borderline transcription sentences are always paired with a load-bearing rationale in the same paragraph. Refactor resistance is good but not perfect: a handful of named symbols would need editing on rename, though each is a point being made about the symbol rather than an inventory. Voice is consistently a tired teammate, not a reference manual.
