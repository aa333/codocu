T2 (subagent variant — operator override).

Operator note: T2 normally runs via `claude --plugin-dir <codocu-repo>` against the working copy, with the user invoking `/codocu:init` then `/codocu`. For this pass the user requested the T2 cell be driven by a cold subagent instead. The subagent is instructed to follow Codocu's actual skill files (`skills/init/SKILL.md`, then `skills/codocu/SKILL.md`) as if they were invoked via the plugin, applying them in order against `<cell>/working/`.

The exact instruction given to the subagent is captured in the dispatch record (Agent tool prompt). It points the subagent at:

- `C:\repos\codocu\skills\init\SKILL.md` and its `templates/`
- `C:\repos\codocu\skills\codocu\SKILL.md` and its `references/`
- Working dir: `C:\repos\codocu\testing\runs\002-base-vs-skill-inplace\pass-2\simple-bot-annotated\T2\working\`

This is not equivalent to a real plugin run — flag this in the manual scorecard. The headline mismatch: a plugin-invoked Claude would treat `/codocu:init` as a slash-command-loaded skill in its main context, with the user as a participant; a subagent reads the SKILL.md as text and proceeds autonomously without the user-confirmation gates the init skill describes.
