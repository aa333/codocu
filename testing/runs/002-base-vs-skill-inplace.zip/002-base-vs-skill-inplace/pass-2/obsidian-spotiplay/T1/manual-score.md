# Manual scorecard — pass-2 / obsidian-spotiplay / T1

Tier: T1 (principles.md + doc-standard.md prepended as project conventions; no skill scaffolding).

Fill in by hand. Each numeric score is 1–5 unless noted.

## Scores

| # | Criterion | Score | Notes |
|---|---|---|---|
| 1 | Principle adherence — does each sentence say something code can't? |  |  |
| 2 | Refactor resistance — would this survive a rename, extract, or inline? |  |  |
| 3 | Bloat — judged against a minimum-viable mental version of the same doc set. (5 = lean; 1 = bloated) |  |  |
| 4 | Code-restating count | (list sentences with file refs) |  |
| 5 | Voice — busy-tired-reader (5) vs reference material (1). |  |  |

## Free-form notes

Possible scope creep: the agent removed bare `TODO` comments and two dead `console.debug` comments in `src/SpotifyAuthorizer.ts`. The task said "no logic edits" — removing comments isn't logic, but it is beyond strict "doc-only" interpretation. Weigh whether replacing TODOs with `docs/todo.md` entries (and `DOC:` backlinks) counts as legit inline-doc work.
