# Judge score — pass-2 / obsidian-spotiplay / T1

Cold judge subagent given: principles.md + doc-standard.md + all new `.md` files under `T1/working/` + inline doc diffs against the fixture. No transcript, no rubric file, no other tier's output.

## Scores

### Principle adherence — 5
Almost every sentence carries something code can't show: rationale (client secret on a device, no device picker, hand-rolled parser over a YAML dep), cross-file glue (the promise hand-off via `authPromiseResolve`, the redirect-URI-in-three-places invariant), known gaps (`docs/todo.md`), and onboarding gist. The few public-surface references (URI prefixes, scopes, refresh interval) are used to make a point about *why*, which the doc-standard explicitly permits.

### Refactor resistance — 4
Most prose survives renames because it states meaning ("the click orchestrator", "level-gated wrapper", "pure presentation"). Some weak spots: `architecture.md` and `spotiplayer-block.md` use `main.ts#playTrack`, `main.ts#parseData`, `main.ts#selectDevice`, `main.ts#onClick`, `PlayButton.onClickHandler`, plus a literal regex `^([^:]+):\s*(.+)$`. These break on rename or regex tweak. They are localised and aid grepping, but they are the realistic drift risk in this run.

### Bloat — 4
Lean for what it covers. The three aux docs partition cleanly: `architecture.md` (module map + flows + decisions), `spotiplayer-block.md` (user-facing syntax + parser quirks), `todo.md` (rough edges). README is a touch long for a hobby plugin (Setup, Build, Status, Repo conventions could be one short Setup + a link to architecture). Logger and PlayerPluginSettingTab headers are minimal; types.ts header is appropriately small. Could shave maybe 10–15% without losing signal.

### Voice — 4
Mostly busy-tired-reader: "Reading order: `onload` is the spine", "Deliberately dumb — there is no device-picker UI", "Notably absent: artist URIs", "Three places, one literal". A handful of sentences drift toward reference tone ("OAuth2 authorisation-code flow against accounts.spotify.com, threaded through Obsidian's `obsidian://` protocol handler"), and `architecture.md`'s "Decisions worth knowing" reads slightly formal but stays terse. Overall snappy, not encyclopedic.

## Code-restating sentences

- **`docs/architecture.md` line 22 (PlayerPluginSettingTab row):** "The settings panel Obsidian shows under Community Plugins. Three text fields, bound to the settings object." — The "three text fields, bound to the settings object" half is literally what the `display()` method shows.
- **`docs/architecture.md` lines 100–101:** "`clientId`, `clientSecret`, `deviceId` — set through the settings tab." — Restates what `PlayerPluginSettingTab.display()` already shows verbatim.
- **`docs/spotiplayer-block.md` line 36:** "The regex is `^([^:]+):\s*(.+)$`." — A verbatim copy of `main.ts`'s `KeyValueRegex` constant. Brittle to any tweak.
- **`docs/spotiplayer-block.md` lines 23–25** (the table mapping `spotify:track:` → `uris`, playlist/album → `context_uri`): essentially transcribes the `if/else if` branches in `playTrack`. The *user-facing* "what plays" half earns its keep; the Spotify-payload-field half ("Sent to Spotify as `uris: [uri]`") restates code.
- **`src/main.ts` line 24 comment** ("Matches a single `key: value` line"): the *first* clause restates what the regex name and shape already say; the "NOT a YAML parser…" follow-on is the load-bearing part.
- **`src/PlayButton.ts` lines 8–11** ("Click semantics: while a previous click is in flight (`isLoading`), additional clicks are ignored. After the callback resolves the button either returns to idle or shows "Error!"…"): paraphrases `onClickHandler` step-for-step. The earlier "Pure presentation — owns three states… knows nothing about Spotify" is the part code can't say.
- **`src/SpotifyAuthorizer.ts` line 53 (scopes inside authenticate's docstring)** "Scopes requested: `user-read-playback-state` and `user-modify-playback-state`": restates the literal `scopes` constant on the next line. (Borderline — public surface used to make a point about "no library scopes", which arguably saves it.)
- **`docs/todo.md` "Refresh interval is a magic number"** "`3500000` ms appears twice in `SpotifyAuthorizer`. It corresponds to 3500 seconds": the arithmetic is just what the literal says. The "promote to a named constant" sentence is the value-add.

## Overall verdict

This is a strong Codocu run. The aux/inline split respects scope — module-level meaning sits in docstrings, cross-file glue and decisions sit in `architecture.md`, user-facing surface sits in `spotiplayer-block.md`, deferred work sits in `todo.md` — and `DOC:` backlinks tie code back to the aux docs in exactly the places a future editor would land. The voice is consistently for the busy reader, with rationale carrying most sentences. The main risks are refactor-fragile references (`main.ts#parseData`, the inlined regex, the URI-prefix-to-payload-field table) and a handful of sentences that paraphrase short methods (`onClickHandler`, the settings tab). Trim those and the doc set would be near-ideal for this codebase.
