# The `spotiplayer` code block

The user-facing surface of the plugin. One block produces one play button.

## Syntax

````
```spotiplayer
label: <button label shown to the user>
uri: <a Spotify URI>
```
````

Both `label` and `uri` are required. Missing either renders an error
paragraph in place of the button.

## URI forms accepted

The play handler (`main.ts#playTrack`) branches on the URI prefix.

| Prefix | What plays |
|---|---|
| `spotify:track:<id>` | A single track. Sent to Spotify as `uris: [uri]`. |
| `spotify:playlist:<id>` | The whole playlist. Sent as `context_uri`. |
| `spotify:album:<id>` | The whole album. Sent as `context_uri`. |

Anything else returns an error to the button. Notably absent: artist URIs,
episode URIs, show URIs.

## Parser quirks (read before you get surprised)

`parseData` is a hand-rolled `key: value` reader, not a YAML parser. The
regex is `^([^:]+):\s*(.+)$`. Consequences:

- Quoting does nothing. `label: "Hello: world"` stores the value as
  `"Hello`, because the regex stops at the first colon.
- Whitespace around the key and value is trimmed.
- Unrecognised keys are silently kept in the parsed object but ignored
  downstream. Typos fail quietly.
- Blank lines and lines that don't match the regex are silently skipped.
- There is no multi-line value support.

If the block contains a real YAML error (the parser throws), the renderer
shows "Error: Invalid YAML in spotiplayer block." even though no YAML
parser is actually involved — the wording is from when one was planned.
