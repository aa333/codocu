/**
 * Plugin entry point. Wires Obsidian's settings tab, the `obsidian://`
 * protocol handler, and the `spotiplayer` markdown code-block processor
 * together with the Spotify Web API client and the OAuth authoriser.
 *
 * Reading order: `onload` is the spine — start there. The play path is
 * `PlayButton.onClick → onClick → checkToken/authenticate → selectDevice
 * → playTrack`. The auth path is `authenticate → window.open → Spotify
 * → protocol handler → handleAuthCallback → resolve promise → onTokenChanged`.
 *
 * DOC: see docs/architecture.md for the full module map and both flows.
 */
import { Plugin } from 'obsidian';
import SpotifyWebApi from 'spotify-web-api-js';
import { PlayerPluginSettingTab } from './PlayerPluginSettingTab';
import { PlayerPluginSettings, DEFAULT_SETTINGS } from './types';
import { SpotifyAuthorizer } from './SpotifyAuthorizer';
import { PlayButton } from './PlayButton';
import { Logger, LogLevel } from './Logger';

// Matches a single `key: value` line. NOT a YAML parser — it stops at the
// first colon and has no awareness of quoting, escaping, or nesting.
// DOC: docs/spotiplayer-block.md documents the user-visible consequences.
const KeyValueRegex = /^([^:]+):\s*(.+)$/;

export default class PlayerPlugin extends Plugin {
  private spotifyApi!: SpotifyWebApi.SpotifyWebApiJs;
  private authorizer!: SpotifyAuthorizer;
  private logger: Logger = new Logger(LogLevel.Info); // Set verbosity level to debug for development
  settings!: PlayerPluginSettings;

  async onload() {
    await this.loadSettings();
    this.addSettingTab(new PlayerPluginSettingTab(this.app, this));

    this.spotifyApi = new SpotifyWebApi();
    // The redirect URI string MUST match the protocol handler registered
    // below AND the redirect URI registered in the user's Spotify app.
    // Three places, one literal. See README for the setup.
    // DOC: docs/todo.md notes that settings.accessToken is read here but
    // never pushed into spotifyApi on cold start, so auth doesn't survive
    // an Obsidian restart.
    this.authorizer = new SpotifyAuthorizer(
      'obsidian://obsidian-spotiplay',
      () => this.settings,
      (accessToken) => {
        this.settings.accessToken = accessToken;
        this.saveSettings();
        this.spotifyApi.setAccessToken(accessToken);
      }
    );

    this.registerObsidianProtocolHandler('obsidian-spotiplay', async (data) => {
      const { code }: { code: string } = data as unknown as { code: string };
      await this.authorizer.handleAuthCallback({ code }, this.settings);
    });

    this.registerMarkdownCodeBlockProcessor(
      'spotiplayer',
      async (source, el) => {
        let parsedData: Record<string, string> = {};
        try {
          parsedData = this.parseData(source);
        } catch (error) {
          this.logger.error('Invalid YAML in spotiplayer block:', error);
          el.createEl('p', {
            text: 'Error: Invalid YAML in spotiplayer block.',
          });
          return;
        }

        const { label, uri } = parsedData;
        if (!label || !uri) {
          this.logger.error('Missing label or uri in spotiplayer block.');
          el.createEl('p', {
            text: 'Error: Missing label or uri in spotiplayer block.',
          });
          return;
        }

        this.createPlayButton(label, uri, el);
      }
    );
  }

  /**
   * Parses a `spotiplayer` block body into a `{ key: value }` map.
   *
   * Deliberately tiny — no YAML library, no quoting, no multi-line values.
   * Unknown keys are kept but ignored by the caller. Malformed lines are
   * silently skipped.
   * DOC: docs/spotiplayer-block.md.
   */
  parseData(source: string) {
    const parsedData: Record<string, string> = {};
    source.split('\n').forEach((line) => {
      const match = KeyValueRegex.exec(line);
      if (match) {
        const [, key, value] = match;
        parsedData[key.trim()] = value.trim();
      }
    });
    return parsedData;
  }

  /**
   * "Is our stored token still good?" Probes Spotify with a cheap call
   * (`getMyDevices`) and treats any error as token-expired. Cheap enough
   * to call before every play.
   */
  async checkToken() {
    this.logger.debug('Checking token validity...');
    if (!this.authorizer.getAccessToken()) {
      this.logger.debug('No token');
      return false;
    }
    try {
      await this.spotifyApi.getMyDevices();
    } catch (error) {
      this.logger.error('Token expired', error);
      return false;
    }
    return true;
  }

  onunload() {
    this.logger.debug('Unloading plugin...');
    this.authorizer.dispose();
  }

  /**
   * Picks the first device Spotify reports and persists it. Deliberately
   * dumb — there is no device-picker UI. If the user wants a specific
   * device they paste its ID into the settings tab.
   * DOC: docs/todo.md tracks "no device picker".
   */
  private async selectDevice() {
    const devices = await this.spotifyApi.getMyDevices();
    if (devices.devices.length === 0) {
      this.logger.error('No devices available for playback.');
      return 'No devices available for playback.';
    }
    this.settings.deviceId = devices.devices[0].id;
    await this.saveSettings();
    this.logger.debug('Selected device:', this.settings.deviceId);
  }

  /**
   * Sends a play request to Spotify. The shape of the request depends on
   * the URI: single tracks go in `uris`, playlists and albums go in
   * `context_uri`. Returns an error string on failure (or undefined on
   * success) so the caller can surface it on the button.
   * DOC: docs/spotiplayer-block.md lists the accepted URI prefixes.
   */
  private async playTrack(uri: string) {
    if (!this.settings.deviceId) {
      this.logger.error('No device selected for playback.');
      return 'No device available for playback. Make sure Spotify player is open and available.';
    }
    try {
      let uris = undefined;
      let context_uri = undefined;
      if (uri.startsWith('spotify:track:')) {
        uris = [uri];
      } else if (
        uri.startsWith('spotify:playlist:') ||
        uri.startsWith('spotify:album:')
      ) {
        context_uri = uri;
      } else {
        this.logger.error('Invalid URI format:', uri);
        return 'Invalid URI, should be "spotify:track:..." or "spotify:playlist:..." or "spotify:album:..."';
      }
      await this.spotifyApi.play({
        device_id: this.settings.deviceId,
        uris,
        context_uri,
      });
    } catch (error) {
      this.logger.error('Error playing track:', error);
      return `Error playing track. ${(error as XMLHttpRequest).responseText}`;
    }
    this.logger.debug('Playing track:', uri);
  }

  private createPlayButton(label: string, uri: string, parent: HTMLElement) {
    const btn = new PlayButton(label, uri, parent, (result) =>
      this.onClick(result)
    );
    return btn;
  }

  /**
   * The click orchestrator. Validates the token (auths if needed),
   * ensures a device is selected, and plays. Each step that can fail
   * returns an error string which is bubbled up to the button.
   */
  private async onClick(uri: string) {
    this.logger.debug('Play button clicked:', uri);
    const isTokenValid = await this.checkToken();
    if (!isTokenValid) {
      await this.authorizer.authenticate();
    }

    if (!this.authorizer.getAccessToken()) {
      return { success: false, error: `Token is null. Please authenticate.` };
    }

    let err: string | undefined = '';

    if (!this.settings.deviceId) {
      err = await this.selectDevice();
      if (err) {
        return { success: false, error: `Unable to select device: ${err}` };
      }
    }
    err = await this.playTrack(uri);
    if (err) {
      return { success: false, error: `Unable to play track: ${err}` };
    }
    return { success: true };
  }

  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
  }

  async saveSettings() {
    await this.saveData(this.settings);
  }
}
