# obsidian-spotiplayer

An Obsidian plugin that turns fenced code blocks into play buttons for your
Spotify library. Drop a `spotiplayer` block into a note, click the button,
and the track / playlist / album starts on whichever Spotify device is
currently active.

```spotiplayer
label: Morning focus
uri: spotify:playlist:37i9dQZF1DX3rxVfibe1L0
```

The block above renders as a single button labelled "🎵 Play Morning focus".
Clicking it calls the Spotify Web API and starts playback on the user's
device.

## Status

Working but rough. The happy path (first-time auth, play a track) is
exercised. Edges that are known to be brittle are listed in
[`docs/todo.md`](docs/todo.md). Open issues worth knowing before you depend
on this:

- Authentication does not survive an Obsidian restart — you re-authenticate
  on each session.
- The refresh-token path exists but has not been verified.
- The block parser accepts a YAML-like `key: value` subset, not real YAML.

## Setup

1. Register a Spotify app at <https://developer.spotify.com/dashboard>.
2. In the app's settings, add `obsidian://obsidian-spotiplay` as a redirect
   URI. This exact value is hard-coded in `src/main.ts`; if you change it
   you must change it in both places.
3. Copy the **Client ID** and **Client Secret** into the plugin's settings
   tab inside Obsidian.
4. Leave **Device ID** empty unless you want to pin playback to a specific
   device — empty means "use the first device Spotify returns".

The first time you click a play button the plugin opens the Spotify
authorisation page in your browser, Spotify redirects back to Obsidian via
the `obsidian://` protocol, and the access token is stored in plugin
settings.

## The `spotiplayer` block

Two required keys, `label` and `uri`. See
[`docs/spotiplayer-block.md`](docs/spotiplayer-block.md) for the parser's
quirks and the URI forms it accepts.

## Architecture

See [`docs/architecture.md`](docs/architecture.md) for the module map and
the two flows (auth, play).

## Repo conventions

- All longer-form docs live under `docs/`.
- Code references docs through one-line `DOC:` comments. Grep `DOC:` to
  list every backlink in the repo.
- Roadmap, TODOs, and known rough edges live in
  [`docs/todo.md`](docs/todo.md) — not scattered across the source.

## Build

```
pnpm install
pnpm run build       # one-shot build to main.js
pnpm run dev         # esbuild watch mode
pnpm run lint        # eslint src
```
