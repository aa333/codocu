export const DEFAULT_SETTINGS: PlayerPluginSettings = {
  clientId: '',
  clientSecret: '',
  deviceId: null,
  accessToken: null,
};

/**
 * Persisted plugin settings.
 *
 * - `clientId` / `clientSecret`: from the user's own Spotify app. The
 *   secret lives client-side because we have no server; the trust
 *   boundary is the user's vault. DOC: docs/architecture.md "Decisions
 *   worth knowing" discusses the tradeoff.
 * - `deviceId`: `null` means "auto-select the first device Spotify
 *   returns on the next play". A user-supplied value pins playback.
 * - `accessToken`: managed by the plugin, not the user. Persisted so a
 *   restart could in principle skip re-auth — but see
 *   docs/todo.md "Auth doesn't survive an Obsidian restart".
 */
export interface PlayerPluginSettings {
  clientId: string;
  clientSecret: string;
  deviceId: string | null;
  accessToken: string | null;
}
