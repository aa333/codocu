# Architecture

A short tour of the plugin. The code itself is the detailed spec; this doc
explains the shape and the decisions you can't infer from reading it.

## What the plugin is

A markdown-code-block processor plus a Spotify Web API client. It renders
buttons inside `spotiplayer` blocks and, on click, drives playback on the
user's active Spotify device. Obsidian gives us the markdown render hook,
the settings UI, and a custom `obsidian://` protocol handler — that last
one is the only reason an in-app OAuth flow is possible without a separate
local server.

## Module map

| File | Role |
|---|---|
| `src/main.ts` | Obsidian `Plugin` entry point. Owns the Spotify API client, the authoriser, the code-block processor, and the click handler that ties them together. |
| `src/SpotifyAuthorizer.ts` | OAuth2 authorisation-code flow against `accounts.spotify.com`. Opens the consent page, takes the redirect from the protocol handler, exchanges code for tokens, schedules refresh. |
| `src/PlayButton.ts` | The DOM button rendered into a `spotiplayer` block. Pure UI state (loading / error / idle) — does not know about Spotify. |
| `src/PlayerPluginSettingTab.ts` | The settings panel Obsidian shows under Community Plugins. Three text fields, bound to the settings object. |
| `src/types.ts` | `PlayerPluginSettings` shape and its defaults. |
| `src/Logger.ts` | Level-gated wrapper over `console.*`. Verbosity is hard-coded to `Info` in `main.ts`; change it there for development. |

## Flow: starting playback

The click path is the spine of the plugin. `main.ts#onClick` orchestrates;
everything else is supporting cast.

1. `PlayButton.onClickHandler` flips the button into "Loading…" and calls
   the callback passed in by `main.ts`.
2. `main.ts#checkToken` asks Spotify for the device list. If the call
   throws, the token is treated as expired.
3. If the token is invalid, `SpotifyAuthorizer.authenticate` runs the full
   consent flow (see below).
4. If no `deviceId` is set in settings, `main.ts#selectDevice` picks the
   first device Spotify returns and persists it. There is no UI to pick
   between devices.
5. `main.ts#playTrack` chooses between `uris` (single track) and
   `context_uri` (playlist / album) based on the URI prefix, then calls
   `spotifyApi.play`.
6. Errors bubble back to the button as strings; the button shows "Error!"
   and the message is logged.

## Flow: authentication

Spotify's authorisation-code flow, threaded through Obsidian's protocol
handler.

1. `main.ts#onload` registers a handler for `obsidian://obsidian-spotiplay`
   and constructs a `SpotifyAuthorizer` with the same URI string as its
   `redirectUri`. The two must match or the redirect from Spotify lands
   nowhere.
2. `authenticate()` builds the consent URL and calls `window.open()` on it.
   The browser takes over; the user approves; Spotify redirects to
   `obsidian://obsidian-spotiplay?code=…`.
3. Obsidian routes that URL to the protocol handler registered in step 1,
   which calls `handleAuthCallback`.
4. `handleAuthCallback` POSTs to `accounts.spotify.com/api/token` with the
   code and the client credentials, gets back access + refresh tokens,
   and resolves the promise that `authenticate()` is awaiting (via the
   stashed `authPromiseResolve`).
5. `authenticate()` calls `onTokenChanged`, which writes the token into
   settings and into the API client.
6. A `setTimeout` is scheduled to refresh the token before it expires.
   See "Rough edges" — this path is not well-tested.

The promise hand-off between `authenticate()` and `handleAuthCallback`
(via `authPromiseResolve`) is the non-obvious part. It works because
`registerObsidianProtocolHandler` and `authenticate()` are called on the
same instance during the same Obsidian session.

## Decisions worth knowing

**The client secret lives in plugin settings.** The Spotify
authorisation-code flow normally expects the secret on a server. We don't
have a server; we have an Obsidian plugin. The user pastes their own
secret for their own app; the trust boundary is the user's own Obsidian
vault. PKCE would be the better long-term answer.

**Device selection is "first device wins."** There is no device picker.
If the user wants a specific device they set `deviceId` manually in
settings. This is intentionally minimal — the plugin is a button, not a
Spotify client.

**The block parser is hand-rolled, not YAML.** `main.ts#parseData` splits
on newlines and matches `key: value` with a regex. Real YAML would pull
in a dependency for two keys. The cost is that quoting, escaping, multi-
line values, and nesting all do the wrong thing. See
[`spotiplayer-block.md`](spotiplayer-block.md).

## Rough edges

Tracked in [`todo.md`](todo.md). The code has `DOC:` comments next to
each rough spot pointing here.

## Configuration surface

- `clientId`, `clientSecret`, `deviceId` — set through the settings tab.
- `accessToken` — managed by the plugin; persisted but not user-editable.
- `LogLevel` — hard-coded in `main.ts`; flip to `Debug` while developing.
- `redirectUri` literal `obsidian://obsidian-spotiplay` — appears twice
  in `main.ts`. Must match the Spotify app's registered redirect URI.
- Refresh interval — hard-coded `3500000` ms (≈58 minutes) in
  `SpotifyAuthorizer`. Spotify tokens last 3600 s; this leaves a 100-
  second buffer.
