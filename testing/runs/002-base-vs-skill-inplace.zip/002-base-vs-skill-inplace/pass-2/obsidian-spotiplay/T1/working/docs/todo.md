# TODO and known rough edges

Tracked rough spots. Each entry is reachable from the code via a `DOC:`
comment.

## Auth doesn't survive an Obsidian restart

`SpotifyAuthorizer` reads `settings.accessToken` in its constructor and
assigns it to `this.accessToken`, but `spotifyApi.setAccessToken(...)` is
only called by `onTokenChanged`, which fires on a fresh auth. After a
restart the API client never receives the token even though it's in
settings, so `checkToken` fails and the user re-authorises every session.

The original author noted this with `// TODO doesnt work after app restart
anyway` in `SpotifyAuthorizer.ts`.

Likely fix: in `main.ts#onload`, after `loadSettings`, push
`this.settings.accessToken` into `this.spotifyApi` directly if it is
present.

## `refreshAccessToken` is unverified

Code path exists, scheduled by a `setTimeout` ~58 minutes after a
successful auth. Original author left a `// TODO test properly`. Until
someone actually runs through a refresh end-to-end, treat it as best-
effort. The plugin will recover by falling back to a full re-auth on
the next `checkToken` failure.

## Refresh interval is a magic number

`3500000` ms appears twice in `SpotifyAuthorizer`. It corresponds to
3500 seconds — 100 seconds before Spotify's default 3600-second token
TTL. Promote to a named constant when the refresh path gets attention.

## Device selection has no UI

`selectDevice` picks `devices[0]` and persists it. Users with multiple
devices either pin one manually in settings or accept whatever Spotify
returned first. A device picker (modal or settings dropdown) would be
the obvious next step.

## Block parser is not YAML but the error message says it is

See [`spotiplayer-block.md`](spotiplayer-block.md). Either swap in a
proper YAML parser or update the error string to match reality.

## Client secret on a client device

The OAuth flow is authorisation-code, which expects the client secret to
live server-side. We have no server. PKCE (authorisation-code with
PKCE, no secret) would be the right modernisation if Spotify ever
allows it cleanly through a `window.open` flow.
