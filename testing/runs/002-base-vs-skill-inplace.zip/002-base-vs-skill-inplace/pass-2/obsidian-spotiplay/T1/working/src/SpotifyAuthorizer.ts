/**
 * OAuth2 authorisation-code flow against accounts.spotify.com, threaded
 * through Obsidian's `obsidian://` protocol handler.
 *
 * The non-obvious shape: `authenticate()` and `handleAuthCallback()` are
 * two halves of the same operation, glued together by `authPromiseResolve`.
 * `authenticate` opens the consent page in a browser and parks a promise.
 * Spotify redirects back to Obsidian; the protocol handler (registered in
 * main.ts) calls `handleAuthCallback`, which posts the code for tokens
 * and resolves the parked promise.
 *
 * DOC: docs/architecture.md explains the end-to-end auth flow.
 * DOC: docs/todo.md tracks the cold-start gap (accessToken read but not
 * pushed back into the API client) and the unverified refresh path.
 */
import { PlayerPluginSettings } from './types';

// The two `setTimeout(..., 3500000)` calls below use the token refresh
// interval. Spotify access tokens last 3600 s; refreshing 100 s early
// avoids race conditions around the boundary.
// DOC: docs/todo.md "Refresh interval is a magic number" — promote to a
// named constant when the refresh path gets attention.

export class SpotifyAuthorizer {
  private accessToken: string | null = null;
  private refreshToken: string | null = null;
  private authPromiseResolve:
    | ((data: { accessToken: string; refreshToken: string } | null) => void)
    | null = null;
  private refreshTimeout: number | null = null;
  authTimeout: number | null = null;

  constructor(
    private redirectUri: string,
    private getSettings: () => PlayerPluginSettings,
    private onTokenChanged: (accessToken: string | null) => void
  ) {
    // DOC: docs/todo.md "Auth doesn't survive an Obsidian restart" —
    // we read the persisted token here but `spotifyApi.setAccessToken`
    // is only fired via onTokenChanged on a fresh auth, so the API
    // client starts each session with no token even when one exists.
    this.accessToken = getSettings().accessToken;
  }

  /**
   * Drives a full consent → tokens round-trip. Blocks the caller until
   * `handleAuthCallback` resolves the internal promise (or it times
   * out at 30 s). Scopes requested: `user-read-playback-state` and
   * `user-modify-playback-state` — read the device list and start
   * playback. No library read/write scopes.
   */
  async authenticate() {
    const scopes = 'user-read-playback-state user-modify-playback-state';
    const authUrl = `https://accounts.spotify.com/authorize?response_type=code&client_id=${this.getSettings().clientId}&redirect_uri=${encodeURIComponent(this.redirectUri)}&scope=${encodeURIComponent(scopes)}`;
    const tokenData = await this.getToken(authUrl);
    if (!tokenData) {
      console.error('Failed to get token data');
      return;
    }
    this.accessToken = tokenData.accessToken;
    this.refreshToken = tokenData.refreshToken;
    this.onTokenChanged(this.accessToken);
    if (this.refreshToken) {
      if (this.refreshTimeout) clearTimeout(this.refreshTimeout);
      this.refreshTimeout = setTimeout(() => {
        this.refreshAccessToken();
      }, 3500000); // Refresh ~58 min in — see file header comment.
    }
  }

  /**
   * Exchanges the stored refresh token for a fresh access token and
   * re-arms the refresh timer. Best-effort: on failure the next
   * `checkToken` will fall through to a full re-auth.
   * DOC: docs/todo.md "refreshAccessToken is unverified".
   */
  async refreshAccessToken() {
    if (!this.refreshToken) {
      console.error('No refresh token available.');
      return;
    }
    const tokenData = await fetch(`https://accounts.spotify.com/api/token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        Authorization:
          'Basic ' +
          btoa(
            this.getSettings().clientId + ':' + this.getSettings().clientSecret
          ),
      },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        refresh_token: this.refreshToken,
        client_id: this.getSettings().clientId,
      }),
    })
      .then((response) => response.json())
      .then((data) => ({
        accessToken: data.access_token,
        refreshToken: data.refresh_token,
      }))
      .catch((error) => {
        console.error('Error fetching token:', error);
        return null;
      });

    if (tokenData) {
      if (tokenData.accessToken) this.accessToken = tokenData.accessToken;
      if (tokenData.refreshToken) this.refreshToken = tokenData.refreshToken;
      this.onTokenChanged(this.accessToken);
      if (this.refreshToken) {
        if (this.refreshTimeout) clearTimeout(this.refreshTimeout);
        this.refreshTimeout = setTimeout(() => {
          this.refreshAccessToken();
        }, 3500000); // Refresh ~58 min in — see file header comment.
      }
    }
  }

  /**
   * Clears the refresh timer and forgets in-memory tokens. Called from
   * `main.ts#onunload`. Persisted tokens in plugin settings are NOT
   * cleared — that's a deliberate choice so the user isn't logged out
   * when they disable/re-enable the plugin.
   */
  dispose() {
    if (this.refreshTimeout) clearTimeout(this.refreshTimeout);
    this.accessToken = null;
    this.refreshToken = null;
    this.authPromiseResolve = null;
  }

  /**
   * Called by main.ts's `obsidian://obsidian-spotiplay` protocol handler
   * when Spotify redirects back with an authorisation code. Posts the
   * code (plus the client secret) to Spotify's token endpoint and
   * resolves the promise that `authenticate()` is awaiting.
   *
   * The settings argument is passed explicitly rather than read via
   * `getSettings()` so the protocol handler is the single source of
   * truth for which settings snapshot the exchange uses.
   */
  async handleAuthCallback(
    data: { code: string },
    settings: PlayerPluginSettings
  ) {
    if (this.authTimeout) clearTimeout(this.authTimeout);

    const tokenData = await fetch(`https://accounts.spotify.com/api/token`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        Authorization:
          'Basic ' + btoa(settings.clientId + ':' + settings.clientSecret),
      },
      body: new URLSearchParams({
        grant_type: 'authorization_code',
        code: data.code,
        redirect_uri: this.redirectUri,
      }),
    })
      .then((response) => response.json())
      .then((data) => ({
        accessToken: data.access_token,
        refreshToken: data.refresh_token,
      }))
      .catch((error) => {
        console.error('Error fetching token:', error);
        return null;
      });

    if (this.authPromiseResolve) this.authPromiseResolve(tokenData);
  }

  /**
   * Opens the Spotify consent page and parks a promise that the protocol
   * handler will resolve via `handleAuthCallback`. The 30 s timeout
   * exists so the plugin doesn't sit forever if the user closes the
   * browser tab without consenting.
   */
  private async getToken(
    authUrl: string
  ): Promise<{ accessToken: string; refreshToken: string } | null> {
    return new Promise((resolve, reject) => {
      this.authPromiseResolve = resolve;
      this.authTimeout = setTimeout(() => {
        this.authPromiseResolve = null;
        this.accessToken = null;
        this.refreshToken = null;
        reject(new Error('Authentication timed out'));
      }, 30000);
      window.open(authUrl);
    });
  }

  getAccessToken() {
    return this.accessToken;
  }
}
