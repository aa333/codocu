# obsidian-spotiplay

An Obsidian plugin that turns a fenced code block into a Play button for a
Spotify track, playlist, or album. Useful for embedding listenable references
inside notes — practice logs, study queues, mood boards.

````
```spotiplayer
label: Morning warmup
uri: spotify:playlist:37i9dQZF1DXcBWIGoYBM5M
```
````

Renders a single button that, on click, plays `uri` on your active Spotify
device.

## Setup

You need a Spotify developer app (free) to get a Client ID and Client Secret,
and Spotify running somewhere reachable as a playback device.

1. Create an app at https://developer.spotify.com/dashboard.
2. Add `obsidian://obsidian-spotiplay` as a Redirect URI in the app settings.
3. Open the plugin's settings tab in Obsidian and paste in Client ID and
   Client Secret. Leave Device ID blank to auto-pick the first available
   device, or set it explicitly.
4. Click any Play button — the first click opens Spotify's consent screen in
   your browser; subsequent clicks play immediately.

## Build

```
pnpm install
pnpm build       # one-shot build → main.js
pnpm dev         # esbuild watch mode
```

## Docs

- [Spotify auth flow](docs/systems/spotify-auth.md) — token lifecycle, redirect
  scheme, known limits.
- [`spotiplayer` block](docs/systems/spotiplayer-block.md) — the markdown
  contract: keys, accepted URI shapes, error surface.
- [Tech debt](docs/tech-debt.md), [Backlog](docs/todo.md).
