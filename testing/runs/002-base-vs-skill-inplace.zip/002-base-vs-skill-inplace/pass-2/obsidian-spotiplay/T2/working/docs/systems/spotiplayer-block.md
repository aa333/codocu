# `spotiplayer` markdown block

The user-facing surface of this plugin: a fenced code block with language tag
`spotiplayer` that renders as a single Play button. The contract lives across
`main.ts` (parser + renderer registration) and `PlayButton.ts` (the button
itself), so it's collected here.

## Block shape

```
```spotiplayer
label: <button label>
uri:   <spotify URI>
```
```

Parsed line-by-line with the regex `^([^:]+):\s*(.+)$` — a minimal `key:
value` shape. Whitespace around key and value is trimmed. Lines that don't
match are silently ignored, so blank lines and stray comments are tolerated.

Both `label` and `uri` are required. Missing either renders an inline error
message in place of the button.

## Accepted URIs

| Prefix | Effect |
| --- | --- |
| `spotify:track:<id>` | Plays the single track. |
| `spotify:playlist:<id>` | Plays the playlist in its order. |
| `spotify:album:<id>` | Plays the album in its order. |

Anything else surfaces "Invalid URI" on click. The plugin does not validate
the URI at render time — only when the user clicks Play.

## Click flow

1. Button enters loading state.
2. If no access token or the cached one is rejected, the auth flow runs (see
   [spotify-auth](spotify-auth.md)).
3. If no device is selected in settings, the first device returned by
   Spotify's `getMyDevices` is auto-selected and saved.
4. Playback request is sent.
5. On any failure the button surfaces "Error!" and the original button label
   is replaced; the error string is held on the button instance but not
   currently shown to the user beyond the label change.

## Why a code block, not a custom view

The block processor route means notes stay portable: the `.md` file is plain
text with a recognisable fence, so the embed degrades gracefully when the
plugin is disabled or the file is opened outside Obsidian.
