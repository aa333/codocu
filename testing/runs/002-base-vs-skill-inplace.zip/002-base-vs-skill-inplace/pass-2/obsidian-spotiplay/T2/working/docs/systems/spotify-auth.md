# Spotify auth

Owns getting and keeping a usable Spotify access token. Two flows: first-time
consent and silent refresh. Code lives in `src/SpotifyAuthorizer.ts`.

## Why this shape

Obsidian plugins run inside a desktop app, not a web origin, so the standard
"redirect to localhost" OAuth dance doesn't apply. The plugin registers an
Obsidian protocol handler for `obsidian://obsidian-spotiplay` and uses that
URL as the OAuth Redirect URI. Spotify's consent page opens in the user's
browser; on approval Spotify redirects to the protocol URL, which Obsidian
catches and routes back into the plugin. This is why the redirect URI must be
registered verbatim in the user's Spotify developer-app settings — there's no
flexibility on the receiving side.

The full secret flow (client secret in the body) is used instead of PKCE
because the plugin already needs the user's client secret for refresh, and
keeping both flows symmetric is simpler than maintaining two paths.

## Token lifecycle

- **First click on a Play button**: if there's no token (or the cached one is
  rejected by Spotify), `authenticate()` opens the consent URL, waits up to
  30 s for the protocol callback, and stores the resulting access + refresh
  tokens.
- **Access token** is persisted in plugin settings and reused across button
  clicks within a session.
- **Refresh** is scheduled ~58 minutes after each successful auth (3 500 000 ms
  — Spotify tokens expire at 60 min, so this leaves a small headroom). The
  refresh call itself uses the stored refresh token; if Spotify returns a new
  refresh token it replaces the old one.
- **`dispose()`** clears the refresh timer and the in-memory tokens. Called
  from `onunload`. Persisted settings are not touched here.

## Scopes

`user-read-playback-state user-modify-playback-state` — the minimum to list
devices and start playback. No library, profile, or playlist-modify scopes are
requested.

## Known limits

- **Restart loses session.** Although the access token is persisted in
  settings, the in-memory refresh token is not, so a new Obsidian session
  starts from full consent again. The constructor comment flags this; see
  `TD-auth-restart` in `docs/tech-debt.md`.
- **No retry on refresh failure.** `refreshAccessToken` logs and gives up;
  the next play click will fall through to full re-auth.
- **Auth timeout doesn't clear on success.** `getToken` arms a 30 s reject
  timer but never clears it after `handleAuthCallback` resolves the promise;
  the timer still fires (harmlessly, since the resolver is gone) but means
  any thrown rejection lingers in the event loop. See `TD-auth-timer-leak`.
