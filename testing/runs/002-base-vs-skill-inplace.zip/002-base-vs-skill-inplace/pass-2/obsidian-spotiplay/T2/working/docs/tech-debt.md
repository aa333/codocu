**TD-auth-restart**: Refresh token isn't persisted, so every Obsidian restart forces a full consent flow even though an access token survives in settings. Persist refresh token alongside access token, or accept the trade-off and stop persisting access token too. Anchor: `src/SpotifyAuthorizer.ts` constructor.

**TD-auth-timer-leak**: `getToken` arms a 30 s reject timer but never clears it on the success path (`handleAuthCallback`). The timer still fires; with `authPromiseResolve` already nulled it's harmless, but it's a latent leak if the timeout grows or the handler is reworked. Clear `authTimeout` once the promise resolves.

**TD-refresh-untested**: `refreshAccessToken` has never been exercised end-to-end. The code path includes a hard-coded ~58 min cadence and a refresh-token rotation branch; both need verification before the next release.
