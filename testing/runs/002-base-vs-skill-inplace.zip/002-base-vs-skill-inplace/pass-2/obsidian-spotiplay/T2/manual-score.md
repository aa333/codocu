# Manual scorecard — pass-2 / obsidian-spotiplay / T2

Tier: T2 (full Codocu skill). **Variant for this pass:** the cell was run by a cold subagent that simulated `/codocu:init` then `/codocu` by reading the actual SKILL.md files, rather than by a real `claude --plugin-dir` session. See `transcript.md` for the caveats — no user-in-the-loop init confirmation, no `codocu-reviewer` subagent, etc.

Fill in by hand. Each numeric score is 1–5 unless noted.

## Scores

| # | Criterion | Score | Notes |
|---|---|---|---|
| 1 | Principle adherence — does each sentence say something code can't? |  |  |
| 2 | Refactor resistance — would this survive a rename, extract, or inline? |  |  |
| 3 | Bloat — judged against a minimum-viable mental version of the same doc set. (5 = lean; 1 = bloated) |  |  |
| 4 | Code-restating count | (list sentences with file refs) |  |
| 5 | Voice — busy-tired-reader (5) vs reference material (1). |  |  |

## Free-form notes

T2 agent rewrote existing free-form `// TODO` comments as `TODO TD-…` markers anchored to `docs/tech-debt.md` entries. Same boundary question as T1's removal of TODOs — likely fair-game inline-doc work, but flagged for the scorer.
