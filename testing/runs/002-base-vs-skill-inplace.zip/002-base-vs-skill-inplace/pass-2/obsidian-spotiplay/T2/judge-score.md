# Judge score — pass-2 / obsidian-spotiplay / T2

Cold judge subagent given: principles.md + doc-standard.md + all new `.md` files under `T2/working/` + inline doc diffs against the fixture. No transcript, no rubric file, no other tier's output.

## Scores

1. **Principle adherence — 5.** Nearly every sentence carries something code can't: rationale for `obsidian://` protocol (not PKCE), 30s timer behavior, "auth timeout doesn't clear on success", restart-loses-refresh-token, the deliberate tolerance of stray block lines, scope minimum justification. The block-shape table names a public surface, which the standard explicitly permits.

2. **Refactor resistance — 4.** Most prose talks meaning rather than symbols, and would survive renames of `playTrack`, `PlayButton`, `LogLevel`. The two soft spots: spotiplayer-block.md quotes the regex literally (`^([^:]+):\s*(.+)$`), and tech-debt entries pin to specific method names (`handleAuthCallback`, `authTimeout`, `refreshAccessToken`) — though those are deliberate anchors and the rule permits naming public/load-bearing surfaces.

3. **Bloat — 5.** Two short system docs plus a README, tech-debt, and an empty backlog file. Each section earns its keep — Why-this-shape, lifecycle, known limits, click flow. No tables of contents, no boilerplate sections, no exhaustive API enumeration. The inline docstrings are 2–6 lines each. About as lean as this fixture allows.

4. **Voice — 5.** Conversational, second-person where useful ("you need a Spotify developer app"), short declaratives ("Restart loses session"). No reference-manual tone, no enumerated guarantees, no defensive qualification.

## Code-restating sentences

- "Parsed line-by-line with the regex `^([^:]+):\s*(.+)$` — a minimal `key: value` shape." — `docs/systems/spotiplayer-block.md`. The literal regex restates what the code says; "minimal key: value shape" would have been enough.
- "**`dispose()`** clears the refresh timer and the in-memory tokens. Called from `onunload`." — `docs/systems/spotify-auth.md`. Names and describes the cleanup method at the level the implementation already shows; the only non-code bit ("Persisted settings are not touched here") is fine, the preceding sentence is restating.
- "`error` always prints; the other levels only print when verbosity is set at or above them." — docstring on `Logger` in `src/Logger.ts`. The `if (this.logLevel >= LogLevel.X)` body says this directly; the "set once at construction… to silence chatty logs in release builds" half is the part that earns the docstring.
- "Tracks go in `uris` (an array), playlists and albums go in `context_uri` (the collection itself)." — docstring on `playTrack` in `src/main.ts`. The function body literally branches on these two shapes; the value the doc adds ("Routes a Spotify URI to the right `play` argument shape") sits in the first sentence, and the rest transcribes.

## Overall verdict

A strong, lean run. The aux docs concentrate on negative-space material — protocol-handler rationale, scope choice, lifecycle timing, three concrete tech-debt entries with anchors — and the inline docstrings stick to meaning and quirks rather than re-narrating method bodies. Backlinks are placed where editors will see them (top of `main.ts`, top of `SpotifyAuthorizer.ts`) and TODOs were upgraded to typed `TD-…` anchors that round-trip to tech-debt.md. The few code-restating sentences are localized (one regex echo, one Logger gate description, one playTrack branch enumeration, one dispose description) and don't outweigh the document's earned content. `codocu.md` and `CLAUDE.md` are unchanged template/config, no bloat there. The whole set could lose ~5 sentences without anyone noticing — that's the right scale of imperfection for this fixture.
