Just run the init + orientation + fresh docs on a small bot repo (`../bots/bobatler`)

Results are not very good. Structure is solid, but long term aux docs are extensive and mostly restate what code already says. Which is understandable, where'd Codocu get other context if it only has code?


I've left some METADOCU marks. Also
1. no internal docs offered - left a todo here
2. most of the docs basically repeat code even though principles should be absolutely clear on that. My only guess is we dont clearly communicate what does "repeating code" mean to a cold agent. 
3. docs are bloated. If we rewrite file with my desired level of brevity, the whole summary of module will take just 1-2 paragraphs. We need to steer the skill away from making this shit up. Perhaps agent is tilted towards producing a certain mass of output? need to deep-check system harness for that, only claude meta-awareness can do and counter that.
4. I've used dev skill for a simple refactoring, inline with codocu session. dev skill removed a constant, but left it in the docs. Not sure how we can combat that, except maybe asking to run codocu after changes to see if docs are still intact
- if small change, inline
- if plan, plan must include codocu review step
The only place we can orchestrate that is CLAUDE.md, hence init skill should a) write that and b) have a template string to write into CLAUDE.md so we can tune it better. This template string may be inlined into skill since it ,may (and should) be small 

2, 3 are worst offenders.
Maybe it would help to give skill alternatives for making the shit up:
- ask user per-module/system what's the business value/description is? offer some best guesses?
- just leave barebone docs 
- your options?


Also, I think we need to draft a proper test suite, not the chaotic bunch we have now. That one should mostly be archived, except maybe for the fixtures.
And the first suite to have is:
    - example of code modules (can get some systems from ../bots/bobatler)
    - run cold agent with only base docs (principles/maybe doc standarts, maybe both)
    - assess results
    - this way we can at least better pinpoint whether we have problems with base or with skill

