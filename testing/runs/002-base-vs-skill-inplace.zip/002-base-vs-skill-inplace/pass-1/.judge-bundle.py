"""Assemble a judge-input bundle for one (fixture, cell) pair.

Usage: py .judge-bundle.py <fixture_root> <working_root> <out_path>
"""
import sys, os, difflib, io

def list_md(root):
    out = set()
    for d, _, fs in os.walk(root):
        for f in fs:
            if f.endswith(".md"):
                rel = os.path.relpath(os.path.join(d, f), root).replace("\\", "/")
                out.add(rel)
    return out

def list_code(root):
    out = set()
    for d, _, fs in os.walk(root):
        for f in fs:
            if f.endswith(".py") or f.endswith(".ts") or f.endswith(".js"):
                rel = os.path.relpath(os.path.join(d, f), root).replace("\\", "/")
                out.add(rel)
    return out

def read(p):
    try:
        with open(p, encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        return ""

fixture, working, out_path = sys.argv[1], sys.argv[2], sys.argv[3]

fx_md = list_md(fixture)
wk_md = list_md(working)
new_md = sorted(wk_md - fx_md)

buf = io.StringIO()
buf.write("# NEW AUXILIARY DOCS\n\n")
for rel in new_md:
    full = os.path.join(working, rel)
    buf.write(f"## {rel}\n\n")
    buf.write("```markdown\n")
    buf.write(read(full).rstrip())
    buf.write("\n```\n\n")

buf.write("\n# INLINE-DOC DIFFS (fixture vs working)\n\n")
all_code = list_code(fixture) | list_code(working)
for rel in sorted(all_code):
    fx = read(os.path.join(fixture, rel))
    wk = read(os.path.join(working, rel))
    if fx == wk:
        continue
    diff = list(difflib.unified_diff(
        fx.splitlines(), wk.splitlines(),
        fromfile=f"fixture/{rel}", tofile=f"working/{rel}",
        lineterm=""))
    if not diff:
        continue
    buf.write(f"## {rel}\n\n")
    buf.write("```diff\n")
    for line in diff:
        buf.write(line + "\n")
    buf.write("```\n\n")

with open(out_path, "w", encoding="utf-8") as f:
    f.write(buf.getvalue())
