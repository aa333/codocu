from abc import ABC, abstractmethod


class Module(ABC):
    """Base unit of feature work.

    A module owns a folder under ``src/modules/<name>/`` with a service
    (logic, no Telegram), a bot_connector (Telegram glue), and optional
    models/strings/types. The split is the convention that keeps logic
    testable. See docs/adding-a-module.md.

    Two-phase init: ``__init__`` says "I exist"; ``init()`` says "I can
    see everyone else". Only inside ``init()`` is it safe to look up
    peer modules via ``di.get(...)``. See docs/architecture.md.
    """

    # Lookup key. Also the prefix for /help callback data and the value
    # ModuleList.get() expects.
    name: str
    # Label shown to users (e.g. on /help buttons).
    str_name: str
    # Owner-only modules: hidden from /help unless the caller is in
    # config.owner_ids.
    is_system: bool = False
    # Documentation for the reader; the framework does not enforce order.
    # The real ordering knob is MODULE_CLASSES in app.py.
    depends_on: tuple[str, ...] = ()
    # Peewee models to create tables for at startup.
    models: tuple[type, ...] = ()

    async def init(self) -> None:
        """Resolve peers and register handlers. Runs after every module
        is constructed and present in DI."""

    @abstractmethod
    def help(self) -> str | None:
        """Return help text for this module, or None."""

    @abstractmethod
    async def debug(self) -> str:
        """Return debug/status info string."""
