# simple-bot

A small Telegram group-chat bot. Its job is to keep groups tidy:

- challenge newcomers with a captcha so spam accounts can't walk in,
- track who actually participates in each chat,
- expose a help menu users can browse, and
- give the owner a few operational commands (`/ping`, `/debug`, `/sleep`).

The user-facing strings are Russian; the code and configuration are English.

## Run it

1. Create `config.json` from `config.example.json` and fill in:
   - `tg_token` — bot token from [@BotFather](https://t.me/BotFather);
   - `owner_ids` — Telegram user IDs allowed to use `/ping`, `/debug`, `/sleep`.
2. `python -m src.app`

The SQLite database is created on first run at `db.path`.

## Where to read next

- [`docs/architecture.md`](docs/architecture.md) — how the pieces fit
  together: modules, DI, the message pipeline, what happens on a new join.
- [`docs/adding-a-module.md`](docs/adding-a-module.md) — the convention for
  growing the bot. New work nearly always goes here.
- [`docs/tech-debt.md`](docs/tech-debt.md) — known rough edges that are
  intentional, so you can tell them from bugs.
