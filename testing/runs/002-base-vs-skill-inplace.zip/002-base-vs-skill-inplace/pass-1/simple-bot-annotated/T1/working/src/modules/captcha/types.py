from dataclasses import dataclass
from enum import Enum

# Joins older than this (seconds) are skipped without a challenge. The
# bot was probably down — the user has either settled in or already left,
# and a late challenge is more annoying than useful.
CAPTCHA_OUTDATED_TIMEOUT = 45


class ChallengeStatus(Enum):
    ONGOING = 1
    PASSED = 2
    ABORTED = 3


class JoinOutcome(Enum):
    PASSED = "passed"
    FAILED = "failed"
    SKIPPED = "skipped"
    ABORTED = "aborted"


@dataclass
class CaptchaChallenge:
    chat_id: int
    user_id: int
    captcha_message_id: int
    answer: str
    time_left: int
    status: ChallengeStatus = ChallengeStatus.ONGOING

    def __str__(self) -> str:
        return (
            f"{self.chat_id}:{self.user_id} ans:{self.answer} st:{self.status} t:{self.time_left}"
        )
