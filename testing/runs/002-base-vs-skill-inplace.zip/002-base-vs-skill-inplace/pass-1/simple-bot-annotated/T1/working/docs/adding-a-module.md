# Adding a module

The bot grows one module at a time. A module is a folder under
`src/modules/<name>/` with this shape:

```
src/modules/<name>/
  __init__.py        re-exports the Module subclass
  module.py          the Module subclass (lifecycle, help, debug)
  service.py         business logic; no Telegram imports
  bot_connector.py   Telegram glue: register handlers, format replies
  models.py          Peewee models (only if persisting)
  strings.py         user-facing text
  types.py           internal enums/dataclasses (optional)
```

Not every file is required — a module with no persistence skips `models.py`,
a module with no enums skips `types.py`. The split between `service.py` and
`bot_connector.py` is the part to keep: the service holds state and rules
and stays testable without `pytelegrambotapi`; the connector translates to
and from Telegram.

## Steps

1. Create the folder and a `Module` subclass:

   ```python
   class FooModule(Module):
       name = "foo"          # used in /help callbacks and ModuleList.get
       str_name = "Foo"      # what users see on the /help button
       depends_on = ("chats",)   # documentation; not enforced
       models = (FooRow,)         # if you have Peewee models
   ```

2. Keep `__init__` empty of cross-module work — peer modules may not
   exist yet. Construct your service here and stash `None` placeholders
   for anything you'll resolve later.

3. In `async init()`, resolve peers and the bot from DI, build the
   connector, and call `connector.register(bot)`:

   ```python
   async def init(self) -> None:
       bot = di.get(AsyncTeleBot)
       config = di.get(AppConfig)
       chats = di.get(ChatsModule)
       self._conn = FooBotConnector(self.service, chats.service)
       self._conn.register(bot)
   ```

4. Implement `help()` (return a Markdown string or `None`) and
   `async debug()` (return a short status string for `/debug`).

5. Register the class in `app.py`'s `MODULE_CLASSES`. Put it **after** any
   module it reads from — `app.py` instantiates modules in this order, and
   `db.create_tables` runs against the combined `models` tuple, so the
   ordering also fixes the table creation order if it matters.

## What you get for free

- `/help` will show your module's button as soon as `help()` returns
  non-None.
- `/debug` will include your `debug()` output.
- `app.py` will create your Peewee tables on startup.
- The cleanup-message button (`callback_data="cleanup_message"`) is
  registered by `SystemBotConnector`; you can re-use it in any reply.

## What you should not do

- Don't register handlers in `__init__`. `AsyncTeleBot` is not in DI yet.
- Don't import another module's `module.py` at module scope if that
  module imports yours — resolve via `di.get` inside `init()` instead.
- Don't write Telegram code inside `service.py`. If you find yourself
  needing `bot` there, it belongs on the connector.
- Don't add a second handler for a content type another module already
  owns (e.g. `left_chat_member`) unless your reaction is genuinely
  independent of theirs — both will fire.

## Owner-only features

If a command is for the bot owner only:

- In the handler, call `is_owner(message, self._owner_ids)` first and
  `return` on a miss. Don't reply — non-owners shouldn't learn the command
  exists.
- If the whole module is owner-only, set `is_system = True` on the
  `Module` subclass. The `/help` menu will hide it from non-owners.
