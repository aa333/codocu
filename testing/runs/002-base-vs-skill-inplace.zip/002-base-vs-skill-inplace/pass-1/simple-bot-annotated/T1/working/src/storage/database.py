from peewee import Model, SqliteDatabase

# Lazy-bound handle. Peewee needs Model classes to reference the database
# at import time, but the actual file path is only known after config is
# loaded — so we declare with None and finish wiring in init_db().
db = SqliteDatabase(None)


class BaseModel(Model):
    """Inherit instead of peewee.Model so the shared `db` handle is used."""

    class Meta:
        database = db


def init_db(path: str) -> None:
    db.init(path, pragmas={"journal_mode": "wal", "foreign_keys": 1})
    db.connect()
