# Tech debt and intentional rough edges

These things look wrong on first read but are deliberate. If you change
one, know what you're changing.

## `SystemService.sleep` uses `time.sleep`, not `asyncio.sleep`

`src/modules/system/service.py`. The blocking sleep is the whole point of
`/sleep`: it freezes `infinity_polling` so a second instance can take over
without both bots fighting for updates. Switching to `asyncio.sleep` would
defeat the command.

## 1-second gap between `ban_chat_member` and `unban_chat_member`

`src/modules/captcha/bot_connector.py`, in `_run_challenge`. The "kick"
sequence is ban-then-unban so the user can rejoin later. Without the
sleep, the unban can race the ban on Telegram's side and `only_if_banned`
silently no-ops, leaving the user banned.

## `~` is a wildcard captcha answer

`src/modules/captcha/service.py`, `check_answer`. Any challenge whose
stored answer is `~` accepts any reply. There's currently no production
use, but the branch is kept so test fixtures and manual checks can be
written without solving the math.

## Outdated joins are silently skipped

`src/modules/captcha/bot_connector.py`, `CAPTCHA_OUTDATED_TIMEOUT = 45`.
If the bot wakes up to a `new_chat_members` event more than 45 seconds
old, it doesn't run a challenge — the user has either already settled in
or already left, and a late challenge would be annoying. If they're still
a `member`, we reply once with `OUTDATED` so they know what happened.

## `pyright: ignore[reportArgumentType]` on handler registration

`pytelegrambotapi`'s stubs don't model the `pass_bot=True` callback
signature, so the typed handler `(message, bot)` doesn't match the stub.
The ignore is local to each `register_message_handler` call.

## DI is a module-level dict

`src/core/di.py`. Process-global. That's fine for a single-process bot but
means tests must reset `_registry` between cases.

## Captcha "intercept" lives in `app.py`, not in a handler chain

`app.py:handle_message` checks `captcha.has_ongoing` before doing anything
else. There's no priority system in `pytelegrambotapi` we could lean on,
so the gate is hand-coded at the top of the message handler. If you add
another "must run before normal traffic" check, put it next to this one
and document why.
