# Architecture

This describes how the pieces wire together and what isn't obvious from any
single file. For the layout of a single module see
[`adding-a-module.md`](adding-a-module.md).

## The shape

```
src/
  app.py              entry point: load config, register DI, start polling
  core/
    module.py         Module ABC — base unit of functionality
    di.py             tiny dict-backed DI container, plus ModuleList
    config.py         AppConfig and the JSON loader
    strings.py        shared user-facing strings (button labels, etc.)
  connectors/
    telegram/         thin pytelegrambotapi adapter
  storage/
    database.py       Peewee SQLite handle, shared by every model
  modules/
    captcha/          newcomer challenge
    chats/            membership tracking
    help/             /help menu
    system/           /ping, /debug, /sleep (owner-only)
```

## The Module pattern

A **module** is the unit of feature work. Each module owns a folder under
`src/modules/<name>/` with the same internal layout:

| File | Role |
| --- | --- |
| `module.py` | `Module` subclass. Lifecycle, DI registration, `help()` and `debug()`. |
| `service.py` | Pure business logic. No Telegram imports. Holds state (caches, in-memory lists, etc.). |
| `bot_connector.py` | Glue to Telegram: registers handlers, formats replies, calls into the service. |
| `models.py` | Peewee model classes (only if the module persists data). |
| `strings.py` | User-facing text, kept out of the logic. |
| `types.py` | Enums / dataclasses the module exposes internally. |

The split exists so the service stays testable without Telegram. New work
nearly always goes inside a module; see [`adding-a-module.md`](adding-a-module.md).

## Startup and the two-phase init

`app.py` runs in a fixed order, and each phase exists because the next one
needs it:

1. **Load config** (`load_config`).
2. **Open the database** (`init_db`). Peewee's `db` handle is a singleton
   bound to a path here.
3. **Create the bot** (`create_bot`) and register `AppConfig` and
   `AsyncTeleBot` in the DI container.
4. **Instantiate every module**, then register each by its concrete class.
   Constructors must do no cross-module work — at this point not all
   modules exist yet.
5. **Register `ModuleList`** so any module can iterate or look up peers.
6. **Create tables** from each module's `models` tuple.
7. **Call `Module.init()` on every module.** Now — and only now — modules
   may resolve peers via `di.get(...)` and register their bot handlers.

The two phases (`__init__` and `init`) are the load-bearing convention.
`__init__` is "I exist"; `init` is "I can see everyone else." Skipping the
split means whichever module gets instantiated first can't see modules that
don't exist yet.

`MODULE_CLASSES` order in `app.py` doesn't drive the two-phase init — every
module's `__init__` runs before any module's `init`. The ordering exists
because the **table-creation step** between the two phases needs `chats`
before `captcha`'s checks on membership, and because deterministic order
makes startup logs comparable.

## DI in one paragraph

`src/core/di.py` is a `dict[type, instance]` with `register` and `get`. It
is not a framework — there is no autowiring, no scopes. Modules register
themselves by class in `app.py`, and resolve peers by class in their own
`init`. `ModuleList` is a typed wrapper so a module can ask "who else is
loaded" without knowing concrete classes.

## The message pipeline

Every message in a group chat lands in `handle_message` in `app.py`. The
order there is the policy:

1. Drop anything that isn't a group/supergroup.
2. **If the sender has an active captcha challenge, treat the message as a
   captcha answer and stop.** This is why the captcha check sits in
   `app.py` and not inside `chats` — the user hasn't proven they're human
   yet, so their messages must not count as participation.
3. Otherwise, hand the message to `ChatsService.touch()` to update
   membership.

`new_chat_members` events go to `handle_new_member` and launch a captcha
challenge. `left_chat_member` events are *not* routed through `app.py`;
both `captcha` and `chats` register their own handlers for that content
type — captcha to abort an in-flight challenge, chats to mark the row
as out-of-chat. That's deliberate: each module owns its reaction.

## What "known" means and why it has a threshold

`ChatsService` tracks `(chat_id, user_id)` pairs that have sent at least
`MESSAGES_TO_BE_KNOWN = 3` messages. Below that, the pair lives only in an
in-memory `_watch` counter and is never persisted.

The threshold exists so the captcha gate has a meaningful "known user"
signal: if someone has talked in a chat before, they don't get re-challenged
on a rejoin (see `CaptchaBotConnector.handle_join`). One stray message
shouldn't earn that status, so the bot waits for a small streak.

## Owner-only commands

`/ping`, `/debug`, `/sleep` and the cleanup callback all check
`is_owner(message, owner_ids)` first and silently return on a miss. They
deliberately don't reply on rejection — a non-owner shouldn't even learn
the commands exist. The help menu also hides system-only modules unless
the caller is an owner (`is_system = True` on `SystemModule`).

## Shared widgets across modules

Two pieces of UI are explicitly cross-module by design:

- **The cleanup-message button** (the "Удалить" button under `/debug` and
  `/help` replies). The `cleanup_message` callback is registered once, by
  `SystemBotConnector`. `HelpBotConnector` emits buttons with that
  `callback_data` and relies on system having registered the handler.
  Don't register it twice.
- **`/help` menu contents.** `HelpService` iterates `ModuleList` and shows
  every module whose `help()` returns non-None (filtered by `is_system`).
  Adding a module with a `help()` string is enough; no list to update.

## Persistence

Only `chats` persists anything today (`ChatMembership`). The pattern is:
declare your Peewee models in `models.py`, list them in `Module.models`,
and `app.py` will create the tables for you. SQLite with WAL and foreign
keys on (see `storage/database.py`).

## What's deliberately rough

A few things look like bugs and aren't. They live in
[`tech-debt.md`](tech-debt.md):

- `SystemService.sleep` blocks the event loop on purpose.
- A 1-second `asyncio.sleep` between `ban_chat_member` and
  `unban_chat_member` in the captcha timeout flow.
- `~` as a captcha answer always passes.
- Captcha challenges older than 45 seconds are silently skipped.
