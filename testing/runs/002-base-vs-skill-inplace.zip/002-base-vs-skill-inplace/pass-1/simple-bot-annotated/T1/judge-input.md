# NEW AUXILIARY DOCS

## README.md

```markdown
# simple-bot

A small Telegram group-chat bot. Its job is to keep groups tidy:

- challenge newcomers with a captcha so spam accounts can't walk in,
- track who actually participates in each chat,
- expose a help menu users can browse, and
- give the owner a few operational commands (`/ping`, `/debug`, `/sleep`).

The user-facing strings are Russian; the code and configuration are English.

## Run it

1. Create `config.json` from `config.example.json` and fill in:
   - `tg_token` — bot token from [@BotFather](https://t.me/BotFather);
   - `owner_ids` — Telegram user IDs allowed to use `/ping`, `/debug`, `/sleep`.
2. `python -m src.app`

The SQLite database is created on first run at `db.path`.

## Where to read next

- [`docs/architecture.md`](docs/architecture.md) — how the pieces fit
  together: modules, DI, the message pipeline, what happens on a new join.
- [`docs/adding-a-module.md`](docs/adding-a-module.md) — the convention for
  growing the bot. New work nearly always goes here.
- [`docs/tech-debt.md`](docs/tech-debt.md) — known rough edges that are
  intentional, so you can tell them from bugs.
```

## docs/adding-a-module.md

```markdown
# Adding a module

The bot grows one module at a time. A module is a folder under
`src/modules/<name>/` with this shape:

```
src/modules/<name>/
  __init__.py        re-exports the Module subclass
  module.py          the Module subclass (lifecycle, help, debug)
  service.py         business logic; no Telegram imports
  bot_connector.py   Telegram glue: register handlers, format replies
  models.py          Peewee models (only if persisting)
  strings.py         user-facing text
  types.py           internal enums/dataclasses (optional)
```

Not every file is required — a module with no persistence skips `models.py`,
a module with no enums skips `types.py`. The split between `service.py` and
`bot_connector.py` is the part to keep: the service holds state and rules
and stays testable without `pytelegrambotapi`; the connector translates to
and from Telegram.

## Steps

1. Create the folder and a `Module` subclass:

   ```python
   class FooModule(Module):
       name = "foo"          # used in /help callbacks and ModuleList.get
       str_name = "Foo"      # what users see on the /help button
       depends_on = ("chats",)   # documentation; not enforced
       models = (FooRow,)         # if you have Peewee models
   ```

2. Keep `__init__` empty of cross-module work — peer modules may not
   exist yet. Construct your service here and stash `None` placeholders
   for anything you'll resolve later.

3. In `async init()`, resolve peers and the bot from DI, build the
   connector, and call `connector.register(bot)`:

   ```python
   async def init(self) -> None:
       bot = di.get(AsyncTeleBot)
       config = di.get(AppConfig)
       chats = di.get(ChatsModule)
       self._conn = FooBotConnector(self.service, chats.service)
       self._conn.register(bot)
   ```

4. Implement `help()` (return a Markdown string or `None`) and
   `async debug()` (return a short status string for `/debug`).

5. Register the class in `app.py`'s `MODULE_CLASSES`. Put it **after** any
   module it reads from — `app.py` instantiates modules in this order, and
   `db.create_tables` runs against the combined `models` tuple, so the
   ordering also fixes the table creation order if it matters.

## What you get for free

- `/help` will show your module's button as soon as `help()` returns
  non-None.
- `/debug` will include your `debug()` output.
- `app.py` will create your Peewee tables on startup.
- The cleanup-message button (`callback_data="cleanup_message"`) is
  registered by `SystemBotConnector`; you can re-use it in any reply.

## What you should not do

- Don't register handlers in `__init__`. `AsyncTeleBot` is not in DI yet.
- Don't import another module's `module.py` at module scope if that
  module imports yours — resolve via `di.get` inside `init()` instead.
- Don't write Telegram code inside `service.py`. If you find yourself
  needing `bot` there, it belongs on the connector.
- Don't add a second handler for a content type another module already
  owns (e.g. `left_chat_member`) unless your reaction is genuinely
  independent of theirs — both will fire.

## Owner-only features

If a command is for the bot owner only:

- In the handler, call `is_owner(message, self._owner_ids)` first and
  `return` on a miss. Don't reply — non-owners shouldn't learn the command
  exists.
- If the whole module is owner-only, set `is_system = True` on the
  `Module` subclass. The `/help` menu will hide it from non-owners.
```

## docs/architecture.md

```markdown
# Architecture

This describes how the pieces wire together and what isn't obvious from any
single file. For the layout of a single module see
[`adding-a-module.md`](adding-a-module.md).

## The shape

```
src/
  app.py              entry point: load config, register DI, start polling
  core/
    module.py         Module ABC — base unit of functionality
    di.py             tiny dict-backed DI container, plus ModuleList
    config.py         AppConfig and the JSON loader
    strings.py        shared user-facing strings (button labels, etc.)
  connectors/
    telegram/         thin pytelegrambotapi adapter
  storage/
    database.py       Peewee SQLite handle, shared by every model
  modules/
    captcha/          newcomer challenge
    chats/            membership tracking
    help/             /help menu
    system/           /ping, /debug, /sleep (owner-only)
```

## The Module pattern

A **module** is the unit of feature work. Each module owns a folder under
`src/modules/<name>/` with the same internal layout:

| File | Role |
| --- | --- |
| `module.py` | `Module` subclass. Lifecycle, DI registration, `help()` and `debug()`. |
| `service.py` | Pure business logic. No Telegram imports. Holds state (caches, in-memory lists, etc.). |
| `bot_connector.py` | Glue to Telegram: registers handlers, formats replies, calls into the service. |
| `models.py` | Peewee model classes (only if the module persists data). |
| `strings.py` | User-facing text, kept out of the logic. |
| `types.py` | Enums / dataclasses the module exposes internally. |

The split exists so the service stays testable without Telegram. New work
nearly always goes inside a module; see [`adding-a-module.md`](adding-a-module.md).

## Startup and the two-phase init

`app.py` runs in a fixed order, and each phase exists because the next one
needs it:

1. **Load config** (`load_config`).
2. **Open the database** (`init_db`). Peewee's `db` handle is a singleton
   bound to a path here.
3. **Create the bot** (`create_bot`) and register `AppConfig` and
   `AsyncTeleBot` in the DI container.
4. **Instantiate every module**, then register each by its concrete class.
   Constructors must do no cross-module work — at this point not all
   modules exist yet.
5. **Register `ModuleList`** so any module can iterate or look up peers.
6. **Create tables** from each module's `models` tuple.
7. **Call `Module.init()` on every module.** Now — and only now — modules
   may resolve peers via `di.get(...)` and register their bot handlers.

The two phases (`__init__` and `init`) are the load-bearing convention.
`__init__` is "I exist"; `init` is "I can see everyone else." Skipping the
split means whichever module gets instantiated first can't see modules that
don't exist yet.

`MODULE_CLASSES` order in `app.py` doesn't drive the two-phase init — every
module's `__init__` runs before any module's `init`. The ordering exists
because the **table-creation step** between the two phases needs `chats`
before `captcha`'s checks on membership, and because deterministic order
makes startup logs comparable.

## DI in one paragraph

`src/core/di.py` is a `dict[type, instance]` with `register` and `get`. It
is not a framework — there is no autowiring, no scopes. Modules register
themselves by class in `app.py`, and resolve peers by class in their own
`init`. `ModuleList` is a typed wrapper so a module can ask "who else is
loaded" without knowing concrete classes.

## The message pipeline

Every message in a group chat lands in `handle_message` in `app.py`. The
order there is the policy:

1. Drop anything that isn't a group/supergroup.
2. **If the sender has an active captcha challenge, treat the message as a
   captcha answer and stop.** This is why the captcha check sits in
   `app.py` and not inside `chats` — the user hasn't proven they're human
   yet, so their messages must not count as participation.
3. Otherwise, hand the message to `ChatsService.touch()` to update
   membership.

`new_chat_members` events go to `handle_new_member` and launch a captcha
challenge. `left_chat_member` events are *not* routed through `app.py`;
both `captcha` and `chats` register their own handlers for that content
type — captcha to abort an in-flight challenge, chats to mark the row
as out-of-chat. That's deliberate: each module owns its reaction.

## What "known" means and why it has a threshold

`ChatsService` tracks `(chat_id, user_id)` pairs that have sent at least
`MESSAGES_TO_BE_KNOWN = 3` messages. Below that, the pair lives only in an
in-memory `_watch` counter and is never persisted.

The threshold exists so the captcha gate has a meaningful "known user"
signal: if someone has talked in a chat before, they don't get re-challenged
on a rejoin (see `CaptchaBotConnector.handle_join`). One stray message
shouldn't earn that status, so the bot waits for a small streak.

## Owner-only commands

`/ping`, `/debug`, `/sleep` and the cleanup callback all check
`is_owner(message, owner_ids)` first and silently return on a miss. They
deliberately don't reply on rejection — a non-owner shouldn't even learn
the commands exist. The help menu also hides system-only modules unless
the caller is an owner (`is_system = True` on `SystemModule`).

## Shared widgets across modules

Two pieces of UI are explicitly cross-module by design:

- **The cleanup-message button** (the "Удалить" button under `/debug` and
  `/help` replies). The `cleanup_message` callback is registered once, by
  `SystemBotConnector`. `HelpBotConnector` emits buttons with that
  `callback_data` and relies on system having registered the handler.
  Don't register it twice.
- **`/help` menu contents.** `HelpService` iterates `ModuleList` and shows
  every module whose `help()` returns non-None (filtered by `is_system`).
  Adding a module with a `help()` string is enough; no list to update.

## Persistence

Only `chats` persists anything today (`ChatMembership`). The pattern is:
declare your Peewee models in `models.py`, list them in `Module.models`,
and `app.py` will create the tables for you. SQLite with WAL and foreign
keys on (see `storage/database.py`).

## What's deliberately rough

A few things look like bugs and aren't. They live in
[`tech-debt.md`](tech-debt.md):

- `SystemService.sleep` blocks the event loop on purpose.
- A 1-second `asyncio.sleep` between `ban_chat_member` and
  `unban_chat_member` in the captcha timeout flow.
- `~` as a captcha answer always passes.
- Captcha challenges older than 45 seconds are silently skipped.
```

## docs/tech-debt.md

```markdown
# Tech debt and intentional rough edges

These things look wrong on first read but are deliberate. If you change
one, know what you're changing.

## `SystemService.sleep` uses `time.sleep`, not `asyncio.sleep`

`src/modules/system/service.py`. The blocking sleep is the whole point of
`/sleep`: it freezes `infinity_polling` so a second instance can take over
without both bots fighting for updates. Switching to `asyncio.sleep` would
defeat the command.

## 1-second gap between `ban_chat_member` and `unban_chat_member`

`src/modules/captcha/bot_connector.py`, in `_run_challenge`. The "kick"
sequence is ban-then-unban so the user can rejoin later. Without the
sleep, the unban can race the ban on Telegram's side and `only_if_banned`
silently no-ops, leaving the user banned.

## `~` is a wildcard captcha answer

`src/modules/captcha/service.py`, `check_answer`. Any challenge whose
stored answer is `~` accepts any reply. There's currently no production
use, but the branch is kept so test fixtures and manual checks can be
written without solving the math.

## Outdated joins are silently skipped

`src/modules/captcha/bot_connector.py`, `CAPTCHA_OUTDATED_TIMEOUT = 45`.
If the bot wakes up to a `new_chat_members` event more than 45 seconds
old, it doesn't run a challenge — the user has either already settled in
or already left, and a late challenge would be annoying. If they're still
a `member`, we reply once with `OUTDATED` so they know what happened.

## `pyright: ignore[reportArgumentType]` on handler registration

`pytelegrambotapi`'s stubs don't model the `pass_bot=True` callback
signature, so the typed handler `(message, bot)` doesn't match the stub.
The ignore is local to each `register_message_handler` call.

## DI is a module-level dict

`src/core/di.py`. Process-global. That's fine for a single-process bot but
means tests must reset `_registry` between cases.

## Captcha "intercept" lives in `app.py`, not in a handler chain

`app.py:handle_message` checks `captcha.has_ongoing` before doing anything
else. There's no priority system in `pytelegrambotapi` we could lean on,
so the gate is hand-coded at the top of the message handler. If you add
another "must run before normal traffic" check, put it next to this one
and document why.
```


# INLINE-DOC DIFFS (fixture vs working)

## src/app.py

```diff
--- fixture/src/app.py
+++ working/src/app.py
@@ -15,6 +15,9 @@
 from src.modules.system.module import SystemModule
 from src.storage.database import db, init_db
 
+# Order matters: each module must come after any module it reads in `init()`.
+# See docs/architecture.md ("Startup and the two-phase init"). Captcha asks
+# chats whether a joining user is already known, so chats goes first.
 MODULE_CLASSES: list[type[Module]] = [
     ChatsModule,
     CaptchaModule,
@@ -24,6 +27,11 @@
 
 
 async def main() -> None:
+    # Startup is a fixed sequence: config -> db -> bot -> DI registration ->
+    # construct modules -> create tables -> Module.init() -> polling.
+    # The two-phase init (constructor "I exist"; init() "I can see peers") is
+    # the rule that lets modules resolve each other via DI. Full rationale in
+    # docs/architecture.md.
     config = load_config()
 
     init_db(config.db.path)
@@ -48,9 +56,12 @@
     chats_svc = di.get(ChatsModule).service
 
     async def handle_message(message: Message, bot: AsyncTeleBot) -> None:
+        # Group-chat message policy in one place. Steps are ordered: a user
+        # who hasn't passed captcha must not count toward "known in chat",
+        # so the captcha check runs before chats.touch(). pytelegrambotapi
+        # has no priority system, so this is the gate.
         if not is_group_chat(message):
             return
-        # Captcha intercept: if user has an active challenge, only process their answer
         if message.from_user and captcha.has_ongoing(message.chat.id, message.from_user.id):
             await captcha.verify_answer(bot, message)
             return
```

## src/core/di.py

```diff
--- fixture/src/core/di.py
+++ working/src/core/di.py
@@ -7,11 +7,15 @@
 
 T = TypeVar("T")
 
+# Process-global registry. Tests must reset this between cases.
 _registry: dict[type, Any] = {}
 
 
 class ModuleList:
-    """Typed wrapper for the list of all bot modules, registered in DI."""
+    """Iterable view of every Module loaded into DI.
+
+    Lets a module ask "who else is loaded" without importing peer classes.
+    /help and /debug both fan out through this."""
 
     def __init__(self, modules: list[Module]) -> None:
         self._modules = modules
```

## src/core/module.py

```diff
--- fixture/src/core/module.py
+++ working/src/core/module.py
@@ -2,26 +2,35 @@
 
 
 class Module(ABC):
-    """Base unit of business functionality.
+    """Base unit of feature work.
 
-    Each module is a self-contained unit that provides help/debug info
-    and wires its internals during init().
+    A module owns a folder under ``src/modules/<name>/`` with a service
+    (logic, no Telegram), a bot_connector (Telegram glue), and optional
+    models/strings/types. The split is the convention that keeps logic
+    testable. See docs/adding-a-module.md.
 
-    Subclass in ``src/modules/<name>/module.py``.
+    Two-phase init: ``__init__`` says "I exist"; ``init()`` says "I can
+    see everyone else". Only inside ``init()`` is it safe to look up
+    peer modules via ``di.get(...)``. See docs/architecture.md.
     """
 
+    # Lookup key. Also the prefix for /help callback data and the value
+    # ModuleList.get() expects.
     name: str
+    # Label shown to users (e.g. on /help buttons).
     str_name: str
+    # Owner-only modules: hidden from /help unless the caller is in
+    # config.owner_ids.
     is_system: bool = False
+    # Documentation for the reader; the framework does not enforce order.
+    # The real ordering knob is MODULE_CLASSES in app.py.
     depends_on: tuple[str, ...] = ()
+    # Peewee models to create tables for at startup.
     models: tuple[type, ...] = ()
 
     async def init(self) -> None:
-        """Called after ALL modules are registered in DI.
-
-        Override to resolve cross-module deps via ``di.get()``,
-        load caches, create internal service/connectors, and register handlers.
-        """
+        """Resolve peers and register handlers. Runs after every module
+        is constructed and present in DI."""
 
     @abstractmethod
     def help(self) -> str | None:
```

## src/modules/captcha/bot_connector.py

```diff
--- fixture/src/modules/captcha/bot_connector.py
+++ working/src/modules/captcha/bot_connector.py
@@ -43,6 +43,13 @@
             )
 
     async def handle_join(self, bot: AsyncTeleBot, message: Message, new_user: User) -> JoinOutcome:
+        # Skip rules, in order:
+        #   - bots aren't humans, nothing to verify;
+        #   - if an existing member added someone, trust the inviter;
+        #   - if we've seen this user participate here before, don't
+        #     re-challenge a familiar face (see chats.MESSAGES_TO_BE_KNOWN);
+        #   - if the join event is stale (we were down), don't challenge
+        #     a user who has likely already settled in or left.
         if new_user.is_bot:
             await bot.send_message(
                 message.chat.id,
@@ -92,15 +99,19 @@
             return JoinOutcome.ABORTED
 
         if ch.status == ch.status.ONGOING:
+            # Timeout reached without a passing answer. We "kick" — a
+            # ban immediately followed by an unban — so the user can
+            # rejoin later but isn't sitting in the chat. The sleep
+            # between the two calls is load-bearing; see comment below.
             try:
                 await bot.ban_chat_member(
                     chat_id=ch.chat_id,
                     user_id=ch.user_id,
                     revoke_messages=False,
                 )
-                # Stagger: without a brief gap the unban can race the ban on
-                # Telegram's side, leaving the user banned (only_if_banned then
-                # silently no-ops because the ban isn't committed yet).
+                # Without a brief gap the unban can race the ban on
+                # Telegram's side, leaving the user banned (only_if_banned
+                # then silently no-ops because the ban isn't committed yet).
                 await asyncio.sleep(1)
                 await bot.unban_chat_member(
                     chat_id=ch.chat_id,
```

## src/modules/captcha/service.py

```diff
--- fixture/src/modules/captcha/service.py
+++ working/src/modules/captcha/service.py
@@ -42,6 +42,8 @@
         return ch
 
     def check_answer(self, chat_id: int, user_id: int, text: str) -> bool:
+        # "~" is a wildcard answer that always passes — used by test
+        # fixtures and manual checks so a real math answer isn't required.
         ch = self.get(chat_id, user_id)
         if ch is None:
             return False
```

## src/modules/captcha/types.py

```diff
--- fixture/src/modules/captcha/types.py
+++ working/src/modules/captcha/types.py
@@ -1,6 +1,9 @@
 from dataclasses import dataclass
 from enum import Enum
 
+# Joins older than this (seconds) are skipped without a challenge. The
+# bot was probably down — the user has either settled in or already left,
+# and a late challenge is more annoying than useful.
 CAPTCHA_OUTDATED_TIMEOUT = 45
 
 
```

## src/modules/chats/service.py

```diff
--- fixture/src/modules/chats/service.py
+++ working/src/modules/chats/service.py
@@ -5,14 +5,26 @@
 
 from src.modules.chats.models import ChatMembership
 
+# A pair becomes "known" only after this many messages. Captcha uses
+# is_known() to decide whether to challenge on rejoin, so a stray drive-by
+# message shouldn't be enough to earn that pass — wait for a small streak.
 MESSAGES_TO_BE_KNOWN = 3
 
 
 class ChatsService:
-    """Per-real-chat presence tracking. Rows stay keyed by raw chat_id."""
+    """Tracks who actually participates in each chat.
+
+    A pair is "known" once it crosses MESSAGES_TO_BE_KNOWN; that signal
+    is what captcha uses to decide whether to re-challenge a rejoiner.
+    Below the threshold the pair lives only in the in-memory _watch
+    counter and is never persisted."""
 
     def __init__(self) -> None:
+        # Loaded from DB on init(). The cache is the source of truth at
+        # runtime; DB writes mirror it.
         self._cache: dict[tuple[int, int], ChatMembership] = {}
+        # Pre-known counter. Reset in-process; lost on restart by design —
+        # if you didn't get to 3 messages, you weren't really there.
         self._watch: dict[tuple[int, int], int] = {}
 
     def load_cache(self) -> None:
```

## src/modules/system/bot_connector.py

```diff
--- fixture/src/modules/system/bot_connector.py
+++ working/src/modules/system/bot_connector.py
@@ -23,9 +23,14 @@
         self._owner_ids = owner_ids
 
     def register(self, bot: AsyncTeleBot) -> None:
+        # All three commands silently no-op for non-owners (see each handler).
+        # Non-owners shouldn't even discover the commands exist.
         register_bot_command(bot, self._handle_ping, ["ping"], CommandAllowedIn.DM)
         register_bot_command(bot, self._handle_debug, ["debug"], CommandAllowedIn.DM)
         register_bot_command(bot, self._handle_sleep, ["sleep", "pause"], CommandAllowedIn.DM)
+        # Shared widget: the "delete" button on /help and /debug replies
+        # both emit callback_data="cleanup_message". This is the only place
+        # that handler is registered — don't add a second one elsewhere.
         register_bot_callback(
             bot,
             handler=self._handle_cleanup_message,
```

## src/modules/system/service.py

```diff
--- fixture/src/modules/system/service.py
+++ working/src/modules/system/service.py
@@ -79,7 +79,11 @@
         return True, ""
 
     async def sleep(self, seconds: int) -> None:
-        """Block the event loop to stop polling and yield to another instance."""
+        """Freeze polling so a second instance can take over.
+
+        Uses blocking time.sleep on purpose — the whole point is to stop
+        the event loop from servicing Telegram updates while another bot
+        process handles them. asyncio.sleep would not achieve that."""
         self._sleeping = True
         time.sleep(seconds)
         self._sleeping = False
```

## src/storage/database.py

```diff
--- fixture/src/storage/database.py
+++ working/src/storage/database.py
@@ -1,9 +1,14 @@
 from peewee import Model, SqliteDatabase
 
+# Lazy-bound handle. Peewee needs Model classes to reference the database
+# at import time, but the actual file path is only known after config is
+# loaded — so we declare with None and finish wiring in init_db().
 db = SqliteDatabase(None)
 
 
 class BaseModel(Model):
+    """Inherit instead of peewee.Model so the shared `db` handle is used."""
+
     class Meta:
         database = db
 
```

