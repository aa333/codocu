# Manual Scorecard — simple-bot-annotated / T1 / pass-1

> Operator-filled. Do not let the run agent or judge subagent populate
> these. Score both surfaces together (inline + aux). Inputs to consider:
> `working/`, `prompt.md`, `transcript.md`, `metrics.json`,
> `judge-score.md`.

## 1. Principle adherence
*Does each sentence say something code can't?*

Score (1–5): 2
Justification: Same issue as with T0, a lot of stuff is just created from code

## 2. Refactor resistance
*Would this survive a rename, extract, or inline?*

Score (1–5): 2
Justification: docs still mention a lot of code stuff, maybe a bit less than T0, still fragile

## 3. Bloat
*Judged against a minimum-viable mental version of the same doc set.*

Score (1–5): 3
Justification:
Generated tech debt entries from code just for the sake of the file being not empty. No input was given to do that.
README is much better, though

## 4. Code-restating count
*List specific sentences that restate code, with file references.*
Just one example, a lot more exists

- architecture.md "`src/core/di.py` is a `dict[type, instance]` with `register` and `get`"


## 5. Voice
*Busy-tired-reader, or reference material?*

Score (1–5): 4 
Justification: Well enough

## METADOCU agreement

Ground truth: `testing/fixtures/full/simple-bot-annotated-reference/`.

Of the N annotation-flagged issues there, how many does this run:

- **Reproduce** (introduces the same issue):
- **Avoid** (sidesteps the flagged issue):
- **Introduce new** (flagged-style issues not in the reference set):

Notes: Skipped


## Overall verdict
README is better