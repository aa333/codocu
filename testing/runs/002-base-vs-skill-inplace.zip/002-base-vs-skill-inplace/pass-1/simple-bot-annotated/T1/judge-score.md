# Codocu Scorecard — `simple-bot-annotated/T1`

## Scores

### 1. Principle adherence — **4/5**
Most sentences carry rationale, intent, or cross-module coupling that the code can't express (two-phase init *why*, captcha-before-touch *why*, ban-sleep-unban race, `~` wildcard purpose, `time.sleep` deliberateness). A few residual passages cross into transcription — notably the module-layout table in `architecture.md`, the per-file folder shape in `adding-a-module.md`, and the per-field attribute comments on `Module` — which restate structure the code already shows.

### 2. Refactor resistance — **3/5**
Several spots will rot under a rename or move: `MODULE_CLASSES`, `MESSAGES_TO_BE_KNOWN`, `CAPTCHA_OUTDATED_TIMEOUT`, `is_owner`, `cleanup_message`, `_watch`, `_run_challenge`, `only_if_banned`, `ChatsService.touch()`, `captcha.has_ongoing`, `SystemBotConnector`, `HelpService`, `HelpBotConnector`, `is_system`, `ModuleList.get`, even file paths like `src/modules/captcha/bot_connector.py` appear in tech-debt without breadcrumbs back from those symbols. Inline doc edits (which travel with the code) survive well; the aux `.md` files are the fragile surface.

### 3. Bloat — **2/5**
Material overlaps across three docs. `architecture.md` re-lists the module folder shape that `adding-a-module.md` also lists; `tech-debt.md` re-explains the `~` wildcard, the ban/unban sleep, `SystemService.sleep`, and the 45-second skip that `architecture.md` already summarized and the inline comments now also carry. The Module field comments duplicate the architecture doc's table. A leaner version would push everything in `tech-debt.md` into the existing inline comments (already present) and drop the duplicate module-shape section from `architecture.md`.

### 4. Voice — **4/5**
Mostly busy-tired-reader: short, declarative, "why this exists, what not to do." `architecture.md`'s "Startup and the two-phase init" numbered list and the table-form module layout drift toward reference manual. `adding-a-module.md` and the inline comments hit the tone well.

---

## Sentences that restate code

**`docs/architecture.md`**
- Lines 140-156 (the `src/` tree). A directory listing the reader can produce with `ls`.
- Lines 165-170 (the module-file table). Each row says what the file's name already says ("`service.py` — Pure business logic. … `models.py` — Peewee model classes …").
- Lines 180-186 (steps 1-6 of the numbered startup). Reads as a transcription of `main()` in `app.py`; a rename of `load_config`, `init_db`, `create_bot`, or `ModuleList` invalidates it. Step 7 (the *why* of two-phase init) is the part that earns its space.
- Line 207: "`src/core/di.py` is a `dict[type, instance]` with `register` and `get`." The file is ~15 lines and says exactly that.
- Lines 244-245: "`/ping`, `/debug`, `/sleep` and the cleanup callback all check `is_owner(message, owner_ids)` first and silently return on a miss." The handlers literally show this; the *why* in the next sentence is what's worth keeping.

**`docs/adding-a-module.md`**
- Lines 44-53 (the per-file folder shape). Same content as the architecture table, and discoverable by opening any existing module.
- Lines 64-71 (the `FooModule` class body). The comments next to each attribute (`# used in /help callbacks`, `# if you have Peewee models`) duplicate the field comments now added to `core/module.py`.

**`docs/tech-debt.md`**
- The whole file substantially duplicates the inline comments that the same diff adds to `system/service.py`, `captcha/bot_connector.py`, `captcha/service.py`, `captcha/types.py`, and `core/di.py`. Examples: "Switching to `asyncio.sleep` would defeat the command" (lines 292-293) restates the docstring on `SystemService.sleep`; the `ban_chat_member` / `unban_chat_member` paragraph (lines 297-302) restates the inline comment in `_run_challenge`; "Any challenge whose stored answer is `~` accepts any reply" (lines 307-308) restates the inline comment in `check_answer`.

**`src/core/module.py` (inline)**
- `# Lookup key. Also the prefix for /help callback data and the value ModuleList.get() expects.` — the "lookup key" half is what `name: str` already says; only the `/help`/`ModuleList.get` coupling earns its keep.
- `# Label shown to users (e.g. on /help buttons).` next to `str_name: str` — the field name plus an existing usage grep tells you this.
- `# Peewee models to create tables for at startup.` next to `models: tuple[type, ...] = ()` — the type and `app.py`'s `db.create_tables` already say this.

**`src/core/di.py` (inline)**
- `"""Iterable view of every Module loaded into DI."""` — the class name plus `self._modules: list[Module]` already say this; the second sentence ("Lets a module ask 'who else is loaded' …") is the load-bearing one.

**`src/storage/database.py` (inline)**
- `"""Inherit instead of peewee.Model so the shared `db` handle is used."""` — the `Meta.database = db` line directly above says exactly this.

---

## Overall verdict

A strong T1: the inline edits do most of the load-bearing work and the aux docs largely carry intent (two-phase init *why*, captcha-before-`touch` *why*, the ordering rules between `MODULE_CLASSES` and `init`, the shared `cleanup_message` widget contract). The principle violation is duplication rather than transcription — `tech-debt.md` re-explains every rough edge already captured inline, and `architecture.md` re-lists the module folder shape that `adding-a-module.md` also lists. Refactor resistance is the real weakness: a meaningful number of aux-doc sentences pin specific symbols and file paths with no breadcrumbs back, so a rename of `MESSAGES_TO_BE_KNOWN`, `is_owner`, `cleanup_message`, or any module file path will silently rot them. Voice is right; bloat is the cut to make. The minimum-viable version would keep `README.md`, keep `adding-a-module.md` (trimmed of the folder-shape transcription), keep the *rationale* sections of `architecture.md` (cut the tree, cut the file-role table, cut the numbered `main()` walkthrough), and delete `tech-debt.md` entirely now that the inline comments exist.
