# Modules

Per-module reference. Read [`architecture.md`](architecture.md) first.

The bot ships four modules, registered in `app.py` in this order:

```python
MODULE_CLASSES = [ChatsModule, CaptchaModule, HelpModule, SystemModule]
```

Order matters because `CaptchaModule.init()` does `di.get(ChatsModule)`.

---

## chats — "known user" presence tracking

`src/modules/chats/`

Tracks `(chat_id, user_id)` pairs in the `chat_memberships` table (peewee
model `ChatMembership`). A pair becomes "known" only after the user has
posted `MESSAGES_TO_BE_KNOWN = 3` messages in that chat. Until then their
counter sits in an in-memory `_watch` dict and nothing is persisted.

This threshold is what captcha uses to decide whether to challenge a joiner:
if `chats.is_known(chat_id, user_id)` is True, the joiner skips the
challenge (they re-joined a chat where they'd already proven they speak).

Key methods on `ChatsService`:

- `touch(message)` — called for every non-captcha group message. Increments
  the watch counter or updates `last_message_at`. On the third hit it
  inserts the row.
- `mark_left(chat_id, user_id)` — flips `in_chat=False`. Called from two
  places: the chats module's own `left_chat_member` handler, and via
  `CaptchaBotConnector._handle_left_member` which calls `service.abort` on
  the captcha side (different concern: aborting an ongoing challenge if the
  user leaves mid-test).
- `is_known(chat_id, user_id)` — pure cache lookup. Used by captcha.
- `get_all(chat_id)`, `get_user_chats(user_id)` — convenience reads, not
  currently called.

Cache is loaded from the DB once at `init()` via `load_cache()`. After that
all reads go through `_cache` and writes go to both `_cache` and the DB.

No commands. No `help()` text (returns `None`, so it's invisible in `/help`).

---

## captcha — gate new joiners with a math question

`src/modules/captcha/`

When a `new_chat_members` event fires for a real user, the captcha module
posts a Russian math question (from a hard-coded list in `strings.QUESTIONS`)
and waits up to `config.captcha.challenge_time` seconds (default 15) for the
joiner to reply.

### Filter chain in `handle_join`

In `CaptchaBotConnector.handle_join`, **in this order**:

1. **Bot joiner** — post `PASSED_BOT` and return `SKIPPED`.
2. **Second-party add** — if `from_user != new_user`, an existing member is
   adding someone else. Return `SKIPPED` (we trust the inviter).
3. **Already known** — if `ChatsService.is_known(chat_id, new_user_id)`,
   return `SKIPPED` (re-join).
4. **Stale event** — if `time.time() - message.date >
   CAPTCHA_OUTDATED_TIMEOUT` (45 s), the join event arrived too late
   (bot was offline or sleeping). Send `OUTDATED` only if the user really
   is still in the chat. Return `SKIPPED`.
5. Otherwise run `_run_challenge`.

### Challenge loop

`_run_challenge` posts the question, creates a `CaptchaChallenge` in
`CaptchaService._challenges` (in-memory list, **not persisted**), and
busy-loops one `await asyncio.sleep(1)` at a time, decrementing
`ch.time_left`. The loop exits when status changes (PASSED / ABORTED) or
time runs out (ONGOING with `time_left == 0`).

Three exit paths:

- **PASSED**: `verify_answer` saw the right answer, set status to PASSED,
  and posted the welcome. `_cleanup` deletes the challenge prompt.
- **ABORTED**: user left the chat mid-challenge (`_handle_left_member`
  flipped status), or a new challenge replaced this one for the same
  `(chat_id, user_id)` (see `CaptchaService.create`). `_cleanup` deletes the
  prompt; no ban.
- **FAILED**: timed out. Ban → `asyncio.sleep(1)` → unban → post the
  timeout message.

### Why ban-then-sleep-then-unban

In `_run_challenge` we do:

```python
await bot.ban_chat_member(...)
await asyncio.sleep(1)
await bot.unban_chat_member(..., only_if_banned=True)
```

The pause matters. Without it the unban can race the ban on Telegram's side
and silently no-op (because `only_if_banned` evaluates before the ban has
committed), leaving the user banned. The intent is "kick" — boot them so
they can re-join later if they want.

### Captcha intercept (in `app.py`)

`app.py`'s `handle_message` checks `captcha.has_ongoing(...)` **before**
calling `chats_svc.touch(...)`. While a user is mid-challenge, their text
messages bypass `ChatsService` entirely and go to
`CaptchaBotConnector.verify_answer`. This is what keeps captcha answers from
counting toward the "3 messages → known" threshold.

### State

`CaptchaService` holds challenges in a plain `list[CaptchaChallenge]`. Lost
on restart — there's no persistence and no recovery. If the bot restarts
mid-challenge, the user neither passes nor fails; the next time they post,
the captcha intercept won't trigger and `chats.touch` will start counting.

`CaptchaChallenge.answer` is stored lowercased (`answer.lower()`); a special
value `"~"` always passes — useful if you want a never-rejecting
"placeholder" question.

---

## help — `/help` menu

`src/modules/help/`

`/help` is DM-only (`CommandAllowedIn.DM` in
`HelpBotConnector.register`). It replies with an inline keyboard listing
every module that returns non-`None` from `help()`. Pressing a button edits
the message to show that module's help text.

Owner-only visibility: `is_system=True` modules (only `system` today) appear
in the keyboard only when the caller's ID is in `config.owner_ids`. The
filter is enforced in three places by `HelpService`: building the keyboard,
deciding access for a click, and rendering the help text. All three are
needed because a non-owner could craft a callback by hand.

Access control on clicks is by **command author**, not call author. The
keyboard's callbacks reply to the original `/help` message; if a different
user clicks them, they get a random `RESPONSES_NO` snippet
(`src/core/strings.random_no()`).

Buttons are laid out 3 per row. The currently-shown module's button is
re-emitted with `callback_data = "noop"` (handled by `_handle_noop`, which
just acks) so clicking the active page is harmless.

The "Удалить" button at the bottom emits `cleanup_message`, which is
handled by `system` (see [`architecture.md`](architecture.md) → "Cross-module
handler convention").

---

## system — `/ping`, `/debug`, `/sleep` for owners

`src/modules/system/`

`is_system = True` (hidden from non-owner `/help`). All three commands are
DM-only and short-circuit when `is_owner` is False — no reply, no error.

### `/ping`

Returns `PONG` with hostname and uptime (since `SystemService` construction,
which happens in `SystemModule.init()` — so this is uptime since process
start, in practice).

### `/debug`

Calls every module's `debug()` and concatenates the results separated by
`=========`. Also appends a memory line via `psutil`. The reply gets a
"Удалить" button (`cleanup_message`) so the owner can clean up their own
output.

`collect_debug_info` tolerates both sync and async `debug()` — it inspects
the return with `asyncio.iscoroutine` before awaiting. Today every module's
`debug()` is async, but the helper keeps the door open.

### `/sleep <seconds>`

**Deliberately blocks the event loop.** `SystemService.sleep` calls
`time.sleep`, not `asyncio.sleep`. The use case is running two instances
behind the same bot token — one is told to nap, telegram routes polls to
the other for the duration. Don't "fix" this to async.

Bounds: 10–1200 seconds. `parse_sleep_args` returns `(ok, error)` so the
connector can post a specific error message back; on missing args it
returns the usage hint.

### `get_recent_logs` is wired but unused

`SystemService.get_recent_logs` tails `config.log_file`. Nothing calls it
today — it's reachable from future debug surfaces or a `/logs` command if
you add one. Logging is also not actually configured anywhere; `log_level`
and `log_file` flow into the config but no handler is attached.

---

## Adding a new module

1. Create `src/modules/<name>/module.py` with a `Module` subclass. Pick a
   short lowercase `name`, a display `str_name`, and decide `is_system`.
2. Add a `service.py` for the logic. Keep telebot types out of its
   signatures so it stays unit-testable.
3. If it touches Telegram, add `bot_connector.py` and register handlers in
   `Module.init()` via `register_bot_command` / `register_bot_callback`.
4. If it has persistent state, declare peewee models in `models.py` and set
   `models = (YourModel,)` on the module class.
5. Append the class to `MODULE_CLASSES` in `src/app.py`. Put it **after**
   anything it `di.get()`s.
6. If you want it in `/help`, return a string from `help()`.

If you need to react to ordinary messages (not commands, not callbacks),
think hard before adding to `app.py`'s `handle_message`. The captcha
intercept is there because skipping `chats.touch` is part of its contract.
Most cases can be handled by registering your own filtered message handler
inside the module.
