# Architecture

## The shape of the app

`src/app.py` is a hundred lines, and the order it does things in is the whole
architecture. Read it first; everything below explains *why* each step is
where it is.

```
load_config()                             # AppConfig (frozen dataclass)
init_db(config.db.path)                   # bind the peewee Sqlite singleton
bot = create_bot(...)                     # AsyncTeleBot, optional proxy

di.register(AppConfig, config)            # values into the DI registry
di.register(AsyncTeleBot, bot)

modules = [Cls() for Cls in MODULE_CLASSES]   # __init__ only — no cross-deps yet
for m in modules: di.register(type(m), m)
di.register(ModuleList, ModuleList(modules))

db.create_tables(...)                     # tables for every model declared on a module

for m in modules: await m.init()          # NOW modules can resolve siblings via di.get()

# top-level message dispatch (see "Message dispatch" below)
bot.register_message_handler(handle_message, content_types=[...], pass_bot=True)
bot.register_message_handler(handle_new_member, content_types=["new_chat_members"], pass_bot=True)

await bot.infinity_polling(...)
```

Three things to internalise:

1. **Construct then wire.** All `Module.__init__` calls happen before any
   `init()` does. That's what lets modules resolve their siblings — by the
   time `init()` runs, every module is already in the DI registry.
2. **DI is a `dict[type, instance]`.** `src/core/di.py` is forty lines. No
   factories, no scopes — keys are types, values are singletons registered by
   `app.py`. `ModuleList` is a thin wrapper that lets you also look up modules
   by their `name`.
3. **No declarative dependency graph.** `Module.depends_on` is informational
   (only `CaptchaModule` sets it today, and nothing reads it at runtime).
   Order is whatever `MODULE_CLASSES` says it is. If module A needs module B,
   list B first.

## The Module contract

Every feature is a subclass of `src.core.module.Module`:

```python
class Module(ABC):
    name: str                              # short id ("captcha")
    str_name: str                          # display name ("Captcha")
    is_system: bool = False                # if True, hidden from /help for non-owners
    depends_on: tuple[str, ...] = ()       # informational
    models: tuple[type, ...] = ()          # peewee models — collected for create_tables

    async def init(self) -> None: ...      # called after every module is registered
    @abstractmethod
    def help(self) -> str | None: ...      # text for /help; None hides it
    @abstractmethod
    async def debug(self) -> str: ...      # one section of /debug output
```

Concrete patterns:

- **`__init__`** builds local state only (`self.service = FooService()`).
  Don't call `di.get()` here — the other modules may not be registered yet.
- **`init()`** resolves cross-module dependencies, builds the bot connector,
  registers handlers on the bot. It's `async` for symmetry but most modules
  use it synchronously.
- **`models`** is read once after construction so peewee can create tables.
  Only `ChatsModule` declares any today (`ChatMembership`).
- **`is_system = True`** marks the module owner-only — `HelpService` filters
  it out of `/help` for everyone else. Currently only `SystemModule` is
  flagged.

Inside a module the conventional split is:

| File              | Role                                                           |
| ----------------- | -------------------------------------------------------------- |
| `module.py`       | The `Module` subclass. Wires service + connector in `init()`.  |
| `service.py`      | Logic and state, no telebot types. Unit-testable in isolation. |
| `bot_connector.py`| Telebot handlers; translates telegram events to service calls. |
| `strings.py`      | User-visible text (Russian).                                   |
| `types.py` / `models.py` | dataclasses (captcha) or peewee models (chats).         |

Only `captcha`, `help`, and `system` have a `bot_connector.py`. `chats` is
internal — it registers one handler inline in `init()` and is otherwise
called by other modules.

## Message dispatch

The top-level message flow is in `app.py`, not in any module:

```python
async def handle_message(message, bot):
    if not is_group_chat(message):
        return
    # Captcha intercept: if user has an active challenge, only process their answer.
    if message.from_user and captcha.has_ongoing(message.chat.id, message.from_user.id):
        await captcha.verify_answer(bot, message)
        return
    if message.from_user is not None:
        chats_svc.touch(message)
```

This is the only place where module interaction is *ordered*: a user with an
ongoing captcha is not yet "in the chat", so their message must be routed to
the captcha verifier before `ChatsService.touch` would otherwise count it
toward the "known user" threshold.

`handle_new_member` always calls `captcha.handle_join`. The captcha module
decides itself (in `CaptchaBotConnector.handle_join`) whether to actually run
a challenge — it skips bots, second-hand `new_chat_members` notifications,
already-known users, and joins that are older than `CAPTCHA_OUTDATED_TIMEOUT`
(45 s).

Modules also register their own additional handlers directly on `AsyncTeleBot`
during `init()` — commands via `register_bot_command` from
`src/connectors/telegram/utils.py`, callbacks via `register_bot_callback`.
**Telebot dispatches the *first matching* handler**, so the `app.py` handlers
above (content-type filtered) and the module handlers (command/callback
filtered) don't fight each other.

## Cross-module handler convention

`HelpBotConnector` emits inline keyboard buttons with `callback_data =
"cleanup_message"`. The handler for that callback lives in
`SystemBotConnector`. This is intentional: any module can request "user can
delete this message" by attaching that callback_data; system owns the
implementation. If you see `cleanup_message` referenced elsewhere, that's the
contract.

## Storage

`src/storage/database.py` exposes a module-level `db = SqliteDatabase(None)`
that `init_db(path)` binds at startup (WAL, foreign keys on). `BaseModel`
points peewee at that singleton. Models declared on a module's `models`
tuple are passed to `db.create_tables(...)` in `app.py`. That's the entire
migration story — adding a column means editing the model and dropping the
table.

## Why this shape

The pieces fit together because each plays one role:

- **DI registry** keeps `app.py` from needing to know how modules are
  constructed — just register the types it provides (`AppConfig`,
  `AsyncTeleBot`, `ModuleList`, every `Module` subclass) and modules pull
  what they need.
- **`Module.init()` after all `__init__`s** is what makes circular references
  safe: by the time anyone runs `di.get(OtherModule)`, every module is
  registered.
- **Service / connector split** lets the service layer be tested without
  spinning up a `AsyncTeleBot`, and lets `module.py` stay short.

For per-module quirks and surprises see [`modules.md`](modules.md).
