# simple-bot

A Telegram group bot built around a small module system. New joiners answer a
captcha; verified users get tracked for presence; owners get `/ping`, `/debug`,
and `/sleep` to operate multiple instances. All user-visible strings are
Russian.

The interesting part of this codebase is the **module system** — not the
Telegram features themselves. Read `docs/architecture.md` once before changing
anything that crosses module boundaries.

## Run it

Requires Python 3.14 and [uv](https://docs.astral.sh/uv/).

```bash
cp config.example.json config.json    # then fill in tg_token + owner_ids
uv sync
uv run python -m src.app
```

The bot polls (no webhook). The SQLite DB lives at `config.db.path` and is
created on first run.

## Config

Defined by `AppConfig` in `src/core/config.py`. Fields:

| Field            | Required | Notes                                                  |
| ---------------- | -------- | ------------------------------------------------------ |
| `tg_token`       | yes      | Bot token from @BotFather.                             |
| `bot_username`   | no       | Currently unused at runtime; reserved for future use.  |
| `db.path`        | yes      | SQLite file path. WAL mode, foreign keys on.           |
| `captcha.challenge_time` | no | Seconds the new joiner has to answer (default 15). |
| `debug_chats`    | no       | Chats that get a `"simplebot started"` ping on boot.   |
| `owner_ids`      | no       | User IDs allowed to run `/ping`, `/debug`, `/sleep`.   |
| `proxy`          | no       | Forwarded to `telebot.asyncio_helper.proxy`.           |
| `log_level`      | no       | Wired into config but not currently used to configure logging. |
| `log_file`       | no       | Path that `SystemService` tails for `get_recent_logs`. |

`load_config()` reads `config.json` from cwd by default.

## Layout

```
src/
  app.py                    # entrypoint: load config, build modules, register handlers, poll
  core/
    config.py               # AppConfig + load_config
    di.py                   # tiny type-keyed DI registry + ModuleList wrapper
    module.py               # Module ABC every feature subclasses
    strings.py              # shared user-visible strings ("Удалить", random_no, ...)
  connectors/telegram/
    bot.py                  # create_bot(token, proxy)
    utils.py                # register_bot_command/callback helpers + is_owner
  storage/
    database.py             # peewee SqliteDatabase singleton + BaseModel + init_db
  modules/
    captcha/                # gate new joiners with a math question
    chats/                  # track which (chat, user) pairs are "known"
    help/                   # /help menu, paginated by module
    system/                 # /ping, /debug, /sleep — owner-only ops
```

Each module directory follows the same shape (see `docs/architecture.md`):

```
module.py          # subclass of Module; wires the rest in init()
service.py         # pure logic / state (no telebot types in signatures)
bot_connector.py   # turns telebot events into service calls (optional)
strings.py         # user-facing text
types.py / models.py  # dataclasses (captcha) or peewee models (chats)
```

## Further reading

- [`docs/architecture.md`](docs/architecture.md) — module system, DI, lifecycle, message dispatch.
- [`docs/modules.md`](docs/modules.md) — per-module behavior and the non-obvious bits.
