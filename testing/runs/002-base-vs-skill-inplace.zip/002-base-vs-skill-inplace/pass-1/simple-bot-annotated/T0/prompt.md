You are documenting an existing project. The fixture is in your current working directory, `testing/runs/002-base-vs-skill-inplace/pass-1/simple-bot-annotated/T0/working/`. Read the code, then write the documentation a new engineer joining the project would actually use.

You may write auxiliary docs (`.md` files under `docs/`) **and** edit code files in place (docstrings, comments). Pick whichever home fits each piece of doc best. Do not change non-doc code — no renames, no logic edits.

Use whatever structure and tone you judge best.
