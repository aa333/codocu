# Manual Scorecard — simple-bot-annotated / T0 / pass-1

> Operator-filled. Do not let the run agent or judge subagent populate
> these. Score both surfaces together (inline + aux). Inputs to consider:
> `working/`, `prompt.md`, `transcript.md`, `metrics.json`,
> `judge-score.md`.

## 1. Principle adherence
*Does each sentence say something code can't?*

Score (1–5): 2
Justification: There are some parts that are good business summaries, but mostly docs are just retelling code. +1 score for decent "Adding a new module" section.

## 2. Refactor resistance
*Would this survive a rename, extract, or inline?*

Score (1–5): 1
Justification: All docs will be stale even after simple refactor.

## 3. Bloat
*Judged against a minimum-viable mental version of the same doc set.*

Score (1–5): 1
Justification: Tied to retelling code; extremely bloated

## 4. Code-restating count
*List specific sentences that restate code, with file references.*

- "`src/app.py` is a hundred lines" is all we need to know about this doc's quality.


## 5. Voice
*Busy-tired-reader, or reference material?*

Score (1–5): 4
Justification: Well-readable. Poor debloating is what usually degrades this stat. 

## METADOCU agreement

Ground truth: `testing/fixtures/full/simple-bot-annotated-reference/`.

Of the N annotation-flagged issues there, how many does this run:

- **Reproduce** (introduces the same issue):
- **Avoid** (sidesteps the flagged issue):
- **Introduce new** (flagged-style issues not in the reference set):

Notes: I'll skip this 

## Overall verdict
There are some decent places - module's order inline comment was good, as was the "how to add a new module" section. 
However, docs are bloated and mostly code-oriented. Almost no new inline documentation. 
Note that inline doc about request stagger is a pre-existing piece explaining "Why it's like that". We dont count it.