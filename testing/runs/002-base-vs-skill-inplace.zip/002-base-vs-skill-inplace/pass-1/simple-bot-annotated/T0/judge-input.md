# NEW AUXILIARY DOCS

## README.md

```markdown
# simple-bot

A Telegram group bot built around a small module system. New joiners answer a
captcha; verified users get tracked for presence; owners get `/ping`, `/debug`,
and `/sleep` to operate multiple instances. All user-visible strings are
Russian.

The interesting part of this codebase is the **module system** — not the
Telegram features themselves. Read `docs/architecture.md` once before changing
anything that crosses module boundaries.

## Run it

Requires Python 3.14 and [uv](https://docs.astral.sh/uv/).

```bash
cp config.example.json config.json    # then fill in tg_token + owner_ids
uv sync
uv run python -m src.app
```

The bot polls (no webhook). The SQLite DB lives at `config.db.path` and is
created on first run.

## Config

Defined by `AppConfig` in `src/core/config.py`. Fields:

| Field            | Required | Notes                                                  |
| ---------------- | -------- | ------------------------------------------------------ |
| `tg_token`       | yes      | Bot token from @BotFather.                             |
| `bot_username`   | no       | Currently unused at runtime; reserved for future use.  |
| `db.path`        | yes      | SQLite file path. WAL mode, foreign keys on.           |
| `captcha.challenge_time` | no | Seconds the new joiner has to answer (default 15). |
| `debug_chats`    | no       | Chats that get a `"simplebot started"` ping on boot.   |
| `owner_ids`      | no       | User IDs allowed to run `/ping`, `/debug`, `/sleep`.   |
| `proxy`          | no       | Forwarded to `telebot.asyncio_helper.proxy`.           |
| `log_level`      | no       | Wired into config but not currently used to configure logging. |
| `log_file`       | no       | Path that `SystemService` tails for `get_recent_logs`. |

`load_config()` reads `config.json` from cwd by default.

## Layout

```
src/
  app.py                    # entrypoint: load config, build modules, register handlers, poll
  core/
    config.py               # AppConfig + load_config
    di.py                   # tiny type-keyed DI registry + ModuleList wrapper
    module.py               # Module ABC every feature subclasses
    strings.py              # shared user-visible strings ("Удалить", random_no, ...)
  connectors/telegram/
    bot.py                  # create_bot(token, proxy)
    utils.py                # register_bot_command/callback helpers + is_owner
  storage/
    database.py             # peewee SqliteDatabase singleton + BaseModel + init_db
  modules/
    captcha/                # gate new joiners with a math question
    chats/                  # track which (chat, user) pairs are "known"
    help/                   # /help menu, paginated by module
    system/                 # /ping, /debug, /sleep — owner-only ops
```

Each module directory follows the same shape (see `docs/architecture.md`):

```
module.py          # subclass of Module; wires the rest in init()
service.py         # pure logic / state (no telebot types in signatures)
bot_connector.py   # turns telebot events into service calls (optional)
strings.py         # user-facing text
types.py / models.py  # dataclasses (captcha) or peewee models (chats)
```

## Further reading

- [`docs/architecture.md`](docs/architecture.md) — module system, DI, lifecycle, message dispatch.
- [`docs/modules.md`](docs/modules.md) — per-module behavior and the non-obvious bits.
```

## docs/architecture.md

```markdown
# Architecture

## The shape of the app

`src/app.py` is a hundred lines, and the order it does things in is the whole
architecture. Read it first; everything below explains *why* each step is
where it is.

```
load_config()                             # AppConfig (frozen dataclass)
init_db(config.db.path)                   # bind the peewee Sqlite singleton
bot = create_bot(...)                     # AsyncTeleBot, optional proxy

di.register(AppConfig, config)            # values into the DI registry
di.register(AsyncTeleBot, bot)

modules = [Cls() for Cls in MODULE_CLASSES]   # __init__ only — no cross-deps yet
for m in modules: di.register(type(m), m)
di.register(ModuleList, ModuleList(modules))

db.create_tables(...)                     # tables for every model declared on a module

for m in modules: await m.init()          # NOW modules can resolve siblings via di.get()

# top-level message dispatch (see "Message dispatch" below)
bot.register_message_handler(handle_message, content_types=[...], pass_bot=True)
bot.register_message_handler(handle_new_member, content_types=["new_chat_members"], pass_bot=True)

await bot.infinity_polling(...)
```

Three things to internalise:

1. **Construct then wire.** All `Module.__init__` calls happen before any
   `init()` does. That's what lets modules resolve their siblings — by the
   time `init()` runs, every module is already in the DI registry.
2. **DI is a `dict[type, instance]`.** `src/core/di.py` is forty lines. No
   factories, no scopes — keys are types, values are singletons registered by
   `app.py`. `ModuleList` is a thin wrapper that lets you also look up modules
   by their `name`.
3. **No declarative dependency graph.** `Module.depends_on` is informational
   (only `CaptchaModule` sets it today, and nothing reads it at runtime).
   Order is whatever `MODULE_CLASSES` says it is. If module A needs module B,
   list B first.

## The Module contract

Every feature is a subclass of `src.core.module.Module`:

```python
class Module(ABC):
    name: str                              # short id ("captcha")
    str_name: str                          # display name ("Captcha")
    is_system: bool = False                # if True, hidden from /help for non-owners
    depends_on: tuple[str, ...] = ()       # informational
    models: tuple[type, ...] = ()          # peewee models — collected for create_tables

    async def init(self) -> None: ...      # called after every module is registered
    @abstractmethod
    def help(self) -> str | None: ...      # text for /help; None hides it
    @abstractmethod
    async def debug(self) -> str: ...      # one section of /debug output
```

Concrete patterns:

- **`__init__`** builds local state only (`self.service = FooService()`).
  Don't call `di.get()` here — the other modules may not be registered yet.
- **`init()`** resolves cross-module dependencies, builds the bot connector,
  registers handlers on the bot. It's `async` for symmetry but most modules
  use it synchronously.
- **`models`** is read once after construction so peewee can create tables.
  Only `ChatsModule` declares any today (`ChatMembership`).
- **`is_system = True`** marks the module owner-only — `HelpService` filters
  it out of `/help` for everyone else. Currently only `SystemModule` is
  flagged.

Inside a module the conventional split is:

| File              | Role                                                           |
| ----------------- | -------------------------------------------------------------- |
| `module.py`       | The `Module` subclass. Wires service + connector in `init()`.  |
| `service.py`      | Logic and state, no telebot types. Unit-testable in isolation. |
| `bot_connector.py`| Telebot handlers; translates telegram events to service calls. |
| `strings.py`      | User-visible text (Russian).                                   |
| `types.py` / `models.py` | dataclasses (captcha) or peewee models (chats).         |

Only `captcha`, `help`, and `system` have a `bot_connector.py`. `chats` is
internal — it registers one handler inline in `init()` and is otherwise
called by other modules.

## Message dispatch

The top-level message flow is in `app.py`, not in any module:

```python
async def handle_message(message, bot):
    if not is_group_chat(message):
        return
    # Captcha intercept: if user has an active challenge, only process their answer.
    if message.from_user and captcha.has_ongoing(message.chat.id, message.from_user.id):
        await captcha.verify_answer(bot, message)
        return
    if message.from_user is not None:
        chats_svc.touch(message)
```

This is the only place where module interaction is *ordered*: a user with an
ongoing captcha is not yet "in the chat", so their message must be routed to
the captcha verifier before `ChatsService.touch` would otherwise count it
toward the "known user" threshold.

`handle_new_member` always calls `captcha.handle_join`. The captcha module
decides itself (in `CaptchaBotConnector.handle_join`) whether to actually run
a challenge — it skips bots, second-hand `new_chat_members` notifications,
already-known users, and joins that are older than `CAPTCHA_OUTDATED_TIMEOUT`
(45 s).

Modules also register their own additional handlers directly on `AsyncTeleBot`
during `init()` — commands via `register_bot_command` from
`src/connectors/telegram/utils.py`, callbacks via `register_bot_callback`.
**Telebot dispatches the *first matching* handler**, so the `app.py` handlers
above (content-type filtered) and the module handlers (command/callback
filtered) don't fight each other.

## Cross-module handler convention

`HelpBotConnector` emits inline keyboard buttons with `callback_data =
"cleanup_message"`. The handler for that callback lives in
`SystemBotConnector`. This is intentional: any module can request "user can
delete this message" by attaching that callback_data; system owns the
implementation. If you see `cleanup_message` referenced elsewhere, that's the
contract.

## Storage

`src/storage/database.py` exposes a module-level `db = SqliteDatabase(None)`
that `init_db(path)` binds at startup (WAL, foreign keys on). `BaseModel`
points peewee at that singleton. Models declared on a module's `models`
tuple are passed to `db.create_tables(...)` in `app.py`. That's the entire
migration story — adding a column means editing the model and dropping the
table.

## Why this shape

The pieces fit together because each plays one role:

- **DI registry** keeps `app.py` from needing to know how modules are
  constructed — just register the types it provides (`AppConfig`,
  `AsyncTeleBot`, `ModuleList`, every `Module` subclass) and modules pull
  what they need.
- **`Module.init()` after all `__init__`s** is what makes circular references
  safe: by the time anyone runs `di.get(OtherModule)`, every module is
  registered.
- **Service / connector split** lets the service layer be tested without
  spinning up a `AsyncTeleBot`, and lets `module.py` stay short.

For per-module quirks and surprises see [`modules.md`](modules.md).
```

## docs/modules.md

```markdown
# Modules

Per-module reference. Read [`architecture.md`](architecture.md) first.

The bot ships four modules, registered in `app.py` in this order:

```python
MODULE_CLASSES = [ChatsModule, CaptchaModule, HelpModule, SystemModule]
```

Order matters because `CaptchaModule.init()` does `di.get(ChatsModule)`.

---

## chats — "known user" presence tracking

`src/modules/chats/`

Tracks `(chat_id, user_id)` pairs in the `chat_memberships` table (peewee
model `ChatMembership`). A pair becomes "known" only after the user has
posted `MESSAGES_TO_BE_KNOWN = 3` messages in that chat. Until then their
counter sits in an in-memory `_watch` dict and nothing is persisted.

This threshold is what captcha uses to decide whether to challenge a joiner:
if `chats.is_known(chat_id, user_id)` is True, the joiner skips the
challenge (they re-joined a chat where they'd already proven they speak).

Key methods on `ChatsService`:

- `touch(message)` — called for every non-captcha group message. Increments
  the watch counter or updates `last_message_at`. On the third hit it
  inserts the row.
- `mark_left(chat_id, user_id)` — flips `in_chat=False`. Called from two
  places: the chats module's own `left_chat_member` handler, and via
  `CaptchaBotConnector._handle_left_member` which calls `service.abort` on
  the captcha side (different concern: aborting an ongoing challenge if the
  user leaves mid-test).
- `is_known(chat_id, user_id)` — pure cache lookup. Used by captcha.
- `get_all(chat_id)`, `get_user_chats(user_id)` — convenience reads, not
  currently called.

Cache is loaded from the DB once at `init()` via `load_cache()`. After that
all reads go through `_cache` and writes go to both `_cache` and the DB.

No commands. No `help()` text (returns `None`, so it's invisible in `/help`).

---

## captcha — gate new joiners with a math question

`src/modules/captcha/`

When a `new_chat_members` event fires for a real user, the captcha module
posts a Russian math question (from a hard-coded list in `strings.QUESTIONS`)
and waits up to `config.captcha.challenge_time` seconds (default 15) for the
joiner to reply.

### Filter chain in `handle_join`

In `CaptchaBotConnector.handle_join`, **in this order**:

1. **Bot joiner** — post `PASSED_BOT` and return `SKIPPED`.
2. **Second-party add** — if `from_user != new_user`, an existing member is
   adding someone else. Return `SKIPPED` (we trust the inviter).
3. **Already known** — if `ChatsService.is_known(chat_id, new_user_id)`,
   return `SKIPPED` (re-join).
4. **Stale event** — if `time.time() - message.date >
   CAPTCHA_OUTDATED_TIMEOUT` (45 s), the join event arrived too late
   (bot was offline or sleeping). Send `OUTDATED` only if the user really
   is still in the chat. Return `SKIPPED`.
5. Otherwise run `_run_challenge`.

### Challenge loop

`_run_challenge` posts the question, creates a `CaptchaChallenge` in
`CaptchaService._challenges` (in-memory list, **not persisted**), and
busy-loops one `await asyncio.sleep(1)` at a time, decrementing
`ch.time_left`. The loop exits when status changes (PASSED / ABORTED) or
time runs out (ONGOING with `time_left == 0`).

Three exit paths:

- **PASSED**: `verify_answer` saw the right answer, set status to PASSED,
  and posted the welcome. `_cleanup` deletes the challenge prompt.
- **ABORTED**: user left the chat mid-challenge (`_handle_left_member`
  flipped status), or a new challenge replaced this one for the same
  `(chat_id, user_id)` (see `CaptchaService.create`). `_cleanup` deletes the
  prompt; no ban.
- **FAILED**: timed out. Ban → `asyncio.sleep(1)` → unban → post the
  timeout message.

### Why ban-then-sleep-then-unban

In `_run_challenge` we do:

```python
await bot.ban_chat_member(...)
await asyncio.sleep(1)
await bot.unban_chat_member(..., only_if_banned=True)
```

The pause matters. Without it the unban can race the ban on Telegram's side
and silently no-op (because `only_if_banned` evaluates before the ban has
committed), leaving the user banned. The intent is "kick" — boot them so
they can re-join later if they want.

### Captcha intercept (in `app.py`)

`app.py`'s `handle_message` checks `captcha.has_ongoing(...)` **before**
calling `chats_svc.touch(...)`. While a user is mid-challenge, their text
messages bypass `ChatsService` entirely and go to
`CaptchaBotConnector.verify_answer`. This is what keeps captcha answers from
counting toward the "3 messages → known" threshold.

### State

`CaptchaService` holds challenges in a plain `list[CaptchaChallenge]`. Lost
on restart — there's no persistence and no recovery. If the bot restarts
mid-challenge, the user neither passes nor fails; the next time they post,
the captcha intercept won't trigger and `chats.touch` will start counting.

`CaptchaChallenge.answer` is stored lowercased (`answer.lower()`); a special
value `"~"` always passes — useful if you want a never-rejecting
"placeholder" question.

---

## help — `/help` menu

`src/modules/help/`

`/help` is DM-only (`CommandAllowedIn.DM` in
`HelpBotConnector.register`). It replies with an inline keyboard listing
every module that returns non-`None` from `help()`. Pressing a button edits
the message to show that module's help text.

Owner-only visibility: `is_system=True` modules (only `system` today) appear
in the keyboard only when the caller's ID is in `config.owner_ids`. The
filter is enforced in three places by `HelpService`: building the keyboard,
deciding access for a click, and rendering the help text. All three are
needed because a non-owner could craft a callback by hand.

Access control on clicks is by **command author**, not call author. The
keyboard's callbacks reply to the original `/help` message; if a different
user clicks them, they get a random `RESPONSES_NO` snippet
(`src/core/strings.random_no()`).

Buttons are laid out 3 per row. The currently-shown module's button is
re-emitted with `callback_data = "noop"` (handled by `_handle_noop`, which
just acks) so clicking the active page is harmless.

The "Удалить" button at the bottom emits `cleanup_message`, which is
handled by `system` (see [`architecture.md`](architecture.md) → "Cross-module
handler convention").

---

## system — `/ping`, `/debug`, `/sleep` for owners

`src/modules/system/`

`is_system = True` (hidden from non-owner `/help`). All three commands are
DM-only and short-circuit when `is_owner` is False — no reply, no error.

### `/ping`

Returns `PONG` with hostname and uptime (since `SystemService` construction,
which happens in `SystemModule.init()` — so this is uptime since process
start, in practice).

### `/debug`

Calls every module's `debug()` and concatenates the results separated by
`=========`. Also appends a memory line via `psutil`. The reply gets a
"Удалить" button (`cleanup_message`) so the owner can clean up their own
output.

`collect_debug_info` tolerates both sync and async `debug()` — it inspects
the return with `asyncio.iscoroutine` before awaiting. Today every module's
`debug()` is async, but the helper keeps the door open.

### `/sleep <seconds>`

**Deliberately blocks the event loop.** `SystemService.sleep` calls
`time.sleep`, not `asyncio.sleep`. The use case is running two instances
behind the same bot token — one is told to nap, telegram routes polls to
the other for the duration. Don't "fix" this to async.

Bounds: 10–1200 seconds. `parse_sleep_args` returns `(ok, error)` so the
connector can post a specific error message back; on missing args it
returns the usage hint.

### `get_recent_logs` is wired but unused

`SystemService.get_recent_logs` tails `config.log_file`. Nothing calls it
today — it's reachable from future debug surfaces or a `/logs` command if
you add one. Logging is also not actually configured anywhere; `log_level`
and `log_file` flow into the config but no handler is attached.

---

## Adding a new module

1. Create `src/modules/<name>/module.py` with a `Module` subclass. Pick a
   short lowercase `name`, a display `str_name`, and decide `is_system`.
2. Add a `service.py` for the logic. Keep telebot types out of its
   signatures so it stays unit-testable.
3. If it touches Telegram, add `bot_connector.py` and register handlers in
   `Module.init()` via `register_bot_command` / `register_bot_callback`.
4. If it has persistent state, declare peewee models in `models.py` and set
   `models = (YourModel,)` on the module class.
5. Append the class to `MODULE_CLASSES` in `src/app.py`. Put it **after**
   anything it `di.get()`s.
6. If you want it in `/help`, return a string from `help()`.

If you need to react to ordinary messages (not commands, not callbacks),
think hard before adding to `app.py`'s `handle_message`. The captcha
intercept is there because skipping `chats.touch` is part of its contract.
Most cases can be handled by registering your own filtered message handler
inside the module.
```


# INLINE-DOC DIFFS (fixture vs working)

## src/app.py

```diff
--- fixture/src/app.py
+++ working/src/app.py
@@ -15,6 +15,9 @@
 from src.modules.system.module import SystemModule
 from src.storage.database import db, init_db
 
+# Order matters: each module's init() may di.get() its siblings, so list a
+# module AFTER anything it depends on. CaptchaModule resolves ChatsModule,
+# so chats must precede it. See docs/architecture.md ("The shape of the app").
 MODULE_CLASSES: list[type[Module]] = [
     ChatsModule,
     CaptchaModule,
```

## src/modules/captcha/service.py

```diff
--- fixture/src/modules/captcha/service.py
+++ working/src/modules/captcha/service.py
@@ -2,6 +2,13 @@
 
 
 class CaptchaService:
+    """In-memory store of active captcha challenges.
+
+    Not persisted: a restart loses every ongoing challenge. The user will
+    neither pass nor fail; the next message they post will fall through to
+    ChatsService.touch like any new joiner.
+    """
+
     def __init__(self) -> None:
         self._challenges: list[CaptchaChallenge] = []
 
@@ -27,6 +34,9 @@
         answer: str,
         challenge_time: int,
     ) -> CaptchaChallenge:
+        # If the same (chat, user) already has a challenge, mark it ABORTED so
+        # the awaiting _run_challenge loop in the bot connector wakes up,
+        # cleans up, and returns ABORTED instead of FAILED.
         existing = self.get(chat_id, user_id)
         if existing is not None:
             existing.status = ChallengeStatus.ABORTED
@@ -42,6 +52,8 @@
         return ch
 
     def check_answer(self, chat_id: int, user_id: int, text: str) -> bool:
+        # "~" is the always-passes sentinel: a question whose `answer` is "~"
+        # accepts any text. Useful for placeholder/test questions.
         ch = self.get(chat_id, user_id)
         if ch is None:
             return False
```

## src/modules/chats/service.py

```diff
--- fixture/src/modules/chats/service.py
+++ working/src/modules/chats/service.py
@@ -5,11 +5,22 @@
 
 from src.modules.chats.models import ChatMembership
 
+# A (chat_id, user_id) becomes "known" only after the user has posted this
+# many messages in that chat. Until then they sit in self._watch and nothing
+# is persisted. The threshold is what CaptchaBotConnector.handle_join uses
+# to decide whether to skip the challenge on re-join.
 MESSAGES_TO_BE_KNOWN = 3
 
 
 class ChatsService:
-    """Per-real-chat presence tracking. Rows stay keyed by raw chat_id."""
+    """Per-real-chat presence tracking. Rows stay keyed by raw chat_id.
+
+    State:
+      _cache  -- (chat_id, user_id) -> ChatMembership for persisted rows.
+                 Loaded once in load_cache() and kept in sync on writes.
+      _watch  -- (chat_id, user_id) -> int  pre-persistence counter; promotes
+                 to _cache + DB row when it reaches MESSAGES_TO_BE_KNOWN.
+    """
 
     def __init__(self) -> None:
         self._cache: dict[tuple[int, int], ChatMembership] = {}
```

## src/modules/help/bot_connector.py

```diff
--- fixture/src/modules/help/bot_connector.py
+++ working/src/modules/help/bot_connector.py
@@ -17,7 +17,10 @@
 from src.modules.help import strings
 from src.modules.help.service import HelpService
 
-# `cleanup_message` callback is registered by SystemBotConnector — help only emits the data.
+# `cleanup_message` callback is registered by SystemBotConnector — help only
+# emits the callback_data. This is the cross-module "user can delete this
+# reply" contract; see docs/architecture.md ("Cross-module handler
+# convention").
 
 
 class HelpBotConnector:
```

## src/modules/system/service.py

```diff
--- fixture/src/modules/system/service.py
+++ working/src/modules/system/service.py
@@ -79,7 +79,13 @@
         return True, ""
 
     async def sleep(self, seconds: int) -> None:
-        """Block the event loop to stop polling and yield to another instance."""
+        """Block the event loop to stop polling and yield to another instance.
+
+        Intentionally uses time.sleep (blocking), not asyncio.sleep. The use
+        case is running two instances behind one bot token: telling this one
+        to nap routes telegram polls to the other for the duration. Don't
+        "fix" this to be async.
+        """
         self._sleeping = True
         time.sleep(seconds)
         self._sleeping = False
```

