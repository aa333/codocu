# Manual Scorecard — simple-bot-annotated / T0 / pass-1

> Operator-filled. Do not let the run agent or judge subagent populate
> these. Score both surfaces together (inline + aux). Inputs to consider:
> `working/`, `prompt.md`, `transcript.md`, `metrics.json`,
> `judge-score.md`.

## 1. Principle adherence
*Does each sentence say something code can't?*

Score (1–5): 3
Justification: Still a lot of docs generated from just restating code. A little better due to retelling it in business terms, but still excessive. 

## 2. Refactor resistance
*Would this survive a rename, extract, or inline?*

Score (1–5): 3
Justification: Not good, still some unnecessary code references, but at least backlinks are present

## 3. Bloat
*Judged against a minimum-viable mental version of the same doc set.*

Score (1–5): 2
Justification: Related to code retelling

## 4. Code-restating count
*List specific sentences that restate code, with file references.*

- bot-architecture: MODULE_CLASSES, depends_on, chats.touch(), AppConfig
- chats-presence: `left_chat_member` flips `in_chat` to false but keeps the row, so a returning user is still "known" and bypasses the captcha.
- a lot more

## 5. Voice
*Busy-tired-reader, or reference material?*

Score (1–5): 3 
Justification: A little dense in places. e.g. "The threshold is a soft heuristic against passive accounts gaming the bypass. " 

## METADOCU agreement

Ground truth: `testing/fixtures/full/simple-bot-annotated-reference/`.

Of the N annotation-flagged issues there, how many does this run:

- **Reproduce** (introduces the same issue):
- **Avoid** (sidesteps the flagged issue):
- **Introduce new** (flagged-style issues not in the reference set):

Notes: Skipped

## Final Verdict

tech-debt generation is a sign of an overarching problem - codocu cannot ingest the principle well-enough. "Make documentation" process is deeply related with "tell what code does", and it doesnt seem we can break this link easily; 
