# Scorecard — `simple-bot-annotated/T2`

## 1. Principle adherence — **5**
Nearly every sentence carries rationale, intent, non-goals, or invariants that code can't express: why the captcha intercept lives in `app.py`, why the one-second ban/unban gap exists, why `/sleep` blocks, what `MESSAGES_TO_BE_KNOWN` is defending against, what the module *doesn't* track.

## 2. Refactor resistance — **4**
Most prose describes meaning ("known returners", "the kick", "becoming known"), so renames won't break it. A handful of named symbols (`CAPTCHA_OUTDATED_TIMEOUT`, `MESSAGES_TO_BE_KNOWN`, `MIN_SLEEP`/`MAX_SLEEP`, `cleanup_message`, `handle_join`, `verify_answer`, `MODULE_CLASSES`) are load-bearing in the prose; the breadcrumbs make this defensible, but renames would still leave stale name-drops.

## 3. Bloat — **4**
The four system docs each earn their space and stay close to a minimum-viable mental model. Mild fat: `bot-architecture.md`'s "Modules" list enumerates every per-file role in the directory convention (close to reference territory), and `codocu.md`'s "Additional notes" duplicates the breadcrumb mechanism that the spec already covers. Nothing egregious.

## 4. Voice — **4**
Reads like a tired-reader briefing: "The block *is* the feature.", "Don't 'fix' it to be async.", "keep the stagger." A few stretches drift toward reference cadence (the module-file checklist in `bot-architecture.md`, the four-outcome enum in `captcha-gate.md`) but recover quickly.

## Sentences that restate code

- `docs/systems/bot-architecture.md` — the per-file breakdown under "Modules" (`module.py — the Module subclass`, `service.py — pure logic, no Telegram imports`, `bot_connector.py — the only file that talks to telebot`, `strings.py — Russian-language user-facing strings`, `models.py (optional) — peewee model classes…`) is structural transcription of what each filename already says; it could be a directory listing.
- `docs/systems/bot-architecture.md` — "`src/app.py` runs in three phases: 1. **Instantiate.** … 2. **Register.** … 3. **Init.** `await m.init()` on each module in declaration order." narrates the literal three-block shape of `app.py`; the *why* sentences around it are good, but the phase enumeration is the code's outline.
- `docs/systems/captcha-gate.md` — the four-outcome list ("PASSED — the user answered correctly within the time limit", "FAILED — the time limit ran out; the user is kicked", "ABORTED — the challenge started but the user left mid-challenge") restates an enum that almost certainly exists in `handle_join`'s return type.
- `docs/systems/captcha-gate.md` — "If the challenged user leaves the chat mid-challenge, the `left_chat_member` event aborts the challenge…" is a behavior assertion testable against the handler; could be a docstring on the abort path.
- `docs/systems/chats-presence.md` — "`left_chat_member` flips `in_chat` to false but keeps the row" describes the literal effect of one function; belongs as a docstring on that handler.
- `docs/systems/owner-commands.md` — "Both `/debug` and `/help` end with a 'Удалить' button that removes the reply and the original command message." is what the callback's code does; the *only-issuer-can-trigger* sentence after it is the doc-worthy part.
- `codocu.md` — "**docs/systems/** — the long-term docs home. One file per system, edited in place, never date-stamped." and the matching `docs/plans/` / `docs/archive/` lines are convention statements (fine here), but the breadcrumb paragraph under "Additional notes" duplicates a rule the doc-standard spec already owns.

## Overall verdict

Strong run. The aux docs consistently land on the negative space — race conditions, deliberate footguns, non-goals, threshold rationale, cross-module callback ownership — and the inline breadcrumbs are placed exactly where the spec asks for them, including the nice one-liner on `help/bot_connector.py` that names the cross-module owner. The recurring weakness is structural enumeration: the per-module file roles, the three-phase `app.py` walk-through, and the four-outcome list each transcribe shape the reader could get from a `tree` or an enum definition, and they'll be the first things to drift if the code reorganizes. Trimming those three blocks would lift this from "good" to "tight"; as it stands it is a faithful, opinionated, refactor-resilient doc set well within Codocu's spirit.
