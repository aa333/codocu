# NEW AUXILIARY DOCS

## CLAUDE.md

```markdown
@codocu.md
```

## codocu.md

```markdown
# Codocu
<!-- Created by /codocu:init. Defines this project's documentation conventions, loaded through CLAUDE.md. 
Edit freely. -->

## Docs structure

- **docs/systems/** — the long-term docs home. One file per system, edited
  in place, never date-stamped. This is where durable knowledge lives.
- **docs/plans/** — fleeting working plans. Deleted or folded into a
  system doc on completion.
- **docs/archive/** — folded plans, kept for history. Fold target; never
  hand-edited.


## Tech Debt
- **docs/tech-debt.md** — Compact list of known issues, deferred work, and explicitly suboptimal choices. Add freely; remove on fix.
Format: `**<TD-short-id>**: <what is wrong> - <optional: reason for not fixing || solution draft>`


## Agent guidelines

Agents/skills that come with their dedicated opinionated plan/doc/spec structures must keep documents related to planning and immediate implementation in docs/plans. Plans must contain actual completion status per each step. 

## Fold settings

Ask per each incomplete plan: archive as is, extract incomplete parts, leave

## Additional notes

**Breadcrumb form.** Each code file load-bearing for a system doc carries a top-of-file comment `# System doc: docs/systems/<file>.md`. Grep for `System doc:` to list every breadcrumb in the repo.

<!-- You can set project-specific rules — API conventions, security postures, deprecation
policies, anything else that doesn't fit above. -->
```

## docs/systems/bot-architecture.md

```markdown
# Bot architecture

simple-bot is a Telegram group-chat bot. It gates new joiners with a captcha, tracks who is actually in each chat over time, and exposes a few diagnostic commands to the owner over DM. All user-facing messages are in Russian; new modules should follow.

## Modules

Every piece of behavior is a module under `src/modules/<name>/`. The four shipped modules are `chats`, `captcha`, `help`, and `system`. A new module is one directory with:

- `module.py` — the `Module` subclass. This is the DI handle other modules ask for.
- `service.py` — pure logic, no Telegram imports. Testable in isolation.
- `bot_connector.py` — the only file that talks to telebot. Registers handlers and turns Telegram events into service calls.
- `strings.py` — Russian-language user-facing strings.
- `models.py` (optional) — peewee model classes, listed on the module class's `models` tuple so the app picks them up at table creation.

The Module / Service / BotConnector split is load-bearing. Services stay testable because they don't import telebot. The connector is swappable if the bot ever speaks a second protocol. The module class carries the metadata (`name`, `str_name`, `is_system`, `help()`, `debug()`) that the help and debug commands consume generically.

## Assembly

`src/app.py` runs in three phases:

1. **Instantiate.** Construct every class in `MODULE_CLASSES`. Construction is cheap and dependency-free; modules must not reach into DI in `__init__`.
2. **Register.** Put the config, the bot, each module, and the `ModuleList` wrapper into the DI registry. DI is a flat global type→instance dict (`src/core/di.py`) — no scopes, no DAG, no lifecycle management.
3. **Init.** `await m.init()` on each module in declaration order. This is where modules pull cross-module dependencies via `di.get(...)` and register their handlers.

`MODULE_CLASSES` order is the dependency order. `chats` precedes `captcha` because the captcha service asks chats whether a joiner is a returner. `depends_on` on the module class records the intent but is not enforced; the list ordering is what actually drives init.

After init, `app.py` installs the top-level group-chat message handler. It runs the captcha intercept first (see [captcha-gate.md](captcha-gate.md)), then calls `chats.touch()` so presence tracking sees the message.

## Why the captcha intercept lives in app.py

The intercept could live inside the captcha module's own message handler. It lives in `app.py` because the captcha must win the race against every other module's message handler — the challenged user's reply is otherwise just an ordinary message. Putting the check at the dispatch point makes that win impossible to miss when a new module is added.

## Configuration

Config is JSON at `config.json`, loaded into the frozen `AppConfig` dataclass on startup (`src/core/config.py`). `config.example.json` is the template. The configurable surface is small on purpose: bot token, optional proxy, SQLite path, owner ids, debug-chat ids, log level, and the captcha challenge time.

## Storage

One peewee SQLite database (`src/storage/database.py`), opened in WAL mode with foreign keys on. Modules declare their model classes on the `models` class attribute; `app.py` collects them and creates tables at startup. The DB handle is lazily initialized (`SqliteDatabase(None)` then `init_db(path)`) so config can drive the path.
```

## docs/systems/captcha-gate.md

```markdown
# Captcha gate

When someone new joins a group chat, the bot asks them a simple Russian-language question. If they answer in time, they're welcomed; if the timer runs out, the bot kicks them. The point is to drop trivial spam joins without locking the chat down.

## How a join lands

The new-member event reaches `CaptchaModule.handle_join`, which returns one of four outcomes:

- **PASSED** — the user answered correctly within the time limit.
- **FAILED** — the time limit ran out; the user is kicked.
- **SKIPPED** — no challenge ran. Reasons: the joiner is a bot (a short greeting is sent anyway), the joiner is a known returner (see [chats-presence.md](chats-presence.md)), or the message was added by someone other than the joiner themselves (e.g. an admin adding a user).
- **ABORTED** — the challenge started but the user left mid-challenge.

## Outdated joins

Telegram redelivers backlog `new_chat_members` events when the bot reconnects after downtime. An event older than 45 seconds (`CAPTCHA_OUTDATED_TIMEOUT`) is treated as backlog. If the user is still in the chat, the bot tells them the check expired; otherwise it stays silent. Either way, no challenge runs.

## During the challenge

While the timer ticks (default 15s, configurable as `captcha.challenge_time`), the top-level message handler in `app.py` intercepts every message from a user with an open challenge and routes it straight to `verify_answer`. See [bot-architecture.md](bot-architecture.md) for why this intercept lives at the dispatch point rather than in the captcha module's own handler.

If the challenged user leaves the chat mid-challenge, the `left_chat_member` event aborts the challenge so the polling loop exits cleanly without trying to kick someone who's already gone.

## The kick

Telegram's bot API has no "remove without ban" primitive for supergroups. The captcha kicks by banning, sleeping one second, then unbanning. **The one-second gap is real.** Without it the unban can race the ban server-side and silently no-op (the unban arrives before the ban is committed), leaving the user permanently banned. If you ever change this code, keep the stagger.

## Strings and questions

User-facing copy and the question pool live in `src/modules/captcha/strings.py`. Questions are simple arithmetic and trivia with one literal answer each. The answer string `~` is a wildcard — used by tests, not exposed to config. Treat it as intentional: don't strip the wildcard branch.
```

## docs/systems/chats-presence.md

```markdown
# Chats presence

The chats module tracks who is actually present in each chat. Its only current consumer is the captcha gate, which asks "have we seen this user here before?" so it can skip re-challenging known returners.

## Becoming known

A user becomes "known" in a chat after sending `MESSAGES_TO_BE_KNOWN` messages (currently 3). Joining alone doesn't make a user known — a botted joiner who never speaks won't graduate, so the captcha will challenge them again if they leave and rejoin.

The threshold is a soft heuristic against passive accounts gaming the bypass. Raise it if drive-by joins start abusing the skip; lower it if real users complain about being re-challenged.

## Storage and the cache

Membership rows persist in the `chat_memberships` table (composite key chat_id + user_id). The full table is loaded into memory at startup and the in-memory cache is the source of truth for queries during the session; writes go through to peewee.

The cache assumes one bot instance writes at a time. Running two instances against the same DB will silently diverge the caches — tracked as TD-chats-multi-instance in [docs/tech-debt.md](../tech-debt.md).

## Leaving

`left_chat_member` flips `in_chat` to false but keeps the row, so a returning user is still "known" and bypasses the captcha. Rows are never deleted; the bot has no reason to forget.

## What this module doesn't do

It doesn't track admin status, kick history, or message content. It doesn't deduplicate across chats — a user is known in chat A and unknown in chat B until they speak in B.
```

## docs/systems/owner-commands.md

```markdown
# Owner commands

The bot exposes a small set of DM-only commands for the owner: `/help`, `/ping`, `/debug`, `/sleep`. The `help` and `system` modules implement them but share one access model and one cross-module callback worth knowing about.

## Owner gating

`owner_ids` in config is the allow-list of Telegram user ids with elevated access. Each handler checks `is_owner` itself (in `src/connectors/telegram/utils.py`); there is no central middleware. If a new handler should be owner-only, the convention is the same in-line check.

## System modules

A module marked `is_system = True` (currently only `system`) is hidden from `/help` for non-owners. The help service filters the menu; if the module's `help()` returns text, owners see it. Use this for any module whose existence shouldn't be advertised to ordinary users.

## `/sleep` blocks on purpose

`/sleep <seconds>` calls blocking `time.sleep`, not `asyncio.sleep`. It deliberately freezes the event loop so a second deployed instance can take over Telegram polling without conflict — useful for blue/green-style restarts when both processes briefly share the same token.

Don't "fix" it to be async. The block *is* the feature.

The accepted range (10s–1200s, `MIN_SLEEP`/`MAX_SLEEP`) is a safety rail. Going lower defeats the purpose of yielding; going higher is more rope than the owner usually wants.

## Shared "delete this message" callback

Both `/debug` and `/help` end with a "Удалить" button that removes the reply and the original command message. The callback handler (`cleanup_message`) is registered by the system module's bot connector; the help module's connector just emits the same callback data on its own buttons.

Only the user who issued the originating command can trigger the cleanup; other users get a soft refusal. If a third module wants the same affordance, emit the same callback data — don't register another handler.
```

## docs/tech-debt.md

```markdown
# Tech debt

**TD-chats-multi-instance**: ChatsService caches the full `chat_memberships` table in memory at startup and treats the cache as the source of truth for the session — running two bot instances against the same DB will silently diverge their caches. If a multi-instance setup is adopted, the cache must be invalidated on writes by another instance, or removed. See [docs/systems/chats-presence.md](systems/chats-presence.md).
```


# INLINE-DOC DIFFS (fixture vs working)

## src/app.py

```diff
--- fixture/src/app.py
+++ working/src/app.py
@@ -1,3 +1,4 @@
+# System doc: docs/systems/bot-architecture.md
 import asyncio
 
 from telebot.async_telebot import AsyncTeleBot
```

## src/core/di.py

```diff
--- fixture/src/core/di.py
+++ working/src/core/di.py
@@ -1,3 +1,4 @@
+# System doc: docs/systems/bot-architecture.md
 from __future__ import annotations
 
 from typing import TYPE_CHECKING, Any, TypeVar
```

## src/core/module.py

```diff
--- fixture/src/core/module.py
+++ working/src/core/module.py
@@ -1,3 +1,4 @@
+# System doc: docs/systems/bot-architecture.md
 from abc import ABC, abstractmethod
 
 
```

## src/modules/captcha/bot_connector.py

```diff
--- fixture/src/modules/captcha/bot_connector.py
+++ working/src/modules/captcha/bot_connector.py
@@ -1,3 +1,4 @@
+# System doc: docs/systems/captcha-gate.md
 import asyncio
 import random
 import time
```

## src/modules/captcha/module.py

```diff
--- fixture/src/modules/captcha/module.py
+++ working/src/modules/captcha/module.py
@@ -1,3 +1,4 @@
+# System doc: docs/systems/captcha-gate.md
 from __future__ import annotations
 
 from typing import TYPE_CHECKING
```

## src/modules/chats/module.py

```diff
--- fixture/src/modules/chats/module.py
+++ working/src/modules/chats/module.py
@@ -1,3 +1,4 @@
+# System doc: docs/systems/chats-presence.md
 from telebot.async_telebot import AsyncTeleBot
 from telebot.types import Message
 
```

## src/modules/chats/service.py

```diff
--- fixture/src/modules/chats/service.py
+++ working/src/modules/chats/service.py
@@ -1,3 +1,4 @@
+# System doc: docs/systems/chats-presence.md
 from datetime import datetime, timezone
 from typing import cast
 
```

## src/modules/help/bot_connector.py

```diff
--- fixture/src/modules/help/bot_connector.py
+++ working/src/modules/help/bot_connector.py
@@ -1,3 +1,4 @@
+# System doc: docs/systems/owner-commands.md  (cleanup_message callback is owned there)
 from telebot.async_telebot import AsyncTeleBot
 from telebot.formatting import escape_markdown
 from telebot.types import (
```

## src/modules/system/bot_connector.py

```diff
--- fixture/src/modules/system/bot_connector.py
+++ working/src/modules/system/bot_connector.py
@@ -1,3 +1,4 @@
+# System doc: docs/systems/owner-commands.md
 import socket
 
 from telebot.async_telebot import AsyncTeleBot
```

## src/modules/system/service.py

```diff
--- fixture/src/modules/system/service.py
+++ working/src/modules/system/service.py
@@ -1,3 +1,4 @@
+# System doc: docs/systems/owner-commands.md
 import asyncio
 import os
 import socket
```

