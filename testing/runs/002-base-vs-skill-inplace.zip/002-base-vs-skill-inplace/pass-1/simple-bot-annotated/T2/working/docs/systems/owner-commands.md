# Owner commands

The bot exposes a small set of DM-only commands for the owner: `/help`, `/ping`, `/debug`, `/sleep`. The `help` and `system` modules implement them but share one access model and one cross-module callback worth knowing about.

## Owner gating

`owner_ids` in config is the allow-list of Telegram user ids with elevated access. Each handler checks `is_owner` itself (in `src/connectors/telegram/utils.py`); there is no central middleware. If a new handler should be owner-only, the convention is the same in-line check.

## System modules

A module marked `is_system = True` (currently only `system`) is hidden from `/help` for non-owners. The help service filters the menu; if the module's `help()` returns text, owners see it. Use this for any module whose existence shouldn't be advertised to ordinary users.

## `/sleep` blocks on purpose

`/sleep <seconds>` calls blocking `time.sleep`, not `asyncio.sleep`. It deliberately freezes the event loop so a second deployed instance can take over Telegram polling without conflict — useful for blue/green-style restarts when both processes briefly share the same token.

Don't "fix" it to be async. The block *is* the feature.

The accepted range (10s–1200s, `MIN_SLEEP`/`MAX_SLEEP`) is a safety rail. Going lower defeats the purpose of yielding; going higher is more rope than the owner usually wants.

## Shared "delete this message" callback

Both `/debug` and `/help` end with a "Удалить" button that removes the reply and the original command message. The callback handler (`cleanup_message`) is registered by the system module's bot connector; the help module's connector just emits the same callback data on its own buttons.

Only the user who issued the originating command can trigger the cleanup; other users get a soft refusal. If a third module wants the same affordance, emit the same callback data — don't register another handler.
