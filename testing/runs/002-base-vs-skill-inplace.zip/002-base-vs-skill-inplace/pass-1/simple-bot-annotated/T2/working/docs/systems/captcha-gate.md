# Captcha gate

When someone new joins a group chat, the bot asks them a simple Russian-language question. If they answer in time, they're welcomed; if the timer runs out, the bot kicks them. The point is to drop trivial spam joins without locking the chat down.

## How a join lands

The new-member event reaches `CaptchaModule.handle_join`, which returns one of four outcomes:

- **PASSED** — the user answered correctly within the time limit.
- **FAILED** — the time limit ran out; the user is kicked.
- **SKIPPED** — no challenge ran. Reasons: the joiner is a bot (a short greeting is sent anyway), the joiner is a known returner (see [chats-presence.md](chats-presence.md)), or the message was added by someone other than the joiner themselves (e.g. an admin adding a user).
- **ABORTED** — the challenge started but the user left mid-challenge.

## Outdated joins

Telegram redelivers backlog `new_chat_members` events when the bot reconnects after downtime. An event older than 45 seconds (`CAPTCHA_OUTDATED_TIMEOUT`) is treated as backlog. If the user is still in the chat, the bot tells them the check expired; otherwise it stays silent. Either way, no challenge runs.

## During the challenge

While the timer ticks (default 15s, configurable as `captcha.challenge_time`), the top-level message handler in `app.py` intercepts every message from a user with an open challenge and routes it straight to `verify_answer`. See [bot-architecture.md](bot-architecture.md) for why this intercept lives at the dispatch point rather than in the captcha module's own handler.

If the challenged user leaves the chat mid-challenge, the `left_chat_member` event aborts the challenge so the polling loop exits cleanly without trying to kick someone who's already gone.

## The kick

Telegram's bot API has no "remove without ban" primitive for supergroups. The captcha kicks by banning, sleeping one second, then unbanning. **The one-second gap is real.** Without it the unban can race the ban server-side and silently no-op (the unban arrives before the ban is committed), leaving the user permanently banned. If you ever change this code, keep the stagger.

## Strings and questions

User-facing copy and the question pool live in `src/modules/captcha/strings.py`. Questions are simple arithmetic and trivia with one literal answer each. The answer string `~` is a wildcard — used by tests, not exposed to config. Treat it as intentional: don't strip the wildcard branch.
