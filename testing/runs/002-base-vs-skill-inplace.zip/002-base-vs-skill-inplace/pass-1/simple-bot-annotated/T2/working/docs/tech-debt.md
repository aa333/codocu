# Tech debt

**TD-chats-multi-instance**: ChatsService caches the full `chat_memberships` table in memory at startup and treats the cache as the source of truth for the session — running two bot instances against the same DB will silently diverge their caches. If a multi-instance setup is adopted, the cache must be invalidated on writes by another instance, or removed. See [docs/systems/chats-presence.md](systems/chats-presence.md).
