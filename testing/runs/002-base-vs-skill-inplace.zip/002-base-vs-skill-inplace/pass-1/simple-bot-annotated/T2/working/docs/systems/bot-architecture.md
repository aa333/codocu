# Bot architecture

simple-bot is a Telegram group-chat bot. It gates new joiners with a captcha, tracks who is actually in each chat over time, and exposes a few diagnostic commands to the owner over DM. All user-facing messages are in Russian; new modules should follow.

## Modules

Every piece of behavior is a module under `src/modules/<name>/`. The four shipped modules are `chats`, `captcha`, `help`, and `system`. A new module is one directory with:

- `module.py` — the `Module` subclass. This is the DI handle other modules ask for.
- `service.py` — pure logic, no Telegram imports. Testable in isolation.
- `bot_connector.py` — the only file that talks to telebot. Registers handlers and turns Telegram events into service calls.
- `strings.py` — Russian-language user-facing strings.
- `models.py` (optional) — peewee model classes, listed on the module class's `models` tuple so the app picks them up at table creation.

The Module / Service / BotConnector split is load-bearing. Services stay testable because they don't import telebot. The connector is swappable if the bot ever speaks a second protocol. The module class carries the metadata (`name`, `str_name`, `is_system`, `help()`, `debug()`) that the help and debug commands consume generically.

## Assembly

`src/app.py` runs in three phases:

1. **Instantiate.** Construct every class in `MODULE_CLASSES`. Construction is cheap and dependency-free; modules must not reach into DI in `__init__`.
2. **Register.** Put the config, the bot, each module, and the `ModuleList` wrapper into the DI registry. DI is a flat global type→instance dict (`src/core/di.py`) — no scopes, no DAG, no lifecycle management.
3. **Init.** `await m.init()` on each module in declaration order. This is where modules pull cross-module dependencies via `di.get(...)` and register their handlers.

`MODULE_CLASSES` order is the dependency order. `chats` precedes `captcha` because the captcha service asks chats whether a joiner is a returner. `depends_on` on the module class records the intent but is not enforced; the list ordering is what actually drives init.

After init, `app.py` installs the top-level group-chat message handler. It runs the captcha intercept first (see [captcha-gate.md](captcha-gate.md)), then calls `chats.touch()` so presence tracking sees the message.

## Why the captcha intercept lives in app.py

The intercept could live inside the captcha module's own message handler. It lives in `app.py` because the captcha must win the race against every other module's message handler — the challenged user's reply is otherwise just an ordinary message. Putting the check at the dispatch point makes that win impossible to miss when a new module is added.

## Configuration

Config is JSON at `config.json`, loaded into the frozen `AppConfig` dataclass on startup (`src/core/config.py`). `config.example.json` is the template. The configurable surface is small on purpose: bot token, optional proxy, SQLite path, owner ids, debug-chat ids, log level, and the captcha challenge time.

## Storage

One peewee SQLite database (`src/storage/database.py`), opened in WAL mode with foreign keys on. Modules declare their model classes on the `models` class attribute; `app.py` collects them and creates tables at startup. The DB handle is lazily initialized (`SqliteDatabase(None)` then `init_db(path)`) so config can drive the path.
