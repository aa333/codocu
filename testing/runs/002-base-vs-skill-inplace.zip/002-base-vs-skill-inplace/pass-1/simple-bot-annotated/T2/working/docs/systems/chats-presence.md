# Chats presence

The chats module tracks who is actually present in each chat. Its only current consumer is the captcha gate, which asks "have we seen this user here before?" so it can skip re-challenging known returners.

## Becoming known

A user becomes "known" in a chat after sending `MESSAGES_TO_BE_KNOWN` messages (currently 3). Joining alone doesn't make a user known — a botted joiner who never speaks won't graduate, so the captcha will challenge them again if they leave and rejoin.

The threshold is a soft heuristic against passive accounts gaming the bypass. Raise it if drive-by joins start abusing the skip; lower it if real users complain about being re-challenged.

## Storage and the cache

Membership rows persist in the `chat_memberships` table (composite key chat_id + user_id). The full table is loaded into memory at startup and the in-memory cache is the source of truth for queries during the session; writes go through to peewee.

The cache assumes one bot instance writes at a time. Running two instances against the same DB will silently diverge the caches — tracked as TD-chats-multi-instance in [docs/tech-debt.md](../tech-debt.md).

## Leaving

`left_chat_member` flips `in_chat` to false but keeps the row, so a returning user is still "known" and bypasses the captcha. Rows are never deleted; the bot has no reason to forget.

## What this module doesn't do

It doesn't track admin status, kick history, or message content. It doesn't deduplicate across chats — a user is known in chat A and unknown in chat B until they speak in B.
