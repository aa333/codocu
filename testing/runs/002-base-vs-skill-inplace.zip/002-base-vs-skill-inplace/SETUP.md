# Base-vs-Skill Eval — SETUP (in-place flow)

Same headline question as 001: **does Codocu's bloat and code-repetition
failure live in the base material or in the skill's behavior on top of
it?** Refactored to fix two shape problems found in 001/pass-1.

Companion design: [`docs/plans/2026-05-26-eval-suite-refactor.md`](../../../docs/plans/2026-05-26-eval-suite-refactor.md).
Original suite design (still useful context): [`docs/plans/2026-05-25-base-vs-skill-eval-suite-design.md`](../../../docs/plans/2026-05-25-base-vs-skill-eval-suite-design.md).
Motivating prior art: [`PRIOR-FINDINGS.md`](PRIOR-FINDINGS.md).

## What changed from 001

1. **Both doc homes are available.** 001 gave agents a write-only `produced/`
   directory and pointed them at a read-only fixture, so the only homes
   they had were System (`docs/`) and Outside. The doc-standard's whole
   routing rule (symbol → docstring, module → file header, …) had no
   target to route *toward*. 002 hands the agent a working copy of the
   fixture and tells it explicitly to write each piece of doc in its
   proper home — inline or aux.
2. **Tier ladder collapses 5 → 3.** Old T1 (principles only) and old T3
   (+ smell-catalog) dropped. The headline question is *Codocu as designed
   vs base materials*; the in-between ablations weren't changing any
   decisions after pass-1.

## Fixtures

Same two as 001, frozen at the same paths under `testing/fixtures/full/`.

- **`simple-bot-annotated/`** — Python. Ships with `simple-bot-annotated-reference/`
  (METADOCU-annotated; scorer-only).
- **`obsidian-spotiplay/`** — TypeScript. No `-reference/` companion.

Each fixture is frozen. Bad fixture → new name; never edit in place.

## Tier ladder

| Tier | Materials | What it isolates |
|---|---|---|
| **T0** | Nothing Codocu. Generic prompt. | The pretrained baseline. |
| **T1** | + `skills/codocu/references/principles.md` + `doc-standard.md` (prepended to the prompt as "project conventions"). | Marginal value of the base materials. |
| **T2** | Full `/codocu` skill via plugin install. `/codocu:init` then `/codocu` against the working copy. | Marginal value of the skill scaffolding. |

T0–T1 deliver materials by injecting files into the agent's initial context
as plain text. The agent is given the working copy and told it can write
aux docs *and* edit code (docstrings, comments). T2 is the real plugin
invocation: `claude --plugin-dir <codocu-repo>` inside the working copy.

One run per cell to start. Variance test deferred. Opus 4.7 only at first.

## Per-cell flow

1. Copy `testing/fixtures/full/<fixture>/` to `<cell>/working/`.
2. Dispatch the run agent into `working/`. It can write aux docs anywhere
   under `docs/` and edit code-file docstrings/comments in place. It must
   not change non-doc code; the metrics catch this via the `code_touched`
   flag.
3. After the run, `working/` is the artifact. To extract "what the agent
   wrote", diff it against `testing/fixtures/full/<fixture>/`.

T2 (full skill) follows the same shape — the user launches
`claude --plugin-dir <codocu-repo>` inside `working/` and runs the skill;
no separate `produced/` collection step.

## Scoring — three tracks

Same triangle as 001. Both doc homes (inline + aux) feed every track.

### Manual rubric

| # | Criterion | Scale |
|---|---|---|
| 1 | Principle adherence — does each sentence say something code can't? | 1–5 |
| 2 | Refactor resistance — would this survive a rename, extract, or inline? | 1–5 |
| 3 | Bloat — judged against a minimum-viable mental version of the same doc. | 1–5 |
| 4 | Code-restating count | list of sentences with file refs |
| 5 | Voice — busy-tired-reader, or reference material? | 1–5 |

**METADOCU agreement (optional — only when the fixture ships a `-reference/`
companion):** of the N annotation-flagged issues, how many does this run
reproduce, avoid, or introduce new? `simple-bot-annotated` ships one, so
the section applies there. `obsidian-spotiplay` does not, so it is
omitted from that fixture's scorecards.

Manual scores live in `manual-score.md` inside each cell directory.

### Automated metrics — `testing/tools/metrics.py`

Per produced `.md` (aux docs under `working/`):
- word count, sentence count, average sentence length
- code-block count, code-block total lines

Per code file (`.py`, `.ts`, `.tsx`, `.js`, `.jsx`):
- inline-doc words added vs fixture original (line-classification heuristic
  for docstrings and comments)

Aggregated per cell:
- `total_aux_words`, `total_inline_words`, `total_doc_words`
- `home_split` = `total_inline_words / total_doc_words` (the routing signal
  the 001 metrics couldn't see)
- `fixture_module_count`, `words_per_module` (sum across both surfaces)
- `code_touched` boolean — true if the agent changed any non-doc code line

Identifier-mention density is parked (see `TD-eval-identifier-counts` in
`docs/todo.md`); reviving it needs real Python and TypeScript ASTs.

JSON output → `metrics.json` in each cell directory. Diffable across passes.

### Claude-as-judge

Fresh session loaded with principles.md + doc-standard.md + the agent's
output (new `.md` files under `working/docs/` plus the docstring/comment
diff per code file). No transcript, no rubric, no other tier's output.
Scores the same five criteria across both surfaces; lists specific
sentences (aux or inline) that restate code; outputs structured markdown
→ `judge-score.md`.

Known limit: the judge may share the bloat-tilt we're hunting. Convergence
across the three tracks = high confidence. Divergence = data.

## Pass output layout

```
testing/runs/002-base-vs-skill-inplace/
  SETUP.md              # this file
  PRIOR-FINDINGS.md     # carried forward from 001
  SUMMARY.md            # cross-cell scoreboard + narrative + next-pass actions
  pass-1/
    simple-bot-annotated/
      T0/
        prompt.md          # exact prompt given to the agent
        transcript.md      # verbatim agent transcript
        working/           # the fixture copy after the agent worked on it
        metrics.json
        judge-score.md
        manual-score.md   # includes METADOCU section
      T1/ T2/
    obsidian-spotiplay/
      T0/ T1/ T2/         # same shape; manual-score.md omits METADOCU
```

## Running a pass

The operator skill is `.claude/skills/eval-base-vs-skill/` (project-local;
not in the plugin manifest). It owns the playbook — how the run agent is
dispatched into `working/`, how scoring extracts both surfaces, where
outputs land.

## Status

- **Phase 1** — refactor of the 001 flow landing in 002. SETUP in place,
  skill rewritten for in-place flow, metrics extended for inline-doc
  accounting and `home_split`. First clean pass pending.
- **Phase 2** — `pass <id>` orchestrator and variance reruns.
